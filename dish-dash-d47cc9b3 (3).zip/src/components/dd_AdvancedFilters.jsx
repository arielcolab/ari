import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Filter, MapPin, Clock, Star, Utensils } from 'lucide-react';
import { FeatureFlag } from './dd_FeatureFlag';

const AdvancedFilters = ({ isOpen, onClose, filters, onFiltersChange, onSaveSearch }) => {
  const [localFilters, setLocalFilters] = useState(filters);
  const [searchName, setSearchName] = useState('');

  const dietaryOptions = [
    'vegetarian', 'vegan', 'gluten_free', 'dairy_free', 'nut_free', 'keto', 'paleo'
  ];

  const allergenOptions = [
    'nuts', 'dairy', 'eggs', 'gluten', 'soy', 'shellfish', 'fish'
  ];

  const kosherLevels = [
    { value: 'none', label: 'Not Kosher' },
    { value: 'kosher_style', label: 'Kosher Style' },
    { value: 'kosher_supervised', label: 'Kosher Supervised' },
    { value: 'glatt_kosher', label: 'Glatt Kosher' }
  ];

  const handleFilterChange = (key, value) => {
    setLocalFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleApply = () => {
    onFiltersChange(localFilters);
    onClose();
  };

  const handleReset = () => {
    const resetFilters = {
      dietary_tags: [],
      allergens: [],
      kosher_level: 'none',
      max_distance: 10,
      max_price: 50,
      min_rating: 0,
      cooked_within_hours: 24,
      expires_within_hours: 12,
      cuisine_type: '',
      spice_level: ''
    };
    setLocalFilters(resetFilters);
    onFiltersChange(resetFilters);
  };

  const handleSaveSearch = () => {
    if (searchName.trim()) {
      onSaveSearch(searchName, localFilters);
      setSearchName('');
    }
  };

  if (!isOpen) return null;

  return (
    <FeatureFlag flag="ff_advanced_filters">
      <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center">
        <div className="bg-white w-full sm:w-96 max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl">
          <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
            <h2 className="text-xl font-semibold">Advanced Filters</h2>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>

          <div className="p-4 space-y-6">
            {/* Distance Filter */}
            <div>
              <Label className="flex items-center gap-2 mb-3">
                <MapPin className="w-4 h-4" />
                Distance: {localFilters.max_distance || 10} km
              </Label>
              <Slider
                value={[localFilters.max_distance || 10]}
                onValueChange={([value]) => handleFilterChange('max_distance', value)}
                max={50}
                min={1}
                step={1}
                className="w-full"
              />
            </div>

            {/* Price Range */}
            <div>
              <Label className="mb-3 block">Max Price: ${localFilters.max_price || 50}</Label>
              <Slider
                value={[localFilters.max_price || 50]}
                onValueChange={([value]) => handleFilterChange('max_price', value)}
                max={100}
                min={1}
                step={1}
                className="w-full"
              />
            </div>

            {/* Rating Filter */}
            <div>
              <Label className="flex items-center gap-2 mb-3">
                <Star className="w-4 h-4" />
                Minimum Rating: {localFilters.min_rating || 0} stars
              </Label>
              <Slider
                value={[localFilters.min_rating || 0]}
                onValueChange={([value]) => handleFilterChange('min_rating', value)}
                max={5}
                min={0}
                step={0.5}
                className="w-full"
              />
            </div>

            {/* Freshness Filters */}
            <div>
              <Label className="flex items-center gap-2 mb-3">
                <Clock className="w-4 h-4" />
                Cooked within: {localFilters.cooked_within_hours || 24} hours
              </Label>
              <Slider
                value={[localFilters.cooked_within_hours || 24]}
                onValueChange={([value]) => handleFilterChange('cooked_within_hours', value)}
                max={72}
                min={1}
                step={1}
                className="w-full"
              />
            </div>

            <div>
              <Label className="mb-3 block">Expires within: {localFilters.expires_within_hours || 12} hours</Label>
              <Slider
                value={[localFilters.expires_within_hours || 12]}
                onValueChange={([value]) => handleFilterChange('expires_within_hours', value)}
                max={48}
                min={1}
                step={1}
                className="w-full"
              />
            </div>

            {/* Dietary Tags */}
            <div>
              <Label className="mb-3 block">Dietary Preferences</Label>
              <div className="grid grid-cols-2 gap-2">
                {dietaryOptions.map(option => (
                  <div key={option} className="flex items-center space-x-2">
                    <Switch
                      id={option}
                      checked={(localFilters.dietary_tags || []).includes(option)}
                      onCheckedChange={(checked) => {
                        const current = localFilters.dietary_tags || [];
                        const updated = checked 
                          ? [...current, option]
                          : current.filter(tag => tag !== option);
                        handleFilterChange('dietary_tags', updated);
                      }}
                    />
                    <Label htmlFor={option} className="text-sm capitalize">
                      {option.replace('_', ' ')}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Allergen Exclusions */}
            <div>
              <Label className="mb-3 block">Exclude Allergens</Label>
              <div className="grid grid-cols-2 gap-2">
                {allergenOptions.map(allergen => (
                  <div key={allergen} className="flex items-center space-x-2">
                    <Switch
                      id={`exclude-${allergen}`}
                      checked={(localFilters.allergens || []).includes(allergen)}
                      onCheckedChange={(checked) => {
                        const current = localFilters.allergens || [];
                        const updated = checked 
                          ? [...current, allergen]
                          : current.filter(a => a !== allergen);
                        handleFilterChange('allergens', updated);
                      }}
                    />
                    <Label htmlFor={`exclude-${allergen}`} className="text-sm capitalize">
                      {allergen}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Kosher Level */}
            <div>
              <Label className="mb-3 block">Kosher Level</Label>
              <Select 
                value={localFilters.kosher_level || 'none'} 
                onValueChange={(value) => handleFilterChange('kosher_level', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select kosher level" />
                </SelectTrigger>
                <SelectContent>
                  {kosherLevels.map(level => (
                    <SelectItem key={level.value} value={level.value}>
                      {level.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Cuisine Type */}
            <div>
              <Label className="flex items-center gap-2 mb-3">
                <Utensils className="w-4 h-4" />
                Cuisine Type
              </Label>
              <Select 
                value={localFilters.cuisine_type || ''} 
                onValueChange={(value) => handleFilterChange('cuisine_type', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Any cuisine" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>Any cuisine</SelectItem>
                  <SelectItem value="italian">Italian</SelectItem>
                  <SelectItem value="mexican">Mexican</SelectItem>
                  <SelectItem value="asian">Asian</SelectItem>
                  <SelectItem value="indian">Indian</SelectItem>
                  <SelectItem value="mediterranean">Mediterranean</SelectItem>
                  <SelectItem value="american">American</SelectItem>
                  <SelectItem value="french">French</SelectItem>
                  <SelectItem value="thai">Thai</SelectItem>
                  <SelectItem value="chinese">Chinese</SelectItem>
                  <SelectItem value="japanese">Japanese</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Save Search */}
            <FeatureFlag flag="ff_enhanced_search">
              <div className="border-t pt-4">
                <Label className="mb-2 block">Save this search</Label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Search name"
                    value={searchName}
                    onChange={(e) => setSearchName(e.target.value)}
                    className="flex-1 px-3 py-2 border rounded-lg"
                  />
                  <Button onClick={handleSaveSearch} disabled={!searchName.trim()}>
                    Save
                  </Button>
                </div>
              </div>
            </FeatureFlag>
          </div>

          <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4 flex gap-3">
            <Button variant="outline" onClick={handleReset} className="flex-1">
              Reset
            </Button>
            <Button onClick={handleApply} className="flex-1 bg-red-500 hover:bg-red-600">
              Apply Filters
            </Button>
          </div>
        </div>
      </div>
    </FeatureFlag>
  );
};

export default AdvancedFilters;