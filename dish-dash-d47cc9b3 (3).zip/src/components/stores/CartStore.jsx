
class CartStore {
  constructor() {
    this.items = [];
    this.listeners = [];
    this.loadItems();
  }

  loadItems() {
    try {
      const stored = localStorage.getItem('dishDashCart');
      this.items = stored ? JSON.parse(stored) : [];
      // Validate loaded items
      this.items = this.items.filter(item => item && item.dish && item.dish.id);
    } catch (error) {
      console.error('Error loading cart from storage:', error);
      this.items = [];
      this.clearStorage();
    }
  }

  loadFromStorage() {
    return [...this.items];
  }

  saveToStorage() {
    try {
      localStorage.setItem('dishDashCart', JSON.stringify(this.items));
    } catch (error) {
      console.error('Error saving cart to storage:', error);
    }
  }

  clearStorage() {
    try {
      localStorage.removeItem('dishDashCart');
    } catch (error) {
      console.error('Error clearing cart storage:', error);
    }
  }

  addItem(item, quantity = 1, itemType = 'dish') {
    if (!item || !item.id) {
      throw new Error('Invalid item data provided');
    }

    try {
      const existingIndex = this.items.findIndex(cartItem => cartItem.dish.id === item.id && cartItem.dish.type === itemType);
      
      if (existingIndex >= 0) {
        this.items[existingIndex].quantity += quantity;
      } else {
        // Normalize item data based on type
        let normalizedItem;
        switch (itemType) {
          case 'dish':
          case 'prepared_meal':
          case 'leftovers':
            normalizedItem = {
              id: item.id,
              name: item.name || item.title,
              price: item.price || 0,
              photos: item.photos && item.photos.length > 0 ? item.photos : (item.photo_url ? [item.photo_url] : []),
              cook_name: item.cook_name || item.chef_name || 'Unknown Cook',
              type: itemType,
              servings: item.servings || 1,
              condition: item.condition || 'fresh'
            };
            break;
          case 'class':
            normalizedItem = {
              id: item.id,
              name: item.title,
              price: item.price || 0,
              photos: item.image_url ? [item.image_url] : [],
              cook_name: item.chef_name || 'Unknown Chef',
              type: 'class',
              date: item.date,
              capacity: item.capacity,
              spots_left: item.spots_left
            };
            break;
          case 'meal_prep':
            normalizedItem = {
              id: item.id,
              name: item.service_title,
              price: item.price_per_week || 0,
              photos: item.photo_url ? [item.photo_url] : [],
              cook_name: item.cook_name || 'Unknown Cook',
              type: 'meal_prep',
              meals_per_week: item.meals_per_week
            };
            break;
          case 'last_call':
            normalizedItem = {
              id: item.id,
              name: item.food_title,
              price: item.discounted_price || 0,
              original_price: item.original_price,
              photos: item.photo_url ? [item.photo_url] : [],
              cook_name: item.seller_name || 'Unknown Seller',
              type: 'last_call',
              expires_at: item.expires_at,
              discount_percentage: item.discount_percentage
            };
            break;
          case 'surplus_grocery':
            normalizedItem = {
              id: item.id,
              name: item.product_title,
              price: item.discounted_price || 0,
              original_price: item.original_price,
              photos: item.photo_url ? [item.photo_url] : [],
              cook_name: item.seller_name || 'Unknown Seller',
              type: 'surplus_grocery',
              brand: item.brand,
              size: item.size,
              expiry_date: item.expiry_date
            };
            break;
          case 'giveaway': // Added case for giveaways
            normalizedItem = {
              id: item.id,
              name: item.item_title,
              price: 0, // Giveaways are free
              photos: item.photo_url ? [item.photo_url] : [],
              cook_name: item.giver_name || 'Community Member',
              type: 'giveaway',
            };
            break;
          default:
            normalizedItem = {
              id: item.id,
              name: item.name || item.title,
              price: item.price || 0,
              photos: item.photos && item.photos.length > 0 ? item.photos : (item.photo_url ? [item.photo_url] : []),
              cook_name: item.cook_name || 'Unknown',
              type: itemType
            };
        }

        this.items.push({ 
          dish: normalizedItem,
          quantity: quantity
        });
      }
      
      this.saveToStorage();
      this.notifyListeners();
      
      // Award gamification points on successful add to cart
      this.tryAwardGamificationPoints();
    } catch (error) {
      console.error('Error adding item to cart:', error);
      throw error;
    }
  }

  updateQuantity(dishId, quantity) {
    try {
      if (quantity <= 0) {
        this.removeItem(dishId);
        return;
      }

      this.items = this.items.map(item =>
        item.dish.id === dishId
          ? { ...item, quantity }
          : item
      );

      this.saveToStorage();
      this.notifyListeners();
    } catch (error) {
      console.error('Error updating quantity:', error);
      throw error;
    }
  }

  removeItem(dishId) {
    try {
      this.items = this.items.filter(item => item.dish.id !== dishId);
      this.saveToStorage();
      this.notifyListeners();
    } catch (error) {
      console.error('Error removing item:', error);
      throw error;
    }
  }

  getTotal() {
    try {
      return this.items.reduce((total, item) => {
        const price = parseFloat(item.dish.price) || 0;
        const quantity = parseInt(item.quantity) || 0;
        return total + (price * quantity);
      }, 0);
    } catch (error) {
      console.error('Error calculating total:', error);
      return 0;
    }
  }

  getItemCount() {
    try {
      return this.items.reduce((count, item) => count + (parseInt(item.quantity) || 0), 0);
    } catch (error) {
      console.error('Error getting item count:', error);
      return 0;
    }
  }

  clear() {
    this.items = [];
    this.saveToStorage();
    this.notifyListeners();
  }

  subscribe(callback) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  notifyListeners() {
    this.listeners.forEach(callback => {
      try {
        callback([...this.items]);
      } catch (error) {
        console.error('Error in cart listener:', error);
      }
    });
  }

  async tryAwardGamificationPoints() {
    try {
      // Import dynamically to avoid circular dependencies
      const { User } = await import('@/api/entities');
      const { awardOrderPoints } = await import('../gamification/GamificationManager');
      
      const user = await User.me();
      if (user && user.id) {
        await awardOrderPoints(user.id);
      }
    } catch (error) {
      // Silently fail - gamification should not break cart functionality
      console.log('Gamification points could not be awarded:', error);
    }
  }
}

export const cartStore = new CartStore();
