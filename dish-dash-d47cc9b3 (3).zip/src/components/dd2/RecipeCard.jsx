import React from 'react';
import { Clock, Star, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import OptimizedImage from '../dd_OptimizedImage';

const RecipeCard = ({ recipe, className = "", showPantryStatus = false }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(createPageUrl(`DD2_RecipeDetail?id=${recipe.id}`));
  };

  return (
    <div 
      onClick={handleClick}
      className={`bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer overflow-hidden ${className}`}
    >
      <div className="relative aspect-video">
        <OptimizedImage
          src={recipe.imageUrl || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop"}
          alt={recipe.title}
          className="w-full h-full object-cover"
        />
        {showPantryStatus && (
          <div className="absolute top-3 right-3 bg-green-500 text-white text-xs px-2 py-1 rounded-full font-medium">
            Pantry Ready
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">{recipe.title}</h3>
        
        <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{recipe.prepTime + recipe.cookTime} min</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>{recipe.servings} servings</span>
          </div>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <span>{recipe.rating || 4.5}</span>
          </div>
        </div>
        
        <p className="text-gray-600 text-sm line-clamp-2">{recipe.description}</p>
      </div>
    </div>
  );
};

export default RecipeCard;