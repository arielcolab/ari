
import React from 'react';
import { Clock, Users, MapPin, Calendar, Star, AlertCircle, Timer } from 'lucide-react';
import { useTranslation } from '../utils/translations';
import OptimizedImage from '../dd_OptimizedImage';
import { PriceDisplay } from '../utils/dd_currency';
import RatingDisplay from '../reviews/RatingDisplay';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';
import QuickAddToCart from './QuickAddToCart';

export default function DetailedItemCard({ item, type, onClick }) {
  const { t } = useTranslation();

  const getItemDetails = () => {
    switch (type) {
      case 'prepared_meal':
      case 'leftovers':
        return {
          title: item.name,
          subtitle: item.cook_name,
          image: item.photo_url,
          price: item.price,
          route: `DishDetails?id=${item.id}`,
          details: [
            { icon: Users, text: `${item.servings} מנות` },
            { icon: Clock, text: item.condition === 'fresh' ? 'טרי' : 'מקורר' },
            { icon: MapPin, text: item.location }
          ],
          badges: item.diet_tags?.slice(0, 2) || [],
          allergens: item.allergen_list || []
        };
      case 'class':
        return {
          title: item.title,
          subtitle: item.chef_name,
          image: item.image_url,
          price: item.price,
          route: `ClassDetails?id=${item.id}`,
          details: [
            { icon: Calendar, text: new Date(item.date).toLocaleDateString('he-IL') },
            { icon: Users, text: `${item.spots_left} מקומות נותרו` },
            { icon: MapPin, text: item.address }
          ],
          badges: [item.category],
          rating: item.rating
        };
      case 'meal_prep':
        return {
          title: item.service_title,
          subtitle: item.cook_name,
          image: item.photo_url,
          price: item.price_per_week,
          route: `MealPrepDetails?id=${item.id}`,
          details: [
            { icon: Users, text: `${item.meals_per_week} ארוחות בשבוע` },
            { icon: Clock, text: 'הכנה שבועית' }
          ],
          badges: item.cuisine_types?.slice(0, 2) || [],
          rating: item.rating_average
        };
      case 'last_call':
        return {
          title: item.food_title,
          subtitle: item.seller_name,
          image: item.photo_url,
          price: item.discounted_price,
          originalPrice: item.original_price,
          route: `LastCallEatDetails?id=${item.id}`,
          details: [
            { icon: Timer, text: `פג בעוד ${formatDistanceToNow(new Date(item.expires_at))}` },
            { icon: MapPin, text: item.pickup_location }
          ],
          badges: [`${item.discount_percentage}% הנחה`, item.condition],
          urgent: new Date(item.expires_at) - new Date() < 2 * 60 * 60 * 1000 // Less than 2 hours
        };
      case 'surplus_grocery':
        return {
          title: item.product_title,
          subtitle: item.seller_name,
          image: item.photo_url,
          price: item.discounted_price,
          originalPrice: item.original_price,
          route: `SurplusGroceryDetails?id=${item.id}`,
          details: [
            { icon: Calendar, text: `תפוג ב-${new Date(item.expiry_date).toLocaleDateString('he-IL')}` },
            { icon: MapPin, text: item.pickup_location }
          ],
          badges: [`${item.discount_percentage}% הנחה`, item.brand, item.size]
        };
      case 'giveaway':
        return {
          title: item.item_title,
          subtitle: item.giver_name,
          image: item.photo_url,
          isFree: true,
          route: `GiveawayDetails?id=${item.id}`,
          details: [
            { icon: Calendar, text: `זמין עד ${new Date(item.available_until).toLocaleDateString('he-IL')}` },
            { icon: MapPin, text: item.pickup_location }
          ],
          badges: [item.condition, item.category]
        };
      default:
        return {};
    }
  };

  const details = getItemDetails();

  return (
    <div className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
      <div onClick={onClick} className="cursor-pointer">
        <div className="relative">
          <OptimizedImage 
            src={details.image} 
            alt={details.title}
            className="w-full h-40 object-cover"
          />
          
          {/* Urgent badge for last call items */}
          {details.urgent && (
            <div className="absolute top-2 right-2 bg-red-600 text-white text-xs px-2 py-1 rounded-full font-bold animate-pulse">
              דחוף!
            </div>
          )}
          
          {/* Condition badge */}
          {type === 'leftovers' && (
            <div className="absolute top-2 left-2 bg-blue-600 text-white text-xs px-2 py-1 rounded-full">
              שאריות
            </div>
          )}
        </div>

        <div className="p-4">
          <h4 className="font-bold text-gray-900 text-base mb-1 line-clamp-2">{details.title}</h4>
          <p className="text-sm text-gray-600 mb-2">{details.subtitle}</p>

          {/* Price */}
          <div className="flex items-center gap-2 mb-3">
            {details.isFree ? (
              <span className="text-green-600 font-bold text-lg">חינם!</span>
            ) : (
              <>
                <PriceDisplay price={details.price} className="font-bold text-lg text-red-600" />
                {details.originalPrice && (
                  <PriceDisplay 
                    price={details.originalPrice} 
                    className="text-sm text-gray-500 line-through" 
                  />
                )}
              </>
            )}
          </div>

          {/* Details */}
          <div className="space-y-1 mb-3">
            {details.details?.map((detail, index) => (
              <div key={index} className="flex items-center gap-2 text-xs text-gray-600">
                <detail.icon className="w-3 h-3 flex-shrink-0" />
                <span className="truncate">{detail.text}</span>
              </div>
            ))}
          </div>

          {/* Rating */}
          {details.rating && (
            <div className="mb-3">
              <RatingDisplay rating={details.rating} showCount={false} size="sm" />
            </div>
          )}

          {/* Badges */}
          {details.badges?.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-3">
              {details.badges.slice(0, 3).map((badge, index) => (
                <Badge 
                  key={index} 
                  variant="secondary" 
                  className="text-xs bg-gray-100 text-gray-700"
                >
                  {badge}
                </Badge>
              ))}
            </div>
          )}

          {/* Allergens */}
          {details.allergens?.length > 0 && (
            <div className="flex items-center gap-1 mb-3">
              <AlertCircle className="w-3 h-3 text-orange-500" />
              <span className="text-xs text-orange-600">
                מכיל: {details.allergens.slice(0, 2).join(', ')}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Quick Add to Cart - Added at bottom */}
      <div className="p-4 border-t border-gray-100" onClick={(e) => e.stopPropagation()}>
        <QuickAddToCart 
          item={item} 
          itemType={type} 
          size="default"
          showPrice={true}
          className="justify-between"
        />
      </div>
    </div>
  );
}
