
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Home, SlidersHorizontal, Map, Search, MessageSquare, Trophy } from 'lucide-react';
import LocationManager from '../location/LocationManager';
import { createPageUrl } from '@/utils';

const GlobalHeader = ({ onFilterClick, activeFilterCount = 0 }) => {
  const navigate = useNavigate();

  return (
    <div className="sticky top-0 z-40 flex items-center justify-between w-full px-4 py-3 bg-white/95 backdrop-blur-sm border-b border-gray-100 shadow-sm flex-wrap gap-y-2">
      {/* Left Side - Home Button + Location */}
      <div className="flex items-center gap-2 flex-shrink-0">
        <Button 
            variant="ghost" 
            size="icon" 
            className="bg-gray-100 hover:bg-gray-200 rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center"
            onClick={() => navigate(createPageUrl('Home'))}
        >
          <Home className="w-5 h-5 text-gray-800" />
        </Button>
        <LocationManager variant="header" />
      </div>

      {/* Right Side - Search, Messages, Gamification, Filter + Map Buttons */}
      <div className="flex items-center gap-1.5 flex-wrap justify-end">
        <Button 
            variant="ghost" 
            size="icon" 
            className="bg-gray-100 hover:bg-gray-200 rounded-full w-10 h-10 flex items-center justify-center"
            onClick={() => navigate(createPageUrl('Search'))}
        >
          <Search className="w-5 h-5 text-gray-800" />
        </Button>
        
        {/* Messages Button */}
        <Button 
            variant="ghost" 
            size="icon" 
            className="bg-gray-100 hover:bg-gray-200 rounded-full w-10 h-10 flex items-center justify-center relative"
            onClick={() => navigate(createPageUrl('Messages'))}
        >
          <MessageSquare className="w-5 h-5 text-gray-800" />
        </Button>

        {/* New Gamification Button */}
        <Button 
            variant="ghost" 
            size="icon" 
            className="bg-gray-100 hover:bg-gray-200 rounded-full w-10 h-10 flex items-center justify-center"
            onClick={() => navigate(createPageUrl('Gamification'))}
        >
          <Trophy className="w-5 h-5 text-gray-800" />
        </Button>

        {onFilterClick && (
          <Button 
              variant="ghost" 
              size="icon" 
              className="bg-gray-100 hover:bg-gray-200 rounded-full w-10 h-10 flex items-center justify-center relative"
              onClick={onFilterClick}
          >
            <SlidersHorizontal className="w-5 h-5 text-gray-800" />
            {activeFilterCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-blue-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center border-2 border-white">
                {activeFilterCount}
              </span>
            )}
          </Button>
        )}
        <Button 
            variant="ghost" 
            size="icon" 
            className="bg-gray-100 hover:bg-gray-200 rounded-full w-10 h-10 flex items-center justify-center"
            onClick={() => navigate(createPageUrl('MapListings'))}
        >
          <Map className="w-5 h-5 text-gray-800" />
        </Button>
      </div>
    </div>
  );
};

export default GlobalHeader;
