import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { MapPin, ChevronDown } from "lucide-react";
import { useTranslation } from "../utils/translations";

const LocationSelector = ({ currentLocation = "Your current location", onLocationChange }) => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <Button 
        variant="ghost" 
        className="flex items-center gap-2 text-gray-700 hover:bg-gray-100 px-3 py-2 rounded-full"
        onClick={() => setIsOpen(!isOpen)}
      >
        <MapPin className="w-4 h-4" />
        <span className="text-sm font-medium">{currentLocation}</span>
        <ChevronDown className="w-4 h-4" />
      </Button>
      
      {isOpen && (
        <div className="absolute top-full left-0 mt-2 bg-white rounded-lg shadow-lg border p-2 min-w-48 z-50">
          <div className="text-sm text-gray-600 p-2">
            Location selection coming soon
          </div>
        </div>
      )}
    </div>
  );
};

export default LocationSelector;