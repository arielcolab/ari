import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ArrowUpDown, SlidersHorizontal } from 'lucide-react';
import LocationManager from '../location/LocationManager';
import { useTranslation } from '../utils/translations';

const ListPageHeader = ({ onSortClick, onFilterClick }) => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  return (
    <div className="flex justify-between items-center p-4 bg-white border-b border-gray-200">
      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" onClick={onSortClick}>
          <ArrowUpDown className="w-4 h-4 ltr:mr-2 rtl:ml-2" />
          {t('sort', 'Sort')}
        </Button>
        <Button variant="outline" size="sm" onClick={onFilterClick}>
          <SlidersHorizontal className="w-4 h-4 ltr:mr-2 rtl:ml-2" />
          {t('filters', 'Filters')}
        </Button>
      </div>
      <LocationManager variant="simple" />
      <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
        <ArrowLeft />
      </Button>
    </div>
  );
};

export default ListPageHeader;