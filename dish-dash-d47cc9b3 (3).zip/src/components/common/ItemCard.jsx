import React from 'react';
import { useNavigate } from 'react-router-dom';
import OptimizedImage from '../dd_OptimizedImage';
import RatingDisplay from '../reviews/RatingDisplay';
import { PriceDisplay } from '../utils/dd_currency';
import QuickAddToCart from './QuickAddToCart';
import { useTranslation } from '../utils/translations';
import InfoBadge from './InfoBadge';
import { mapItemToDetails } from '../utils/details-mapper';
import { Badge } from '@/components/ui/badge';
import { Clock, Star, MapPin } from 'lucide-react';

const ItemCard = ({ item, itemType, className = '' }) => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const details = mapItemToDetails(item, itemType);

  if (!details) return null;

  const handleCardClick = () => {
    navigate(details.route);
  };

  const getBadgeColor = (type) => {
    switch (type) {
      case 'last_call': return 'bg-orange-500 text-white';
      case 'giveaway': return 'bg-green-500 text-white';
      case 'surplus_grocery': return 'bg-purple-500 text-white';
      case 'class': return 'bg-blue-500 text-white';
      case 'meal_prep': return 'bg-indigo-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  return (
    <div className={`bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col relative ${className}`}>
      <div onClick={handleCardClick} className="cursor-pointer flex-1">
        <div className="relative">
          <OptimizedImage
            src={details.imageUrl || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400"}
            alt={details.title}
            className="w-full h-32 sm:h-36 object-cover"
          />
          
          {/* Type Badge */}
          <div className={`absolute top-2 left-2 px-2 py-1 rounded-full text-xs font-bold ${getBadgeColor(itemType)}`}>
            {itemType === 'last_call' && 'SALE'}
            {itemType === 'giveaway' && 'FREE'}
            {itemType === 'surplus_grocery' && 'SURPLUS'}
            {itemType === 'class' && 'CLASS'}
            {itemType === 'meal_prep' && 'MEAL PREP'}
            {itemType === 'dish' && 'FRESH'}
          </div>

          {/* Discount Badge */}
          {details.originalPrice && details.price < details.originalPrice && (
            <div className="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-full">
              {Math.round(((details.originalPrice - details.price) / details.originalPrice) * 100)}% OFF
            </div>
          )}

          {/* Rating Overlay */}
          {details.rating && (
            <div className="absolute bottom-2 left-2 bg-black/70 text-white px-2 py-1 rounded-full flex items-center gap-1">
              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
              <span className="text-xs font-medium">{details.rating.toFixed(1)}</span>
            </div>
          )}
        </div>

        <div className="p-3 flex-1 flex flex-col">
          <h3 className="font-semibold text-sm leading-tight mb-1 line-clamp-2 flex-1">
            {details.title}
          </h3>
          
          <div className="flex items-center gap-1 mb-2 text-xs text-gray-600">
            <span className="truncate">{details.cookName}</span>
          </div>

          {/* Additional Info */}
          <div className="text-xs text-gray-500 mb-2 line-clamp-1">
            {details.subtext}
          </div>

          {/* Price and Action */}
          <div className="flex items-center justify-between mt-auto">
            <div className="flex flex-col">
              {details.originalPrice && details.price < details.originalPrice && (
                <PriceDisplay 
                  price={details.originalPrice} 
                  className="text-xs text-gray-400 line-through" 
                />
              )}
              <PriceDisplay 
                price={details.price} 
                className="font-bold text-gray-900"
                isFree={details.price === 0}
              />
            </div>
            
            <div className="flex-shrink-0">
              <QuickAddToCart 
                item={details.item} 
                itemType={itemType}
                size="sm"
                className="px-2 py-1 text-xs"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ItemCard;