import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Minus, ShoppingCart } from 'lucide-react';
import { cartStore } from '../stores/CartStore';
import { showToast } from './ErrorBoundary';
import { useTranslation } from '../utils/translations';
import { PriceDisplay } from '../utils/dd_currency';

const QuickAddToCart = ({ item, itemType, size = 'md', className = '' }) => {
  const { t } = useTranslation();
  const [quantity, setQuantity] = useState(1);
  const [isAdding, setIsAdding] = useState(false);

  const handleAddToCart = async (e) => {
    e.stopPropagation();
    setIsAdding(true);
    
    try {
      await cartStore.addItem(item, quantity, itemType);
      const itemName = item.name || item.title || item.service_title || item.food_title || item.item_title || item.product_title;
      showToast(t('addedToCartToast', '{{quantity}}x {{name}} added to cart!').replace('{{quantity}}', quantity).replace('{{name}}', itemName), 'success');
    } catch (error) {
      console.error('Error adding to cart:', error);
      showToast(t('error', 'Error adding to cart'), 'error');
    } finally {
      setIsAdding(false);
    }
  };

  const sizeClasses = {
    sm: 'h-8 px-3 text-xs',
    md: 'h-10 px-4 text-sm',
    lg: 'h-12 px-6 text-base'
  };

  // Handle free items (giveaways)
  if (itemType === 'giveaway' || (item.price === 0 && !item.discounted_price)) {
    return (
      <Button
        onClick={handleAddToCart}
        disabled={isAdding}
        size={size}
        className={`bg-green-600 hover:bg-green-700 text-white rounded-full font-bold flex-shrink-0 ${sizeClasses[size]} ${className}`}
      >
        {isAdding ? '...' : t('claim', 'Claim')}
      </Button>
    );
  }

  return (
    <div className="flex items-center gap-1 flex-shrink-0">
      {/* Quantity Selector for larger sizes */}
      {size !== 'sm' && (
        <>
          <Button
            variant="outline"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              setQuantity(Math.max(1, quantity - 1));
            }}
            className={`rounded-full ${size === 'lg' ? 'w-8 h-8' : 'w-7 h-7'}`}
          >
            <Minus className="w-3 h-3" />
          </Button>
          <span className={`min-w-[2rem] text-center font-medium ${size === 'lg' ? 'text-base' : 'text-sm'}`}>
            {quantity}
          </span>
          <Button
            variant="outline"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              setQuantity(quantity + 1);
            }}
            className={`rounded-full ${size === 'lg' ? 'w-8 h-8' : 'w-7 h-7'}`}
          >
            <Plus className="w-3 h-3" />
          </Button>
        </>
      )}

      {/* Add to Cart Button */}
      <Button
        onClick={handleAddToCart}
        disabled={isAdding}
        size={size}
        className={`bg-red-600 hover:bg-red-700 text-white rounded-full font-bold flex items-center gap-1 ${sizeClasses[size]} ${className}`}
      >
        {size === 'sm' ? (
          <Plus className="w-3 h-3" />
        ) : (
          <>
            <ShoppingCart className="w-4 h-4" />
            {isAdding ? '...' : t('add', 'Add')}
          </>
        )}
      </Button>
    </div>
  );
};

export default QuickAddToCart;