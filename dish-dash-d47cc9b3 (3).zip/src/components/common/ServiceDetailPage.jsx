import React from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useDataFetching } from '../utils/useDataFetching';
import { LoadingSpinner } from './LoadingStates';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Share2, Heart, Star } from 'lucide-react';
import OptimizedImage from '../dd_OptimizedImage';
import { PriceDisplay } from '../utils/dd_currency';
import QuickAddToCart from './QuickAddToCart';
import { useTranslation } from '../utils/translations';
import { mapItemToDetails } from '../utils/details-mapper';
import { showToast } from './ErrorBoundary';

const ServiceDetailPage = ({ entity, itemType }) => {
  const [searchParams] = useSearchParams();
  const itemId = searchParams.get('id');
  const navigate = useNavigate();
  const { t } = useTranslation();

  const { data: item, isLoading, error } = useDataFetching(async () => {
    if (!itemId) return null;
    const items = await entity.list();
    return items.find(i => i.id === itemId);
  }, [itemId]);

  const details = item ? mapItemToDetails(item, itemType) : null;

  if (isLoading) {
    return <div className="flex items-center justify-center h-screen"><LoadingSpinner size="lg" /></div>;
  }

  if (error || !details) {
    return (
      <div className="flex items-center justify-center h-screen flex-col gap-4 p-4 text-center">
        <h2 className="text-xl font-bold">{t('serviceNotFound', 'Service Not Found')}</h2>
        <p className="text-gray-600">The item you are looking for may have been removed or is no longer available.</p>
        <Button onClick={() => navigate(-1)}>{t('back', 'Back')}</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="relative">
        <OptimizedImage src={details.imageUrl} className="w-full h-64 object-cover" />
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center bg-gradient-to-b from-black/50 to-transparent">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="bg-white/80 backdrop-blur-sm rounded-full">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex gap-2">
            <Button variant="ghost" size="icon" className="bg-white/80 backdrop-blur-sm rounded-full">
              <Share2 className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" className="bg-white/80 backdrop-blur-sm rounded-full">
              <Heart className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        <h1 className="text-3xl font-bold mb-2">{details.title}</h1>
        
        <div className="flex items-center gap-4 mb-4 text-gray-600">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-yellow-500 fill-current" />
            <span className="font-medium">{details.rating || 'New'}</span>
          </div>
          <span className="font-medium">{details.cookName}</span>
        </div>

        <p className="text-gray-700 leading-relaxed mb-6">{details.description}</p>
        
        <div className="flex items-center justify-between bg-gray-50 p-4 rounded-xl">
          <div>
            <span className="text-sm text-gray-600">Price</span>
            <div className="flex items-baseline gap-2">
              <PriceDisplay price={details.price} className="text-black font-bold text-2xl" isFree={details.price === 0} />
              {details.originalPrice && (
                 <PriceDisplay price={details.originalPrice} className="text-gray-400 line-through" />
              )}
            </div>
          </div>
          <QuickAddToCart item={details.item} itemType={details.itemType} size="lg" />
        </div>
      </div>
    </div>
  );
};

export default ServiceDetailPage;