import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Check, ShoppingCart } from 'lucide-react';
import { cartStore } from '../stores/CartStore';
import { showToast } from './ErrorBoundary';
import { PriceDisplay } from '../utils/dd_currency';

export default function AddToCartButton({ 
  item, 
  itemType = 'dish',
  className = "",
  variant = "default",
  size = "default",
  showPrice = false,
  disabled = false
}) {
  const [isAdding, setIsAdding] = useState(false);
  const [justAdded, setJustAdded] = useState(false);

  const handleAddToCart = async (e) => {
    e.stopPropagation(); // Prevent navigation when clicking the button
    
    if (disabled || isAdding) return;

    setIsAdding(true);
    
    try {
      cartStore.addItem(item, 1, itemType);
      
      const itemName = item.name || item.title || item.food_title || item.product_title || item.service_title || item.item_title;
      showToast(`${itemName} נוסף לעגלה!`, 'success');
      
      setJustAdded(true);
      setTimeout(() => setJustAdded(false), 2000);
      
    } catch (error) {
      console.error('Error adding to cart:', error);
      showToast('שגיאה בהוספה לעגלה', 'error');
    }
    
    setIsAdding(false);
  };

  const getPrice = () => {
    return item.price || item.discounted_price || item.price_per_week || 0;
  };

  const isGiveaway = itemType === 'giveaway' || getPrice() === 0;

  if (isGiveaway) {
    return (
      <Button
        onClick={handleAddToCart}
        disabled={disabled || isAdding || item.is_claimed}
        variant={justAdded ? "default" : "outline"}
        size={size}
        className={`${className} ${justAdded ? 'bg-green-500 hover:bg-green-600' : 'border-green-500 text-green-600 hover:bg-green-50'}`}
      >
        {isAdding ? (
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current" />
        ) : justAdded ? (
          <>
            <Check className="w-4 h-4 mr-2" />
            נוסף!
          </>
        ) : item.is_claimed ? (
          'נתפס'
        ) : (
          <>
            <Plus className="w-4 h-4 mr-2" />
            תפוס חינם
          </>
        )}
      </Button>
    );
  }

  return (
    <Button
      onClick={handleAddToCart}
      disabled={disabled || isAdding}
      variant={justAdded ? "default" : variant}
      size={size}
      className={`${className} ${justAdded ? 'bg-green-500 hover:bg-green-600' : ''}`}
    >
      {isAdding ? (
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current" />
      ) : justAdded ? (
        <>
          <Check className="w-4 h-4 mr-2" />
          נוסף!
        </>
      ) : (
        <>
          <ShoppingCart className="w-4 h-4 mr-2" />
          {showPrice && <PriceDisplay price={getPrice()} className="ml-1" />}
          {!showPrice && 'הוסף לעגלה'}
        </>
      )}
    </Button>
  );
}