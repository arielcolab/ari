import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, SlidersHorizontal } from 'lucide-react';
import { useTranslation } from '../utils/translations';
import FilterModal from './FilterModal';
import SortModal from './SortModal';
import ItemCard from './ItemCard';
import { SkeletonList } from './LoadingStates';

const ServiceListPage = ({ 
  entity, 
  itemType, 
  title, 
  subtitle, 
  filterOptions = [], 
  sortOptions = [],
  showBackButton = true 
}) => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [showFilters, setShowFilters] = useState(false);
  const [showSort, setShowSort] = useState(false);
  const [filters, setFilters] = useState({});
  const [sortBy, setSortBy] = useState('newest');
  const [activeFilterCount, setActiveFilterCount] = useState(0);
  const [items, setItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadItems = async () => {
      setIsLoading(true);
      setError(null);
      
      try {
        const fetchedItems = await entity.list();
        setItems(fetchedItems || []);
      } catch (err) {
        console.error('Data fetching error:', err);
        setError(err.message || 'Failed to load items.');
      } finally {
        setIsLoading(false);
      }
    };

    loadItems();
  }, [entity]);

  // Filter and sort items
  const processedItems = (items || [])
    .filter(item => {
      if (!item) return false;
      
      // Apply filters
      for (const [key, value] of Object.entries(filters)) {
        if (!value) continue;
        
        if (Array.isArray(value) && value.length > 0) {
          if (key === 'category' && !value.includes(item.category)) return false;
          if (key === 'cuisine_types' && !value.some(v => item.cuisine_types?.includes(v))) return false;
          if (key === 'allergens' && value.some(v => item.allergens?.includes(v))) return false;
        } else if (typeof value === 'string') {
          if (key === 'price_range') {
            const price = item.price || item.discounted_price || 0;
            if (value === 'under_20' && price >= 20) return false;
            if (value === '20_50' && (price < 20 || price > 50)) return false;
            if (value === 'over_50' && price <= 50) return false;
          }
        }
      }
      return true;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'price_low': return (a.price || a.discounted_price || 0) - (b.price || b.discounted_price || 0);
        case 'price_high': return (b.price || b.discounted_price || 0) - (a.price || a.discounted_price || 0);
        case 'rating': return (b.rating_average || 0) - (a.rating_average || 0);
        case 'distance': return (a.distance || 0) - (b.distance || 0);
        case 'newest': 
          const dateA = a.created_date || a.available_until || 0;
          const dateB = b.created_date || b.available_until || 0;
          return new Date(dateB) - new Date(dateA);
        default: return 0;
      }
    });

  const handleFilterApply = (newFilters) => {
    setFilters(newFilters);
    const count = Object.values(newFilters).filter(v => 
      v !== null && v !== '' && (!Array.isArray(v) || v.length > 0)
    ).length;
    setActiveFilterCount(count);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 px-4 py-3 sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            {showBackButton && (
              <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="flex-shrink-0">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            )}
            <div className="min-w-0 flex-1">
              <h1 className="text-lg font-bold text-gray-900 truncate">{title}</h1>
              {subtitle && <p className="text-sm text-gray-600 truncate">{subtitle}</p>}
            </div>
          </div>
          
          {/* Controls - Responsive */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {filterOptions.length > 0 && (
              <Button 
                variant="outline" 
                size="sm"
                className="rounded-full relative"
                onClick={() => setShowFilters(true)}
              >
                <SlidersHorizontal className="w-4 h-4 mr-2" />
                {t('filters', 'Filters')}
                {activeFilterCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                    {activeFilterCount}
                  </span>
                )}
              </Button>
            )}
            {sortOptions.length > 0 && (
              <Button 
                variant="outline" 
                size="sm"
                className="rounded-full"
                onClick={() => setShowSort(true)}
              >
                {t('sort', 'Sort')}
              </Button>
            )}
          </div>
        </div>
      </div>
      
      {/* Content */}
      <div className="p-4">
        {isLoading ? (
          <SkeletonList />
        ) : error ? (
          <div className="text-center py-10">
            <p className="text-red-500">{t('error_loading_services', 'Error loading services')}</p>
            <p className="text-gray-500">{t('please_try_again_later', 'Please try again later.')}</p>
          </div>
        ) : processedItems.length === 0 ? (
          <div className="text-center py-10">
            <p className="text-gray-800 font-medium">{t('no_items_found', 'No items match your criteria.')}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {processedItems.map(item => (
              <ItemCard key={item.id} item={item} itemType={itemType} />
            ))}
          </div>
        )}
      </div>

      {/* Modals */}
      <FilterModal 
        isOpen={showFilters} 
        onClose={() => setShowFilters(false)} 
        onApply={handleFilterApply}
        initialFilters={filters}
        filterOptions={filterOptions}
      />
      <SortModal
        isOpen={showSort}
        onClose={() => setShowSort(false)}
        onApply={setSortBy}
        currentSort={sortBy}
        sortOptions={sortOptions}
      />
    </div>
  );
};

export default ServiceListPage;