import React from 'react';
import { Button } from '@/components/ui/button';
import { AlertTriangle, RefreshCw, Home, Wifi } from 'lucide-react';
import { useTranslation } from '../utils/translations';
import { createPageUrl } from '@/utils';
import { useNavigate } from 'react-router-dom';

class ErrorBoundaryInner extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      hasError: false, 
      error: null, 
      errorInfo: null,
      retryCount: 0 
    };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('App Error Boundary:', error, errorInfo);
    this.setState({ errorInfo });
    
    // Report to error tracking service in production
    if (typeof window !== 'undefined' && window.location.hostname !== 'localhost') {
      // Analytics or error reporting would go here
    }
  }

  handleRetry = () => {
    this.setState(prevState => ({
      hasError: false,
      error: null,
      errorInfo: null,
      retryCount: prevState.retryCount + 1
    }));
    
    // Force page reload if retry count is high
    if (this.state.retryCount > 2) {
      window.location.reload();
    }
  };

  render() {
    const { t, navigate } = this.props;

    if (this.state.hasError) {
      const isNetworkError = this.state.error?.message?.includes('fetch') || 
                            this.state.error?.message?.includes('network') ||
                            this.state.error?.code === 'ERR_NETWORK';

      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center max-w-md w-full">
            <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
              {isNetworkError ? (
                <Wifi className="w-8 h-8 text-red-500" />
              ) : (
                <AlertTriangle className="w-8 h-8 text-red-500" />
              )}
            </div>
            
            <h2 className="text-xl font-bold text-gray-900 mb-3">
              {isNetworkError ? 
                t('networkError', 'Connection Error') : 
                t('somethingWentWrong', 'Something went wrong')
              }
            </h2>
            
            <p className="text-gray-600 mb-8 leading-relaxed">
              {isNetworkError 
                ? t('networkErrorDescription', 'Please check your internet connection and try again.')
                : t('somethingWentWrongDescription', "We're sorry, but something unexpected happened. Please try again.")
              }
            </p>
            
            <div className="flex flex-col gap-3">
              <Button
                onClick={this.handleRetry}
                className="bg-red-500 hover:bg-red-600 text-white flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                {this.state.retryCount > 2 ? t('reloadApp', 'Reload App') : t('retry', 'Try Again')}
              </Button>
              
              <Button
                variant="outline"
                onClick={() => window.location.href = createPageUrl('Home')}
                className="flex items-center justify-center gap-2"
              >
                <Home className="w-4 h-4" />
                {t('goHome', 'Go to Home')}
              </Button>
            </div>
            
            {this.state.retryCount > 2 && (
              <p className="text-xs text-gray-500 mt-6">
                {t('persistentError', 'If this problem persists, please contact support.')}
              </p>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export const ErrorBoundary = (props) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  return <ErrorBoundaryInner {...props} t={t} navigate={navigate} />;
};

// Enhanced toast notifications with consistent design
export const showToast = (message, type = 'success', duration = 3000) => {
  // Remove existing toasts
  const existingToasts = document.querySelectorAll('.custom-toast');
  existingToasts.forEach(toast => toast.remove());

  const toast = document.createElement('div');
  toast.className = `custom-toast fixed top-4 left-1/2 transform -translate-x-1/2 z-50 px-6 py-3 rounded-2xl shadow-lg font-medium transition-all duration-300 ${
    type === 'success' ? 'bg-green-50 text-green-800 border border-green-200' : 
    type === 'error' ? 'bg-red-50 text-red-800 border border-red-200' :
    'bg-blue-50 text-blue-800 border border-blue-200'
  }`;
  
  toast.textContent = message;
  toast.style.transform = 'translate(-50%, -100px)';
  toast.style.opacity = '0';

  document.body.appendChild(toast);

  // Animate in
  requestAnimationFrame(() => {
    toast.style.transform = 'translate(-50%, 0)';
    toast.style.opacity = '1';
  });

  // Animate out and remove
  setTimeout(() => {
    toast.style.transform = 'translate(-50%, -100px)';
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, duration);
};

// Network error handler
export const handleNetworkError = (error, showFallback = true) => {
  console.error('Network error:', error);
  
  if (error?.code === 'ERR_NETWORK' || error?.message?.includes('fetch')) {
    showToast('Connection error. Please check your internet.', 'error');
  } else if (error?.response?.status === 404) {
    showToast('Content not found.', 'error');
  } else if (error?.response?.status >= 500) {
    showToast('Server error. Please try again later.', 'error');
  } else if (error?.response?.status === 429) {
    showToast('Too many requests. Please wait a moment.', 'error');
  } else if (showFallback) {
    showToast('Something went wrong. Please try again.', 'error');
  }
};