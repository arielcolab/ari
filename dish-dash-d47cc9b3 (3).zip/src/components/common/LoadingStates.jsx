import React from 'react';
import { useTranslation } from '../utils/translations';

// Skeleton loading components that match the minimalist aesthetic
export const SkeletonCard = ({ className = "" }) => (
  <div className={`bg-white rounded-2xl overflow-hidden shadow-sm ${className}`}>
    <div className="animate-pulse">
      <div className="bg-gray-100 aspect-square"></div>
      <div className="p-4">
        <div className="h-4 bg-gray-100 rounded-full mb-2"></div>
        <div className="h-3 bg-gray-100 rounded-full w-2/3"></div>
      </div>
    </div>
  </div>
);

export const SkeletonList = ({ count = 6 }) => (
  <div className="grid grid-cols-2 gap-3">
    {Array(count).fill().map((_, i) => (
      <SkeletonCard key={i} />
    ))}
  </div>
);

export const SkeletonText = ({ lines = 3, className = "" }) => (
  <div className={`animate-pulse space-y-2 ${className}`}>
    {Array(lines).fill().map((_, i) => (
      <div 
        key={i} 
        className="h-3 bg-gray-100 rounded-full"
        style={{ width: i === lines - 1 ? '60%' : '100%' }}
      />
    ))}
  </div>
);

export const SkeletonHeader = () => (
  <div className="animate-pulse">
    <div className="h-6 bg-gray-100 rounded-full w-48 mb-2"></div>
    <div className="h-3 bg-gray-100 rounded-full w-32"></div>
  </div>
);

// Minimal loading spinner for actions
export const LoadingSpinner = ({ size = "md", className = "" }) => {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-6 h-6", 
    lg: "w-8 h-8"
  };
  
  return (
    <div className={`animate-spin rounded-full border-2 border-gray-200 border-t-red-500 ${sizeClasses[size]} ${className}`} />
  );
};

// Subtle loading overlay
export const LoadingOverlay = ({ children, isLoading }) => {
  const { t } = useTranslation();
  
  if (!isLoading) return children;
  
  return (
    <div className="relative">
      {children}
      <div className="absolute inset-0 bg-white/70 backdrop-blur-sm flex items-center justify-center z-10">
        <div className="flex flex-col items-center gap-3">
          <LoadingSpinner size="lg" />
          <p className="text-sm text-gray-600">{t('loading', 'Loading...')}</p>
        </div>
      </div>
    </div>
  );
};