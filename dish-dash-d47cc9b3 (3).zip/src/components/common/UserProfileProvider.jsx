import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { ProfileManager } from '../utils/ProfileManager';

const UserProfileContext = createContext();

export const useUserProfile = () => {
  const context = useContext(UserProfileContext);
  if (!context) {
    throw new Error('useUserProfile must be used within UserProfileProvider');
  }
  return context;
};

export const UserProfileProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUserAndProfile();
  }, []);

  const loadUserAndProfile = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData) {
        // Automatically ensure profile exists
        const userProfile = await ProfileManager.ensureUserProfile(userData);
        setProfile(userProfile);
      }
    } catch (error) {
      // User not logged in or other error
      setUser(null);
      setProfile(null);
    }
    setLoading(false);
  };

  const updateProfile = async (updates) => {
    if (!user) {
      throw new Error('Must be logged in to update profile');
    }
    
    try {
      // Use the secure update method that checks permissions
      const updatedProfile = await ProfileManager.updateCurrentUserProfile(updates);
      setProfile(updatedProfile);
      return updatedProfile;
    } catch (error) {
      console.error('Failed to update profile:', error);
      throw error;
    }
  };

  const refreshProfile = () => {
    loadUserAndProfile();
  };

  // Public methods for reading other profiles
  const getProfileByUserId = (userId) => {
    return ProfileManager.getProfileByUserId(userId);
  };

  const getAllProfiles = (sortBy, limit) => {
    return ProfileManager.getAllProfiles(sortBy, limit);
  };

  const searchProfiles = (query) => {
    return ProfileManager.searchProfiles(query);
  };

  return (
    <UserProfileContext.Provider value={{
      // Current user data
      user,
      profile,
      loading,
      
      // Protected methods (only for current user)
      updateProfile,
      refreshProfile,
      
      // Public methods (can read any profile)
      getProfileByUserId,
      getAllProfiles,
      searchProfiles,
      
      // Utility
      ensureProfile: () => ProfileManager.ensureUserProfile(user)
    }}>
      {children}
    </UserProfileContext.Provider>
  );
};