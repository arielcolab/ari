import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { useTranslation } from '../utils/translations';
import { Badge } from '@/components/ui/badge';

const FilterModal = ({ isOpen, onClose, onApply, initialFilters, filterOptions }) => {
  const { t } = useTranslation();
  const [filters, setFilters] = useState(initialFilters || {});

  if (!isOpen) return null;

  const handleToggle = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: prev[key] === value ? null : value,
    }));
  };
  
  const handleMultiSelectToggle = (key, value) => {
    const currentValues = filters[key] || [];
    const newValues = currentValues.includes(value)
        ? currentValues.filter(v => v !== value)
        : [...currentValues, value];
    setFilters(prev => ({ ...prev, [key]: newValues }));
  };

  const handleClear = () => {
    setFilters({});
    onApply({});
    onClose();
  };
  
  const handleApply = () => {
    onApply(filters);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60" onClick={onClose}>
      <div 
        className="fixed bottom-0 left-0 right-0 bg-white rounded-t-3xl p-4 max-h-[85vh] overflow-y-auto" 
        onClick={e => e.stopPropagation()}
      >
        {/* Header - Mobile Optimized */}
        <div className="flex items-center justify-between mb-6 pb-4 border-b">
          <Button variant="ghost" onClick={handleClear} className="text-red-500 px-0">
            {t('clearFilters', 'Clear')}
          </Button>
          <h2 className="text-xl font-bold">{t('filters', 'Filters')}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-6 h-6" />
          </Button>
        </div>

        {/* Filter Options - Mobile Optimized */}
        <div className="space-y-6">
          {filterOptions.map(option => (
            <div key={option.key}>
              <h3 className="font-bold text-lg mb-3">{t(option.label, option.label)}</h3>
              <div className="flex flex-wrap gap-2">
                {option.values.map(val => {
                  const isSelected = option.type === 'multi' 
                    ? (filters[option.key] || []).includes(val.value)
                    : filters[option.key] === val.value;
                    
                  return (
                    <Button
                      key={val.value}
                      variant={isSelected ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => option.type === 'multi' 
                        ? handleMultiSelectToggle(option.key, val.value) 
                        : handleToggle(option.key, val.value)
                      }
                      className={`rounded-full px-3 py-1 text-sm ${
                        isSelected 
                          ? 'bg-red-600 text-white border-red-600' 
                          : 'border-gray-300 text-gray-700 hover:border-red-600'
                      }`}
                    >
                      {t(val.label, val.label)}
                    </Button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
        
        {/* Apply Button - Mobile Optimized */}
        <div className="sticky bottom-0 bg-white pt-4 pb-2 mt-6 border-t">
          <Button 
            onClick={handleApply} 
            className="w-full bg-red-600 hover:bg-red-700 h-12 text-lg rounded-xl"
          >
            {t('apply', 'Apply Filters')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FilterModal;