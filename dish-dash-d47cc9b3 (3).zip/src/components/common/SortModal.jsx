import React from 'react';
import { Button } from '@/components/ui/button';
import { X, Check } from 'lucide-react';
import { useTranslation } from '../utils/translations';

const SortModal = ({ isOpen, onClose, onApply, currentSort, sortOptions }) => {
  const { t } = useTranslation();

  if (!isOpen) return null;

  const defaultSortOptions = [
    { value: 'newest', label: t('newest', 'Newest') },
    { value: 'price_low', label: t('lowestPrice', 'Price: Low to High') },
    { value: 'price_high', label: t('highestPrice', 'Price: High to Low') },
    { value: 'rating', label: t('highestRating', 'Highest Rated') },
    { value: 'distance', label: t('nearest', 'Nearest') }
  ];

  const options = sortOptions.length > 0 ? sortOptions : defaultSortOptions;

  const handleSelect = (value) => {
    onApply(value);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60" onClick={onClose}>
      <div 
        className="fixed bottom-0 left-0 right-0 bg-white rounded-t-3xl p-4 max-h-[70vh] overflow-y-auto" 
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6 pb-4 border-b">
          <h2 className="text-xl font-bold">{t('sortBy', 'Sort By')}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-6 h-6" />
          </Button>
        </div>

        {/* Sort Options */}
        <div className="space-y-2">
          {options.map(option => (
            <button
              key={option.value}
              onClick={() => handleSelect(option.value)}
              className={`w-full flex items-center justify-between p-4 rounded-xl transition-colors ${
                currentSort === option.value
                  ? 'bg-red-50 border-2 border-red-200'
                  : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
              }`}
            >
              <span className={`font-medium ${
                currentSort === option.value ? 'text-red-600' : 'text-gray-900'
              }`}>
                {option.label}
              </span>
              {currentSort === option.value && (
                <Check className="w-5 h-5 text-red-600" />
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SortModal;