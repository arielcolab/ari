import React from 'react';
import { Button } from "@/components/ui/button";
import { SlidersHorizontal, ArrowUpDown } from "lucide-react";

const FilterButtons = ({ onFiltersClick, onSortClick }) => {
  return (
    <div className="flex gap-2">
      <Button 
        variant="outline" 
        size="sm" 
        className="rounded-full bg-gray-100 border-gray-200 hover:bg-gray-200"
        onClick={onFiltersClick}
      >
        <SlidersHorizontal className="w-4 h-4 mr-1" />
        Filters
      </Button>
      <Button 
        variant="outline" 
        size="sm" 
        className="rounded-full bg-gray-100 border-gray-200 hover:bg-gray-200"
        onClick={onSortClick}
      >
        <ArrowUpDown className="w-4 h-4 mr-1" />
        Sort
      </Button>
    </div>
  );
};

export default FilterButtons;