import React from 'react';
import { Badge } from "@/components/ui/badge";

const CategoryChip = ({ title, subtitle, image, isActive, onClick }) => (
  <div 
    className={`flex-shrink-0 cursor-pointer transition-all ${
      isActive ? 'opacity-100' : 'opacity-70 hover:opacity-90'
    }`}
    onClick={onClick}
  >
    <div className="w-20 h-20 rounded-2xl overflow-hidden mb-2" style={{ backgroundColor: image?.bgColor || '#f3f4f6' }}>
      {image?.url ? (
        <img src={image.url} alt={title} className="w-full h-full object-cover" />
      ) : (
        <div className="w-full h-full flex items-center justify-center text-2xl">
          {image?.emoji || '🏠'}
        </div>
      )}
    </div>
    <div className="text-center">
      <p className="text-sm font-semibold text-gray-900">{title}</p>
      <p className="text-xs text-gray-500">{subtitle}</p>
    </div>
  </div>
);

const CategoryChips = ({ categories, activeCategory, onCategoryChange }) => {
  return (
    <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
      {categories.map((category, index) => (
        <CategoryChip
          key={index}
          title={category.title}
          subtitle={category.subtitle}
          image={category.image}
          isActive={activeCategory === index}
          onClick={() => onCategoryChange(index)}
        />
      ))}
    </div>
  );
};

export default CategoryChips;