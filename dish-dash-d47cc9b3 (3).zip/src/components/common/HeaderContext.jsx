import React, { createContext, useState, useContext } from 'react';

// 1. Create the context
const HeaderContext = createContext();

// 2. Create the provider component
export const HeaderProvider = ({ children }) => {
  const [headerControls, setHeaderControls] = useState({});

  // This function will be passed to pages to let them set controls
  const setControls = (controls) => {
    setHeaderControls(controls);
  };
  
  const value = {
    headerControls,
    setHeaderControls: setControls,
  };

  return (
    <HeaderContext.Provider value={value}>
      {children}
    </HeaderContext.Provider>
  );
};

// 3. Create a custom hook for easy access
export const useHeader = () => {
  const context = useContext(HeaderContext);
  if (context === undefined) {
    throw new Error('useHeader must be used within a HeaderProvider');
  }
  return context;
};