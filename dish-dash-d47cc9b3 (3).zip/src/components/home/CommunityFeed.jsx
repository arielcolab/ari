import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Activity } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { MessageSquare, Heart, Star, PlusCircle, ChefHat } from 'lucide-react';
import OptimizedImage from '../dd_OptimizedImage';
import { createPageUrl } from '@/utils';
import { formatDistanceToNow } from 'date-fns';
import { he } from 'date-fns/locale';

const ActivityCard = ({ activity }) => {
  const navigate = useNavigate();
  
  const ICONS = {
    new_dish: <PlusCircle className="w-5 h-5 text-green-500" />,
    trending_dish: <Heart className="w-5 h-5 text-red-500" />,
    review: <Star className="w-5 h-5 text-yellow-500" />,
    follow: <ChefHat className="w-5 h-5 text-blue-500" />,
    platform_announcement: <MessageSquare className="w-5 h-5 text-indigo-500" />
  };

  const handleNavigation = () => {
    if (activity.related_dish_id) {
      navigate(createPageUrl(`DishDetails?id=${activity.related_dish_id}`));
    } else if (activity.related_user_id) {
      navigate(createPageUrl(`CookProfile?id=${activity.related_user_id}`));
    }
  };

  return (
    <div 
      className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
      onClick={handleNavigation}
    >
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
          {activity.icon_url ? (
            <OptimizedImage src={activity.icon_url} className="w-full h-full rounded-full object-cover" />
          ) : (
            ICONS[activity.activity_type] || <MessageSquare className="w-5 h-5 text-gray-500" />
          )}
        </div>
        <div className="flex-1">
          <p className="font-semibold text-gray-900">{activity.title}</p>
          <p className="text-sm text-gray-600 mt-1">{activity.description}</p>
          <p className="text-xs text-gray-400 mt-2">
            {formatDistanceToNow(new Date(activity.created_date), { addSuffix: true, locale: he })}
          </p>
        </div>
      </div>
    </div>
  );
};

export default function CommunityFeed() {
  const [activities, setActivities] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadActivities();
  }, []);

  const loadActivities = async () => {
    setIsLoading(true);
    try {
      const data = await Activity.list('-created_date', 30);
      setActivities(data);
    } catch (error) {
      console.error("Failed to load community activities:", error);
    }
    setIsLoading(false);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-10">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-500"></div>
      </div>
    );
  }

  if (activities.length === 0) {
    return <p className="text-center py-10 text-gray-500">הפיד הקהילתי ריק כרגע.</p>;
  }

  return (
    <div className="space-y-4 py-6">
      {activities.map(activity => (
        <ActivityCard key={activity.id} activity={activity} />
      ))}
    </div>
  );
}