import React from 'react';
import OptimizedImage from '../dd_OptimizedImage';

const NewHeroHeader = () => {
  // Using the image provided by the user for the new hero section
  const heroImageUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/da3355a40_IMG_9054.jpg";
  
  return (
    <div className="relative w-full rounded-2xl overflow-hidden shadow-lg mb-6">
      <OptimizedImage
        src={heroImageUrl}
        alt="DishDash Hero"
        className="w-full h-auto object-cover"
      />
    </div>
  );
};

export default NewHeroHeader;