import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import OptimizedImage from '../dd_OptimizedImage';

const FeatureTile = ({ image, title, route, badgeCount, badge, className = "" }) => {
  const navigate = useNavigate();

  const handlePress = () => {
    navigate(createPageUrl(route));
  };

  return (
    <div 
      onClick={handlePress}
      className={`relative bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer group ${className}`}
    >
      <div className="aspect-square relative">
        <OptimizedImage
          src={image}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        
        {/* Badge count indicator */}
        {badgeCount > 0 && (
          <div className="absolute top-3 right-3 bg-red-600 text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center">
            {badgeCount}
          </div>
        )}
        
        {/* Revenue Priority Badge */}
        {badge && (
          <div className="absolute top-3 left-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-xs font-bold rounded-full px-2 py-1 shadow-lg">
            {badge}
          </div>
        )}
        
        {/* Updated overlay with better text handling */}
        <div className="absolute bottom-0 left-0 right-0 pt-8 pb-3 px-3 bg-gradient-to-t from-black/80 to-transparent rounded-b-2xl">
          <h3 className="text-white font-bold text-base leading-tight drop-shadow-lg break-words hyphens-auto">
            {title}
          </h3>
        </div>
      </div>
    </div>
  );
};

export default FeatureTile;