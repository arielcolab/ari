import React from 'react';
import { useNavigate } from 'react-router-dom';
import OptimizedImage from '../dd_OptimizedImage';
import { PriceDisplay } from '../utils/dd_currency';
import RatingDisplay from '../reviews/RatingDisplay';
import { createPageUrl } from '@/utils';
import { useTranslation } from '../utils/translations';
import { Badge } from '@/components/ui/badge';

const ServiceCard = ({ service }) => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  if (!service) return null;

  return (
    <div
      onClick={() => navigate(createPageUrl(`MealPrepDetails?id=${service.id}`))}
      className="bg-white rounded-2xl shadow-sm overflow-hidden cursor-pointer hover:shadow-md transition-shadow duration-200"
    >
      <OptimizedImage
        src={service.photo_url}
        alt={service.service_title}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
            {service.cuisine_types?.map(tag => (
                <Badge key={tag} variant="secondary" className="text-xs">{t(tag, tag)}</Badge>
            ))}
        </div>
        <h3 className="font-bold text-lg text-gray-900 truncate">{service.service_title}</h3>
        <p className="text-sm text-gray-600 mb-3">{t('by')} {service.cook_name}</p>
        <div className="flex justify-between items-center">
          <RatingDisplay rating={service.rating_average} reviewCount={service.rating_count} size="sm" />
          <div className="text-right">
            <PriceDisplay price={service.price_per_week} className="text-lg font-bold" />
            <p className="text-xs text-gray-500">/ {t('week', 'week')}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;