
import React from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useTranslation } from "../utils/translations";
import { PriceDisplay } from "../utils/dd_currency";
import OptimizedImage from "../dd_OptimizedImage";
import RatingDisplay from "../reviews/RatingDisplay";
import { Clock, MapPin, Users, Verified, AlertTriangle, Gift } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import QuickAddToCart from '../common/QuickAddToCart';

export default function DishCard({ dish, onClick, showDistance = false, variant = 'default' }) {
  const navigate = useNavigate();
  const { t } = useTranslation();

  const handleCardClick = () => {
    navigate(createPageUrl(`DishDetails?id=${dish.id}`));
  };

  const getTimeLeft = (expiryDate) => {
    if (!expiryDate) return null;
    const now = new Date();
    const expiry = new Date(expiryDate);
    const diffMs = expiry - now;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffDays > 0) return `${diffDays} ${t('daysLeft')}`;
    if (diffHours > 0) return `${diffHours} ${t('hoursLeft')}`;
    return `${Math.floor(diffMs / (1000 * 60))} ${t('minutesLeft')}`;
  };

  const getFridgeHours = (fridgeSince) => {
    if (!fridgeSince) return null;
    const now = new Date();
    const fridgeTime = new Date(fridgeSince);
    const diffMs = now - fridgeTime;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    return diffHours;
  };

  const timeLeft = getTimeLeft(dish.expires_at || dish.best_before);
  const fridgeHours = getFridgeHours(dish.fridge_since);
  const mainPhoto = dish.photo_url || "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&auto=format&fit=crop";

  return (
    <div 
      className={`bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer ${
        variant === 'compact' ? 'h-auto' : 'h-full'
      }`}
    >
      <div onClick={onClick || handleCardClick} className="relative">
        <OptimizedImage
          src={mainPhoto}
          alt={dish.name}
          className={`w-full object-cover ${variant === 'compact' ? 'h-32' : 'h-48'}`}
        />
        
        {/* Badges overlay */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {dish.verified_flag && (
            <Badge className="bg-green-500 text-white text-xs">
              <Verified className="w-3 h-3 mr-1" />
              {t('verified')}
            </Badge>
          )}
          {dish.isChef && (
            <Badge className="bg-blue-500 text-white text-xs">
              {t('professionalChef')}
            </Badge>
          )}
          {dish.is_on_sale && (
            <Badge className="bg-red-500 text-white text-xs">
              {dish.sale_badge || `${dish.sale_percent}% ${t('onSale')}`}
            </Badge>
          )}
          {dish.is_bundle && (
            <Badge className="bg-purple-500 text-white text-xs">
              <Gift className="w-3 h-3 mr-1" />
              {t('bundle')}
            </Badge>
          )}
        </div>

        {/* Time-sensitive badges */}
        <div className="absolute top-2 right-2 flex flex-col gap-1">
          {timeLeft && (
            <Badge className="bg-orange-500 text-white text-xs">
              <Clock className="w-3 h-3 mr-1" />
              {timeLeft}
            </Badge>
          )}
          {fridgeHours !== null && fridgeHours > 0 && (
            <Badge className="bg-blue-100 text-blue-800 text-xs">
              {t('fridgeSince')} {fridgeHours}h
            </Badge>
          )}
        </div>
      </div>

      <div onClick={onClick || handleCardClick} className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-gray-900 line-clamp-1">{dish.name}</h3>
          <div className="text-right">
            <PriceDisplay price={dish.price} className="font-bold text-lg" />
            {dish.is_on_sale && dish.sale_percent && (
              <p className="text-xs text-gray-500 line-through">
                <PriceDisplay price={dish.price / (1 - dish.sale_percent / 100)} />
              </p>
            )}
          </div>
        </div>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{dish.description}</p>

        {/* Status and dietary tags */}
        <div className="flex flex-wrap gap-1 mb-3">
          {dish.made_status && (
            <Badge variant="outline" className="text-xs">
              {t(dish.made_status)}
            </Badge>
          )}
          {dish.diet_tags?.slice(0, 2).map(tag => (
            <Badge key={tag} variant="outline" className="text-xs text-green-700">
              {t(tag)}
            </Badge>
          ))}
        </div>

        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              {dish.servings}
            </span>
            {showDistance && dish.location && (
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {dish.distance ? `${dish.distance}km` : t('pickup')}
              </span>
            )}
          </div>
          
          {dish.rating_average > 0 && (
            <RatingDisplay 
              rating={dish.rating_average} 
              reviewCount={dish.rating_count}
              size="xs"
            />
          )}
        </div>

        <div className="flex items-center justify-between mt-3">
          <span className="text-sm text-gray-600">
            {t('by')} {dish.cook_name || 'Unknown'}
          </span>
          {/* Old Add to Cart button removed */}
        </div>
      </div>

      {/* Quick Add to Cart - Added at bottom */}
      <div className="px-4 pb-4" onClick={(e) => e.stopPropagation()}>
        <QuickAddToCart 
          item={dish} 
          itemType="dish" 
          size="default"
          showPrice={true}
          className="justify-between"
        />
      </div>
    </div>
  );
}
