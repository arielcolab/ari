import React from 'react';
import { Button } from "@/components/ui/button";
import { Plus, Minus } from "lucide-react";

const QuantitySelector = ({ quantity, setQuantity, maxQuantity = 10 }) => {
  const increment = () => {
    if (quantity < maxQuantity) {
      setQuantity(quantity + 1);
    }
  };

  const decrement = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  return (
    <div className="flex items-center gap-2 bg-gray-100 rounded-full">
      <Button 
        size="icon" 
        variant="ghost"
        className="rounded-full"
        onClick={decrement}
        disabled={quantity <= 1}
      >
        <Minus className="w-4 h-4" />
      </Button>
      <span className="font-bold w-6 text-center">{quantity}</span>
      <Button 
        size="icon" 
        variant="ghost"
        className="rounded-full"
        onClick={increment}
        disabled={quantity >= maxQuantity}
      >
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );
};

export default QuantitySelector;