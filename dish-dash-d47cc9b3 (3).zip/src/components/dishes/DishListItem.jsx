import React from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Star, MapPin, Sun } from "lucide-react";
import OptimizedImage from "../dd_OptimizedImage";
import { PriceDisplay } from "../utils/dd_currency";

const DishListItem = ({ dish, onPress }) => {
  const navigate = useNavigate();
  
  const handlePress = () => {
    if (onPress) {
      onPress(dish);
    } else {
      navigate(createPageUrl(`DishDetails?id=${dish.id}`));
    }
  };

  const getImageUrl = () => {
    if (dish.photo_url) return dish.photo_url;
    if (dish.photos && dish.photos.length > 0) return dish.photos[0];
    if (dish.image_url) return dish.image_url;
    return null;
  };

  return (
    <div 
      onClick={handlePress}
      className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer mb-3"
    >
      <div className="flex gap-4">
        <OptimizedImage
          src={getImageUrl()}
          alt={dish.name}
          className="w-24 h-24 rounded-lg object-cover flex-shrink-0"
          fallback="https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=100&h=100&fit=crop&q=80"
        />
        
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-gray-900 truncate">{dish.name}</h3>
          <p className="text-sm text-gray-600 mt-1">
            {dish.cook_name || dish.chef_name || 'Anonymous Cook'}
          </p>
          
          <div className="font-bold text-lg my-1">
            <PriceDisplay price={dish.price} />
          </div>

          <div className="flex items-center gap-3 text-xs text-gray-500">
            <div className="flex items-center gap-1">
              <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
              <span>{dish.rating || 'N/A'}</span>
            </div>
            <div className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              <span>0.3 miles away</span>
            </div>
            {dish.condition && (
              <div className="flex items-center gap-1 bg-gray-100 px-1.5 py-0.5 rounded">
                <Sun className="w-3 h-3" />
                <span>{dish.condition}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DishListItem;