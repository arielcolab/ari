
import React, { useState, useEffect } from 'react';
import { useTranslation } from './utils/translations';

const OptimizedImage = ({ 
  src, 
  alt = 'Image', 
  className = '', 
  fallback = "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=400&fit=crop&q=80",
  showPlaceholder = true,
  ...props 
}) => {
  const { t } = useTranslation();
  const [imgSrc, setImgSrc] = useState(src);
  const [imgError, setImgError] = useState(false);
  const [imgLoading, setImgLoading] = useState(true);

  useEffect(() => {
    setImgSrc(src);
    setImgError(false);
    setImgLoading(true);
  }, [src]);

  const handleImageLoad = () => {
    setImgLoading(false);
    setImgError(false);
  };

  const handleImageError = () => {
    if (imgSrc !== fallback) {
      // Try fallback image first
      setImgSrc(fallback);
    } else {
      // Fallback also failed, show placeholder
      setImgError(true);
      setImgLoading(false);
    }
  };

  // If no src provided or both original and fallback failed, show placeholder
  if (!src || imgError) {
    if (!showPlaceholder) {
      return null;
    }
    
    return (
      <div 
        className={`bg-gray-100 flex items-center justify-center ${className}`}
        style={{ minHeight: '80px', minWidth: '80px' }}
      >
        <div className="text-gray-400 text-center p-2">
          <svg className="w-6 h-6 mx-auto mb-1" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
          </svg>
          <span className="text-xs">{t('noImage', 'No Image')}</span>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      {imgLoading && (
        <div className="absolute inset-0 bg-gray-100 animate-pulse flex items-center justify-center">
          <div className="text-gray-400 text-sm">{t('loading', 'Loading...')}</div>
        </div>
      )}
      <img
        src={imgSrc}
        alt={alt}
        className={`${className} ${imgLoading ? 'opacity-0' : 'opacity-100'} transition-opacity duration-300`}
        onLoad={handleImageLoad}
        onError={handleImageError}
        loading="lazy"
        {...props}
      />
    </div>
  );
};

export default OptimizedImage;
