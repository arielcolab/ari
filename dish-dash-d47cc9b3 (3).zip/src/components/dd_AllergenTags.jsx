import React from 'react';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle } from 'lucide-react';
import { FeatureFlag } from './dd_FeatureFlag';

const allergenInfo = {
  gluten: { label: 'Gluten', color: 'bg-orange-100 text-orange-800' },
  dairy: { label: 'Dairy', color: 'bg-blue-100 text-blue-800' },
  nuts: { label: 'Nuts', color: 'bg-red-100 text-red-800' },
  eggs: { label: 'Eggs', color: 'bg-yellow-100 text-yellow-800' },
  soy: { label: 'Soy', color: 'bg-green-100 text-green-800' },
  shellfish: { label: 'Shellfish', color: 'bg-purple-100 text-purple-800' },
  fish: { label: 'Fish', color: 'bg-cyan-100 text-cyan-800' },
  sesame: { label: 'Sesame', color: 'bg-amber-100 text-amber-800' }
};

export const AllergenTags = ({ allergens = [], className = "" }) => {
  if (!allergens || allergens.length === 0) return null;

  return (
    <FeatureFlag flag="ff_safe_mode">
      <div className={`flex flex-wrap gap-1 ${className}`}>
        {allergens.map(allergen => {
          const info = allergenInfo[allergen] || { label: allergen, color: 'bg-gray-100 text-gray-800' };
          return (
            <Badge key={allergen} className={`${info.color} text-xs`}>
              <AlertTriangle className="w-3 h-3 mr-1" />
              {info.label}
            </Badge>
          );
        })}
      </div>
    </FeatureFlag>
  );
};

export const AllergenSelector = ({ selectedAllergens = [], onSelectionChange, required = false }) => {
  const handleToggle = (allergen) => {
    const newSelection = selectedAllergens.includes(allergen)
      ? selectedAllergens.filter(a => a !== allergen)
      : [...selectedAllergens, allergen];
    onSelectionChange(newSelection);
  };

  return (
    <FeatureFlag flag="ff_safe_mode">
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-orange-500" />
          <label className="font-medium text-gray-900">
            Allergens {required && <span className="text-red-500">*</span>}
          </label>
        </div>
        <p className="text-sm text-gray-600">
          Select all allergens present in this dish. This helps keep our community safe.
        </p>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(allergenInfo).map(([key, info]) => (
            <button
              key={key}
              type="button"
              onClick={() => handleToggle(key)}
              className={`p-3 rounded-lg border-2 text-left transition-colors ${
                selectedAllergens.includes(key)
                  ? 'border-red-500 bg-red-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center gap-2">
                <div className={`w-4 h-4 rounded border-2 ${
                  selectedAllergens.includes(key)
                    ? 'bg-red-500 border-red-500'
                    : 'border-gray-300'
                }`}>
                  {selectedAllergens.includes(key) && (
                    <div className="w-full h-full flex items-center justify-center text-white text-xs">✓</div>
                  )}
                </div>
                <span className="font-medium">{info.label}</span>
              </div>
            </button>
          ))}
        </div>
        {selectedAllergens.length === 0 && (
          <button
            type="button"
            onClick={() => onSelectionChange([])}
            className="w-full p-3 rounded-lg border-2 border-green-500 bg-green-50 text-green-800 font-medium"
          >
            ✓ No allergens present
          </button>
        )}
      </div>
    </FeatureFlag>
  );
};

export default AllergenTags;