
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils'; // Kept as per original file, though not directly used in new navigation logic
import { useTranslation } from '../utils/translations';
import { PriceDisplay } from '../utils/dd_currency';
import { X } from 'lucide-react'; // Assuming X icon is from lucide-react
import { useToast } from '@/components/ui/use-toast'; // Assuming useToast hook from shadcn/ui

export default function CheckoutButton({
  total,
  itemCount,
  disabled = false,
  onCheckout, // This prop is included in the outline but not explicitly used in the provided logic
  subtotal = 0,
  promoAmount = 0,
  serviceFee = 0,
  processingFee = 0,
  deliveryFee = 0,
  tax = 0,
}) {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { toast } = useToast();

  const [showBreakdown, setShowBreakdown] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const OrderSummaryRow = ({ label, value, isTotal = false, isPromo = false }) => (
    <div className={`flex justify-between ${isTotal ? 'text-lg font-bold border-t border-gray-200 pt-3' : 'text-gray-600'} ${isPromo ? 'text-green-600' : ''}`}>
      <span>{label}</span>
      <span className={isTotal ? 'text-black' : ''}>{value}</span>
    </div>
  );

  const handleEnhancedCheckout = async () => {
    setIsProcessing(true);
    try {
      // Navigate to enhanced checkout flow instead of direct payment
      navigate('/EnhancedCheckout');
      // If onCheckout was intended to run additional logic before navigation, it would be called here.
      // Example: if (onCheckout) await onCheckout();
    } catch (error) {
      console.error('Checkout navigation error:', error);
      toast({
        title: t('checkoutErrorTitle', 'Checkout Error'),
        description: t('failedToProceedToCheckout', 'Failed to proceed to checkout'),
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <>
      {/* Bottom Checkout Section */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 z-50">
        <div className="space-y-3">
          {/* Show Items Button */}
          <Button
            onClick={() => setShowBreakdown(!showBreakdown)}
            disabled={disabled || isProcessing} // Disable if overall component is disabled or processing
            variant="outline"
            className="w-full bg-blue-500 text-white border-blue-500 hover:bg-blue-600 h-12 text-lg rounded-xl flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <span className="bg-white text-blue-500 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                {itemCount}
              </span>
              <span>{t('showItems', 'Show items')}</span>
            </div>
            <PriceDisplay price={total} className="text-white font-bold" />
          </Button>

          {/* Service Fee Notice */}
          <p className="text-center text-sm text-gray-500">
            {t('estimatedServiceFee', 'Estimated service fee')} <PriceDisplay price={serviceFee} />
          </p>
        </div>
      </div>

      {/* Order Breakdown Modal */}
      {showBreakdown && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-end" onClick={() => setShowBreakdown(false)}>
          <div
            className="fixed bottom-0 left-0 right-0 bg-white rounded-t-3xl p-6 max-h-[80vh] overflow-y-auto w-full"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">{t('orderSummary', 'Order Summary')}</h2>
              <Button variant="ghost" size="icon" onClick={() => setShowBreakdown(false)}>
                <X className="w-6 h-6" />
              </Button>
            </div>

            <div className="space-y-3 mb-6">
              <OrderSummaryRow label={t('subtotal', 'Subtotal')} value={<PriceDisplay price={subtotal} />} />
              {promoAmount > 0 && (
                <OrderSummaryRow label={t('promoDiscount', 'Promo Discount')} value={<span>-<PriceDisplay price={promoAmount} /></span>} isPromo />
              )}
              <OrderSummaryRow label={t('serviceFee', 'Service Fee')} value={<PriceDisplay price={serviceFee} />} />
              <OrderSummaryRow label={t('processingFee', 'Processing Fee')} value={<PriceDisplay price={processingFee} />} />
              <OrderSummaryRow label={t('deliveryFee', 'Delivery Fee')} value={<PriceDisplay price={deliveryFee} />} />
              <OrderSummaryRow label={t('tax', 'Tax')} value={<PriceDisplay price={tax} />} />
              <OrderSummaryRow label={t('total', 'Total')} value={<PriceDisplay price={total} />} isTotal />
            </div>

            <Button
              onClick={handleEnhancedCheckout}
              disabled={disabled || isProcessing || itemCount === 0} // Disable if overall disabled, processing, or no items
              className="w-full bg-red-600 hover:bg-red-700 text-white h-12 text-lg rounded-xl"
            >
              {isProcessing ? t('processingOrder', 'Processing Order...') : t('proceedToCheckout', 'Proceed to Checkout')}
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
