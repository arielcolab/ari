
import React from 'react';

// Feature flags configuration
const FEATURE_FLAGS = {
  ff_payments: true,
  ff_filters: true,
  ff_geo_push: true,
  ff_community: true,
  ff_gamification: true,
  ff_enhanced_search: true,
  ff_safety_badges: true,
  ff_sandbox_payments: false, // Set to true for testing
  ff_advanced_filters: true,
  ff_loyalty_system: true,
  ff_batch_upload: true,
  ff_safe_mode: true,
  ff_pickup_windows: true,
  ff_wolt_quote: true,
  ff_share_whatsapp: true,
  ff_referral: true,
  ff_leaderboard: true,
  ff_img_fix: true,
  ff_sandbox_images: false
};

// Feature flag hook
export const useFeatureFlag = (flagName) => {
  return FEATURE_FLAGS[flagName] || false;
};

// Feature flag wrapper component
export const FeatureFlag = ({ flag, children, fallback = null }) => {
  const isEnabled = useFeatureFlag(flag);
  return isEnabled ? children : fallback;
};

// Higher-order component for feature flags
export const withFeatureFlag = (WrappedComponent, flag) => {
  return (props) => {
    const isEnabled = useFeatureFlag(flag);
    if (!isEnabled) return null;
    return <WrappedComponent {...props} />;
  };
};

export default FeatureFlag;
