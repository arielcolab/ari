import React, { useState, useEffect } from "react";
import { Leaf, Users, Globe } from "lucide-react";
import { Order } from "@/api/entities";
import { User } from "@/api/entities";

export default function ImpactCounter({ userId = null, showGlobal = true }) {
  const [userImpact, setUserImpact] = useState({ meals: 0, pounds: 0 });
  const [globalImpact, setGlobalImpact] = useState({ meals: 247, pounds: 623 }); // Mock global stats
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadImpactData = async () => {
      setIsLoading(true);
      try {
        if (userId) {
          // Calculate user's impact from their orders
          const userOrders = await Order.filter({ created_by: userId, status: 'completed' });
          const mealsSaved = userOrders.length;
          const poundsSaved = Math.round(mealsSaved * 2.5); // Estimate 2.5 lbs per meal
          
          setUserImpact({ meals: mealsSaved, pounds: poundsSaved });
        }
        
        // In a real app, you'd fetch global stats from the backend
        // For now, we'll increment slightly each time to show activity
        setGlobalImpact(prev => ({
          meals: prev.meals + Math.floor(Math.random() * 3),
          pounds: prev.pounds + Math.floor(Math.random() * 8)
        }));
      } catch (error) {
        console.error("Error loading impact data:", error);
      }
      setIsLoading(false);
    };

    loadImpactData();
  }, [userId]);

  const ImpactCard = ({ icon: Icon, title, value, subtitle, color }) => (
    <div className={`bg-white rounded-xl p-4 shadow-sm border-l-4 ${color}`}>
      <div className="flex items-center gap-3">
        <div className={`p-2 rounded-lg ${color.replace('border-l-', 'bg-').replace('-500', '-100')}`}>
          <Icon className={`w-6 h-6 ${color.replace('border-l-', 'text-')}`} />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gray-900">{isLoading ? '...' : value}</h3>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-xs text-gray-500">{subtitle}</p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {userId && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Your Impact</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ImpactCard
              icon={Leaf}
              title="Meals Saved"
              value={userImpact.meals}
              subtitle="from going to waste"
              color="border-l-green-500"
            />
            <ImpactCard
              icon={Globe}
              title="Pounds Rescued"
              value={userImpact.pounds}
              subtitle="of food saved"
              color="border-l-blue-500"
            />
          </div>
        </div>
      )}
      
      {showGlobal && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Community Impact</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ImpactCard
              icon={Users}
              title="Total Meals Saved"
              value={globalImpact.meals}
              subtitle="by DishDash community"
              color="border-l-purple-500"
            />
            <ImpactCard
              icon={Globe}
              title="Pounds Rescued"
              value={globalImpact.pounds}
              subtitle="from landfills"
              color="border-l-orange-500"
            />
          </div>
        </div>
      )}
    </div>
  );
}