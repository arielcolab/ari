import React from 'react';
import { Crown, Star, Gift, TrendingUp } from 'lucide-react';
import { FeatureFlag } from './dd_FeatureFlag';

const LoyaltyDisplay = ({ loyaltyData, className = "" }) => {
  const getLevelInfo = (level) => {
    const levels = {
      bronze: { color: 'text-amber-600', bgColor: 'bg-amber-100', icon: Star },
      silver: { color: 'text-gray-600', bgColor: 'bg-gray-100', icon: Star },
      gold: { color: 'text-yellow-600', bgColor: 'bg-yellow-100', icon: Crown },
      platinum: { color: 'text-purple-600', bgColor: 'bg-purple-100', icon: Crown }
    };
    return levels[level] || levels.bronze;
  };

  const levelInfo = getLevelInfo(loyaltyData.level);
  const LevelIcon = levelInfo.icon;

  const getNextLevelThreshold = (currentLevel) => {
    const thresholds = {
      bronze: 100,
      silver: 500,
      gold: 1500,
      platinum: 5000
    };
    return thresholds[currentLevel] || 5000;
  };

  const nextThreshold = getNextLevelThreshold(loyaltyData.level);
  const progress = Math.min((loyaltyData.lifetime_points / nextThreshold) * 100, 100);

  return (
    <FeatureFlag flag="ff_loyalty_system">
      <div className={`bg-white rounded-xl p-4 shadow-sm ${className}`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-full ${levelInfo.bgColor}`}>
              <LevelIcon className={`w-4 h-4 ${levelInfo.color}`} />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 capitalize">{loyaltyData.level} Member</h3>
              <p className="text-sm text-gray-600">{loyaltyData.points} points</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-gray-900">{loyaltyData.points}</p>
            <p className="text-xs text-gray-500">Available</p>
          </div>
        </div>

        {loyaltyData.level !== 'platinum' && (
          <div className="mb-3">
            <div className="flex justify-between text-sm text-gray-600 mb-1">
              <span>Progress to next level</span>
              <span>{loyaltyData.lifetime_points}/{nextThreshold}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${levelInfo.color.replace('text-', 'bg-')}`}
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex items-center gap-2 text-gray-600">
            <TrendingUp className="w-4 h-4" />
            <span>{loyaltyData.lifetime_points} earned</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <Gift className="w-4 h-4" />
            <span>Redeem rewards</span>
          </div>
        </div>
      </div>
    </FeatureFlag>
  );
};

export const LoyaltyPointsToast = ({ points, reason, isVisible }) => {
  if (!isVisible) return null;

  return (
    <FeatureFlag flag="ff_loyalty_system">
      <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 animate-slide-down">
        <div className="bg-green-500 text-white px-6 py-3 rounded-full shadow-lg flex items-center gap-2">
          <Star className="w-5 h-5 fill-current" />
          <span className="font-semibold">+{points} points earned!</span>
          <span className="text-green-100">• {reason}</span>
        </div>
      </div>
    </FeatureFlag>
  );
};

export default LoyaltyDisplay;