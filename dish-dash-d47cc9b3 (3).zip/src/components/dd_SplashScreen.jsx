
import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from './utils/translations';

export default function SplashScreen() {
  const { t } = useTranslation();
  const mascotUrl = 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/c370bd465_28F7DC15-363B-4095-BE17-CE7F55F65A67.png';

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-red-500 to-red-600 flex flex-col items-center justify-center z-[100] text-white overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-3 h-3 bg-white rounded-full opacity-10"
            animate={{
              scale: [0, 1, 0],
              opacity: [0, 0.3, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.3,
            }}
            style={{
              left: `${20 + (i * 10)}%`,
              top: `${20 + (i * 8)}%`,
            }}
          />
        ))}
      </div>

      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="text-center relative z-10"
      >
        <motion.div
          animate={{ 
            y: [0, -15, 0],
            rotate: [0, 3, -3, 0]
          }}
          transition={{
            duration: 2.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          <img
            src={mascotUrl}
            alt="DishDash Loading"
            className="w-80 max-w-sm mx-auto drop-shadow-2xl"
          />
        </motion.div>
      </motion.div>

      <motion.div
        className="absolute bottom-16 left-0 right-0 text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <motion.p 
          className="font-bold text-xl mb-2"
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          {t('loadingDeliciousness', 'Loading deliciousness...')}
        </motion.p>
        <motion.div 
          className="w-16 h-1 bg-white rounded-full mx-auto"
          animate={{ scaleX: [0, 1, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        />
      </motion.div>
    </div>
  );
}
