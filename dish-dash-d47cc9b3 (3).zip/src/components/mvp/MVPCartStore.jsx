import { User } from '@/api/entities';
import AnalyticsHelper from './AnalyticsHelper';

class MVPCartStore {
  constructor() {
    this.items = [];
    this.listeners = [];
    this.loadItems();
  }

  loadItems() {
    try {
      const stored = localStorage.getItem('dishdash_mvp_cart');
      this.items = stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error loading cart:', error);
      this.items = [];
    }
  }

  saveToStorage() {
    try {
      localStorage.setItem('dishdash_mvp_cart', JSON.stringify(this.items));
    } catch (error) {
      console.error('Error saving cart:', error);
    }
  }

  async addItem(listing, quantity = 1) {
    const existingIndex = this.items.findIndex(item => item.listing.id === listing.id);
    
    if (existingIndex >= 0) {
      this.items[existingIndex].quantity += quantity;
    } else {
      this.items.push({ 
        listing: {
          id: listing.id,
          title: listing.title,
          price: listing.price,
          photos: listing.photos || [],
          seller_name: listing.seller_name,
          seller_id: listing.seller_id
        },
        quantity 
      });
    }
    
    this.saveToStorage();
    this.notifyListeners();
    
    // Track analytics
    await AnalyticsHelper.addToCart(listing.id, { quantity });
  }

  updateQuantity(listingId, quantity) {
    if (quantity <= 0) {
      this.removeItem(listingId);
      return;
    }

    this.items = this.items.map(item =>
      item.listing.id === listingId
        ? { ...item, quantity }
        : item
    );

    this.saveToStorage();
    this.notifyListeners();
  }

  removeItem(listingId) {
    this.items = this.items.filter(item => item.listing.id !== listingId);
    this.saveToStorage();
    this.notifyListeners();
  }

  getSubtotal() {
    return this.items.reduce((total, item) => {
      return total + (item.listing.price * item.quantity);
    }, 0);
  }

  getTax(subtotal) {
    return subtotal * 0.08; // 8% tax rate
  }

  getCommission(subtotal) {
    return subtotal * 0.12; // 12% commission rate
  }

  getDeliveryFee() {
    return this.items.length > 0 ? 2.99 : 0; // Flat delivery fee
  }

  getTotal() {
    const subtotal = this.getSubtotal();
    const tax = this.getTax(subtotal);
    const deliveryFee = this.getDeliveryFee();
    return subtotal + tax + deliveryFee;
  }

  getItemCount() {
    return this.items.reduce((count, item) => count + item.quantity, 0);
  }

  clear() {
    this.items = [];
    this.saveToStorage();
    this.notifyListeners();
  }

  subscribe(callback) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  notifyListeners() {
    this.listeners.forEach(callback => {
      try {
        callback([...this.items]);
      } catch (error) {
        console.error('Error in cart listener:', error);
      }
    });
  }
}

export const mvpCartStore = new MVPCartStore();