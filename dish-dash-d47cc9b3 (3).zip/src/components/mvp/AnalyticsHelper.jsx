import { AnalyticsEvent } from '@/api/entities';
import { User } from '@/api/entities';

class AnalyticsHelper {
  static async trackEvent(eventType, data = {}) {
    try {
      let userId = null;
      try {
        const user = await User.me();
        userId = user?.id;
      } catch (e) {
        // User not logged in, track as anonymous
      }

      await AnalyticsEvent.create({
        event_type: eventType,
        user_id: userId,
        listing_id: data.listingId,
        order_id: data.orderId,
        metadata: data.metadata || {}
      });
    } catch (error) {
      console.log('Analytics tracking failed:', error);
      // Don't throw - analytics should not break app functionality
    }
  }

  static async viewListing(listingId) {
    return this.trackEvent('view_listing', { listingId });
  }

  static async addToCart(listingId, metadata = {}) {
    return this.trackEvent('add_to_cart', { listingId, metadata });
  }

  static async checkoutStarted(metadata = {}) {
    return this.trackEvent('checkout_started', { metadata });
  }

  static async orderPlaced(orderId, metadata = {}) {
    return this.trackEvent('order_placed', { orderId, metadata });
  }

  static async statusChanged(orderId, metadata = {}) {
    return this.trackEvent('status_changed', { orderId, metadata });
  }
}

export default AnalyticsHelper;