import React from 'react';
import { AlertCircle } from 'lucide-react';
import { useTranslation } from '../utils/translations';

const ComplianceDisclaimer = ({ variant = 'listing' }) => {
  const { t } = useTranslation();
  
  const message = variant === 'checkout' 
    ? "By placing this order, you acknowledge that DishDash is a marketplace platform. Sellers are solely responsible for food safety, quality, and compliance with local regulations."
    : "DishDash is a marketplace platform. Sellers are solely responsible for food safety and compliance with local cottage food laws and regulations.";

  return (
    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mt-4">
      <div className="flex items-start gap-2">
        <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
        <p className="text-sm text-yellow-800">{message}</p>
      </div>
    </div>
  );
};

export default ComplianceDisclaimer;