import React from "react";
import { Button } from "@/components/ui/button";
import { Leaf, Wheat, Shield } from "lucide-react";

const FilterChip = ({ label, icon: Icon, active, onClick, color = "green" }) => {
  const colorClasses = {
    green: active ? "bg-green-500 text-white border-green-500" : "bg-white text-green-700 border-green-200 hover:bg-green-50",
    blue: active ? "bg-blue-500 text-white border-blue-500" : "bg-white text-blue-700 border-blue-200 hover:bg-blue-50",
    purple: active ? "bg-purple-500 text-white border-purple-500" : "bg-white text-purple-700 border-purple-200 hover:bg-purple-50"
  };

  return (
    <Button
      variant="outline"
      onClick={onClick}
      className={`rounded-full h-9 px-4 text-sm font-medium transition-colors whitespace-nowrap border ${colorClasses[color]}`}
    >
      <Icon className="w-4 h-4 mr-2" />
      {label}
    </Button>
  );
};

export default function DietaryFilters({ activeDietaryFilters, onDietaryFilterToggle }) {
  const dietaryOptions = [
    { key: 'vegetarian', label: 'Vegetarian', icon: Leaf, color: 'green' },
    { key: 'vegan', label: 'Vegan', icon: Leaf, color: 'green' },
    { key: 'gluten-free', label: 'Gluten-Free', icon: Wheat, color: 'blue' },
    { key: 'kosher', label: 'Kosher', icon: Shield, color: 'purple' },
    { key: 'dairy-free', label: 'Dairy-Free', icon: Leaf, color: 'green' },
    { key: 'nut-free', label: 'Nut-Free', icon: Shield, color: 'blue' }
  ];

  return (
    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
      {dietaryOptions.map(option => (
        <FilterChip
          key={option.key}
          label={option.label}
          icon={option.icon}
          color={option.color}
          active={activeDietaryFilters.includes(option.key)}
          onClick={() => onDietaryFilterToggle(option.key)}
        />
      ))}
    </div>
  );
}