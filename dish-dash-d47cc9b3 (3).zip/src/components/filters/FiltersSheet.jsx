import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X, DollarSign, Tag, Star } from 'lucide-react';
import { useTranslation } from '../utils/translations';

export default function FiltersSheet({ isOpen, onClose, onApply, initialFilters }) {
  const { t } = useTranslation();
  const [filters, setFilters] = useState(initialFilters || {});
  
  const dietTagOptions = [
    'vegan', 'vegetarian', 'kosher', 'halal', 'gluten_free', 'dairy_free', 'organic'
  ];

  const handleDietToggle = (tag) => {
    setFilters(prev => {
        const currentDiet = prev.dietary || [];
        const newDiet = currentDiet.includes(tag) 
            ? currentDiet.filter(t => t !== tag)
            : [...currentDiet, tag];
        return {...prev, dietary: newDiet};
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end" onClick={onClose}>
      <div className="bg-white w-full max-h-[80vh] overflow-y-auto rounded-t-2xl p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">{t('filters')}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
        </div>

        <div className="space-y-6">
          {/* Price Range */}
          <div>
            <h3 className="font-semibold mb-3 flex items-center gap-2"><DollarSign className="w-4 h-4"/>{t('priceRange')}</h3>
            <div className="flex items-center gap-4">
              <Input 
                type="number" 
                placeholder="מ- (₪)"
                value={filters.minPrice || ''}
                onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
              />
              <span className="text-gray-500">-</span>
              <Input 
                type="number" 
                placeholder="עד (₪)"
                value={filters.maxPrice || ''}
                onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
              />
            </div>
          </div>
          
          {/* Dietary Tags */}
          <div>
            <h3 className="font-semibold mb-3 flex items-center gap-2"><Tag className="w-4 h-4"/>{t('dietaryTags')}</h3>
            <div className="flex flex-wrap gap-2">
              {dietTagOptions.map(tag => (
                <Button
                  key={tag}
                  variant={filters.dietary?.includes(tag) ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handleDietToggle(tag)}
                  className={filters.dietary?.includes(tag) ? "bg-green-600" : ""}
                >
                  {t(tag, tag)}
                </Button>
              ))}
            </div>
          </div>
          
           {/* Rating */}
           <div>
            <h3 className="font-semibold mb-3 flex items-center gap-2"><Star className="w-4 h-4"/>{t('rating')}</h3>
            {/* Rating filter logic can be added here */}
            <p className="text-sm text-gray-500">סינון לפי דירוג יתווסף בקרוב.</p>
          </div>

        </div>

        <div className="mt-8 flex gap-4">
          <Button variant="outline" className="flex-1" onClick={() => { setFilters({}); onApply({}); }}>{t('clearFilters')}</Button>
          <Button className="flex-1 bg-red-500 hover:bg-red-600" onClick={() => onApply(filters)}>{t('apply') || 'החל'}</Button>
        </div>
      </div>
    </div>
  );
}