import { UserPoints } from '@/api/entities';
import { Badge } from '@/api/entities';
import { UserBadge } from '@/api/entities';
import { Challenge } from '@/api/entities';
import { UserChallenge } from '@/api/entities';
import { User } from '@/api/entities';
import { showToast } from '../common/ErrorBoundary';

export class GamificationManager {
  static async initializeUser(userId) {
    try {
      // Check if user already has points record
      const existingPoints = await UserPoints.filter({ user_id: userId });
      
      if (existingPoints.length === 0) {
        await UserPoints.create({
          user_id: userId,
          total_points: 0,
          level: 1,
          points_this_week: 0,
          last_activity: new Date().toISOString()
        });
      }

      // Initialize default badges if they don't exist
      await this.initializeDefaultBadges();
      
      // Initialize weekly challenges
      await this.initializeWeeklyChallenges();
      
    } catch (error) {
      console.error('Error initializing gamification for user:', error);
    }
  }

  static async initializeDefaultBadges() {
    try {
      const existingBadges = await Badge.list();
      
      if (existingBadges.length === 0) {
        const defaultBadges = [
          { name: "First Steps", description: "Earned your first 100 points", icon: "🌟", threshold: 100, badge_type: "points" },
          { name: "Rising Star", description: "Reached 500 points", icon: "⭐", threshold: 500, badge_type: "points" },
          { name: "DishDash Champion", description: "Achieved 1000 points", icon: "🏆", threshold: 1000, badge_type: "points" },
          { name: "Food Explorer", description: "Completed 10 orders", icon: "🗺️", threshold: 10, badge_type: "orders" },
          { name: "Review Master", description: "Left 20 reviews", icon: "📝", threshold: 20, badge_type: "reviews" },
          { name: "Community Builder", description: "Referred 5 friends", icon: "🤝", threshold: 5, badge_type: "referrals" }
        ];

        for (const badge of defaultBadges) {
          await Badge.create(badge);
        }
      }
    } catch (error) {
      console.error('Error initializing default badges:', error);
    }
  }

  static async initializeWeeklyChallenges() {
    try {
      const now = new Date();
      const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay()));
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 6);

      const existingChallenges = await Challenge.filter({
        start_date: startOfWeek.toISOString().split('T')[0],
        is_active: true
      });

      if (existingChallenges.length === 0) {
        const weeklyChallenge = {
          title: "Weekly Rescue Mission",
          description: "Rescue 5 meals this week and earn bonus points!",
          target: 5,
          challenge_type: "rescue_meals",
          reward_points: 50,
          start_date: startOfWeek.toISOString().split('T')[0],
          end_date: endOfWeek.toISOString().split('T')[0],
          is_active: true
        };

        await Challenge.create(weeklyChallenge);
      }
    } catch (error) {
      console.error('Error initializing weekly challenges:', error);
    }
  }

  static async awardPoints(userId, points, activity) {
    try {
      const userPoints = await UserPoints.filter({ user_id: userId });
      
      if (userPoints.length === 0) {
        await this.initializeUser(userId);
        return await this.awardPoints(userId, points, activity);
      }

      const currentPoints = userPoints[0];
      const newTotalPoints = currentPoints.total_points + points;
      const newWeeklyPoints = currentPoints.points_this_week + points;
      const newLevel = Math.floor(newTotalPoints / 100) + 1;

      await UserPoints.update(currentPoints.id, {
        total_points: newTotalPoints,
        level: newLevel,
        points_this_week: newWeeklyPoints,
        last_activity: new Date().toISOString()
      });

      // Check for new badges
      await this.checkAndAwardBadges(userId, newTotalPoints, activity);

      // Update challenge progress
      await this.updateChallengeProgress(userId, activity);

      // Show points notification
      showToast(`+${points} points earned! 🌟`, 'success');

      return { newTotal: newTotalPoints, newLevel };
    } catch (error) {
      console.error('Error awarding points:', error);
    }
  }

  static async checkAndAwardBadges(userId, totalPoints, activity) {
    try {
      const allBadges = await Badge.list();
      const userBadges = await UserBadge.filter({ user_id: userId });
      const earnedBadgeIds = userBadges.map(ub => ub.badge_id);

      for (const badge of allBadges) {
        if (earnedBadgeIds.includes(badge.id)) continue;

        let shouldAward = false;
        
        switch (badge.badge_type) {
          case 'points':
            shouldAward = totalPoints >= badge.threshold;
            break;
          case 'orders':
            // This would need order count logic
            break;
          case 'reviews':
            // This would need review count logic
            break;
          case 'referrals':
            // This would need referral count logic
            break;
        }

        if (shouldAward) {
          await UserBadge.create({
            user_id: userId,
            badge_id: badge.id,
            earned_at: new Date().toISOString()
          });

          showToast(`Badge earned: ${badge.name} ${badge.icon}`, 'success');
        }
      }
    } catch (error) {
      console.error('Error checking badges:', error);
    }
  }

  static async updateChallengeProgress(userId, activity) {
    try {
      if (activity === 'order') {
        const activeChallenges = await Challenge.filter({ is_active: true });
        
        for (const challenge of activeChallenges) {
          if (challenge.challenge_type === 'rescue_meals' || challenge.challenge_type === 'orders') {
            let userChallenge = await UserChallenge.filter({ 
              user_id: userId, 
              challenge_id: challenge.id 
            });

            if (userChallenge.length === 0) {
              await UserChallenge.create({
                user_id: userId,
                challenge_id: challenge.id,
                progress: 1,
                completed: false
              });
            } else {
              const currentProgress = userChallenge[0].progress + 1;
              const isCompleted = currentProgress >= challenge.target;
              
              await UserChallenge.update(userChallenge[0].id, {
                progress: currentProgress,
                completed: isCompleted,
                completed_at: isCompleted ? new Date().toISOString() : null
              });

              if (isCompleted && !userChallenge[0].completed) {
                await this.awardPoints(userId, challenge.reward_points, 'challenge_completion');
                showToast(`Challenge completed! +${challenge.reward_points} bonus points! 🎉`, 'success');
              }
            }
          }
        }
      }
    } catch (error) {
      console.error('Error updating challenge progress:', error);
    }
  }

  static async getUserStats(userId) {
    try {
      const userPoints = await UserPoints.filter({ user_id: userId });
      const userBadges = await UserBadge.filter({ user_id: userId });
      const userChallenges = await UserChallenge.filter({ user_id: userId });

      return {
        points: userPoints[0] || { total_points: 0, level: 1, points_this_week: 0 },
        badges: userBadges,
        challenges: userChallenges
      };
    } catch (error) {
      console.error('Error getting user stats:', error);
      return { points: { total_points: 0, level: 1, points_this_week: 0 }, badges: [], challenges: [] };
    }
  }

  static async getLeaderboard() {
    try {
      const allUserPoints = await UserPoints.list('-points_this_week', 10);
      
      // Get user profiles for the leaderboard
      const leaderboard = await Promise.all(
        allUserPoints.map(async (userPoints, index) => {
          try {
            const user = await User.me(); // This might need to be adjusted based on your user system
            return {
              rank: index + 1,
              user_id: userPoints.user_id,
              username: user?.full_name || 'Anonymous User',
              points: userPoints.points_this_week,
              level: userPoints.level
            };
          } catch (error) {
            return {
              rank: index + 1,
              user_id: userPoints.user_id,
              username: 'Anonymous User',
              points: userPoints.points_this_week,
              level: userPoints.level
            };
          }
        })
      );

      return leaderboard;
    } catch (error) {
      console.error('Error getting leaderboard:', error);
      return [];
    }
  }
}

// Hook into order completion
export const awardOrderPoints = async (userId) => {
  await GamificationManager.awardPoints(userId, 10, 'order');
};

// Hook into review submission
export const awardReviewPoints = async (userId) => {
  await GamificationManager.awardPoints(userId, 5, 'review');
};

// Hook into referral clicks
export const awardReferralPoints = async (userId) => {
  await GamificationManager.awardPoints(userId, 2, 'referral');
};