import React, { useState, useEffect } from 'react';
import { dd_LeaderboardWeekly } from '@/api/entities';
import { User } from '@/api/entities';
import { Trophy, Award, Medal } from 'lucide-react';
import { FeatureFlag } from './dd_FeatureFlag';

const LeaderboardWidget = () => {
  const [leaderboard, setLeaderboard] = useState([]);
  const [userRank, setUserRank] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const loadLeaderboard = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);

        // Get current week's leaderboard
        const weekStart = getWeekStart(new Date());
        const weeklyData = await dd_LeaderboardWeekly.filter(
          { week_start_date: weekStart.toISOString().split('T')[0] },
          '-rescued_meals',
          10
        );

        setLeaderboard(weeklyData);
        
        // Find user's rank
        const userEntry = weeklyData.find(entry => entry.user_id === user.id);
        if (userEntry) {
          setUserRank(userEntry.rank);
        }
      } catch (error) {
        console.error('Error loading leaderboard:', error);
      }
    };

    loadLeaderboard();
  }, []);

  const getWeekStart = (date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day;
    return new Date(d.setDate(diff));
  };

  const getRankIcon = (rank) => {
    switch (rank) {
      case 1: return <Trophy className="w-5 h-5 text-yellow-500" />;
      case 2: return <Award className="w-5 h-5 text-gray-400" />;
      case 3: return <Medal className="w-5 h-5 text-orange-500" />;
      default: return <span className="w-5 h-5 flex items-center justify-center text-sm font-bold">#{rank}</span>;
    }
  };

  return (
    <FeatureFlag flag="ff_leaderboard">
      <div className="bg-white rounded-xl p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-4">
          <Trophy className="w-6 h-6 text-yellow-500" />
          <h3 className="text-lg font-bold text-gray-900">Weekly Rescue Challenge</h3>
        </div>
        
        <p className="text-sm text-gray-600 mb-4">
          Help reduce food waste by rescuing leftover meals!
        </p>

        {leaderboard.length > 0 ? (
          <div className="space-y-3">
            {leaderboard.slice(0, 5).map((entry, index) => (
              <div key={entry.user_id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50">
                {getRankIcon(index + 1)}
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    {entry.user_id === currentUser?.id ? 'You' : `User ${entry.user_id.slice(-4)}`}
                  </p>
                  <p className="text-sm text-gray-600">
                    {entry.rescued_meals} meals rescued
                  </p>
                </div>
                {index === 0 && (
                  <div className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">
                    Champion
                  </div>
                )}
              </div>
            ))}
            
            {userRank && userRank > 5 && (
              <div className="border-t pt-3 mt-3">
                <div className="flex items-center gap-3 p-2 rounded-lg bg-blue-50">
                  <span className="w-5 h-5 flex items-center justify-center text-sm font-bold">
                    #{userRank}
                  </span>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">You</p>
                    <p className="text-sm text-gray-600">Keep rescuing to climb up!</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-4">
            Be the first to start rescuing meals this week!
          </p>
        )}
      </div>
    </FeatureFlag>
  );
};

export default LeaderboardWidget;