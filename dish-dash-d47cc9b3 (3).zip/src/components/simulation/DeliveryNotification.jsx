
import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Star, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import OptimizedImage from '../dd_OptimizedImage';
import { useTranslation } from '../utils/translations';
import { createPageUrl } from '@/utils';
import { useNavigate } from 'react-router-dom';
import { OrderSimulation } from './OrderSimulation'; // Corrected path

// Confetti component
const Confetti = ({ isActive }) => {
  if (!isActive) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {Array.from({ length: 30 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-3 h-3 bg-yellow-400 rounded-full"
          initial={{
            x: window.innerWidth / 2,
            y: window.innerHeight / 2,
            scale: 0,
          }}
          animate={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            scale: [0, 1, 0],
            rotate: [0, 360],
          }}
          transition={{
            duration: 2,
            delay: i * 0.1,
            ease: "easeOut",
          }}
        />
      ))}
    </div>
  );
};

const DeliveryNotification = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [notificationData, setNotificationData] = useState(null);
  const [showNotification, setShowNotification] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    const unsubscribe = OrderSimulation.subscribe(({ activeOrders }) => {
      // Show notification when order is delivered and not yet rated
      const deliveredOrder = activeOrders.find(order => 
        order.status === 'delivered' && 
        !sessionStorage.getItem(`rated_${order.id}`)
      );
      
      if (deliveredOrder) {
        setNotificationData(deliveredOrder);
        setShowNotification(true);
        setShowConfetti(true); // Trigger confetti when an order is detected as delivered

        // Auto-hide confetti after 3 seconds
        setTimeout(() => setShowConfetti(false), 3000);
        
        // Auto-hide notification after 5 seconds
        setTimeout(() => {
          setShowNotification(false);
          setNotificationData(null); // Clear data when notification auto-hides
        }, 5000);
      }
    });

    return unsubscribe;
  }, []);

  const handleRateOrder = () => {
    if (notificationData) {
      sessionStorage.setItem(`rated_${notificationData.id}`, 'true'); // Mark as rated in session storage
      navigate(`/OrderRating?orderId=${notificationData.id}`); // Navigate to the rating page
      setShowNotification(false); // Hide the notification
      setNotificationData(null); // Clear notification data
    }
  };

  const handleDismiss = () => {
    setShowNotification(false); // Hide the notification
    setNotificationData(null); // Clear notification data
  };

  return (
    <>
      <Confetti isActive={showConfetti} />
      
      <AnimatePresence>
        {showNotification && notificationData && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -100 }}
            className="fixed top-4 left-4 right-4 z-50"
          >
            <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Check className="w-6 h-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg text-gray-900">Order Delivered!</h3>
                  <p className="text-sm text-gray-600">Your food has arrived safely</p>
                </div>
                <button
                  onClick={handleDismiss}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              <div className="flex items-center gap-3 mb-4 p-3 bg-gray-50 rounded-xl">
                <OptimizedImage
                  src={notificationData.chef.avatar}
                  className="w-10 h-10 rounded-full"
                  alt={notificationData.chef.name}
                />
                <div className="flex-1">
                  <p className="font-medium">{notificationData.chef.name}</p>
                  <p className="text-sm text-gray-500">
                    {notificationData.items.length} item{notificationData.items.length > 1 ? 's' : ''}
                  </p>
                </div>
                <Package className="w-5 h-5 text-gray-400" />
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1 rounded-xl"
                  onClick={handleDismiss}
                >
                  Close
                </Button>
                <Button
                  className="flex-1 bg-red-600 hover:bg-red-700 rounded-xl"
                  onClick={handleRateOrder}
                >
                  <Star className="w-4 h-4 mr-2" />
                  Rate Order
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

export default DeliveryNotification;
