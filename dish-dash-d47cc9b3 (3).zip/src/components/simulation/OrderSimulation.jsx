import { showToast } from '../common/ErrorBoundary';
import { User } from '@/api/entities';

let activeOrders = [];
let listeners = [];

const notifyListeners = () => {
  listeners.forEach(listener => listener({ activeOrders }));
};

const subscribe = (listener) => {
  listeners.push(listener);
  return () => {
    listeners = listeners.filter(l => l !== listener);
  };
};

const createFakeOrder = async (cartItems, user) => {
  const newOrder = {
    id: `order_${Date.now()}`,
    user_id: user.id,
    user_name: user.full_name,
    items: cartItems.map(item => ({ ...item.dish, quantity: item.quantity })),
    chef: { // Using a mock chef for now
      name: cartItems[0]?.dish?.cook_name || "Mama's Kitchen",
      avatar: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=100'
    },
    status: 'confirmed',
    createdAt: new Date(),
    estimatedDelivery: new Date(Date.now() + 30 * 60 * 1000), // 30 mins
  };
  
  activeOrders.push(newOrder);
  notifyListeners();
  
  // Simulate order progression
  setTimeout(() => {
    updateOrderStatus(newOrder.id, 'preparing');
  }, 5000); // to preparing after 5s

  setTimeout(() => {
    updateOrderStatus(newOrder.id, 'out_for_delivery');
  }, 15000); // to out for delivery after 15s

  setTimeout(() => {
    updateOrderStatus(newOrder.id, 'delivered');
  }, 25000); // delivered after 25s
};

const updateOrderStatus = (orderId, newStatus) => {
  const order = activeOrders.find(o => o.id === orderId);
  if (order) {
    order.status = newStatus;
    if (newStatus === 'delivered') {
      order.deliveredAt = new Date();
    }
    notifyListeners();
  }
};

const getActiveOrders = () => activeOrders;

export const OrderSimulation = {
  subscribe,
  createFakeOrder,
  getActiveOrders,
};