import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { dd_Credits } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Gift, Copy, Users } from 'lucide-react';
import { FeatureFlag } from './dd_FeatureFlag';
import { showToast } from './common/ErrorBoundary';

export const ReferralCode = ({ user }) => {
  const handleCopyCode = () => {
    navigator.clipboard.writeText(user.ref_code);
    showToast('Referral code copied!', 'success');
  };

  const referralUrl = `${window.location.origin}?ref=${user.ref_code}`;

  return (
    <FeatureFlag flag="ff_referral">
      <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl p-6 text-white">
        <div className="flex items-center gap-3 mb-4">
          <Gift className="w-6 h-6" />
          <h3 className="text-lg font-bold">Invite Friends & Earn</h3>
        </div>
        
        <p className="text-purple-100 mb-4">
          Give your friends $5 off their first order and get $5 when they order!
        </p>
        
        <div className="space-y-3">
          <div className="flex gap-2">
            <Input
              value={user.ref_code}
              readOnly
              className="bg-white/20 border-white/30 text-white placeholder-white/70"
            />
            <Button
              variant="secondary"
              onClick={handleCopyCode}
              className="bg-white/20 hover:bg-white/30 text-white border-white/30"
            >
              <Copy className="w-4 h-4" />
            </Button>
          </div>
          
          <Button
            variant="secondary"
            onClick={() => {
              navigator.share({
                title: 'Join DishDash',
                text: 'Get $5 off your first order on DishDash!',
                url: referralUrl
              }).catch(() => {
                navigator.clipboard.writeText(referralUrl);
                showToast('Link copied!', 'success');
              });
            }}
            className="w-full bg-white/20 hover:bg-white/30 text-white border-white/30"
          >
            <Users className="w-4 h-4 mr-2" />
            Share Invite Link
          </Button>
        </div>
      </div>
    </FeatureFlag>
  );
};

export const CreditsBalance = ({ userId }) => {
  const [credits, setCredits] = useState(null);

  useEffect(() => {
    const loadCredits = async () => {
      try {
        const userCredits = await dd_Credits.filter({ user_id: userId });
        setCredits(userCredits[0] || { balance: 0 });
      } catch (error) {
        console.error('Error loading credits:', error);
      }
    };

    if (userId) {
      loadCredits();
    }
  }, [userId]);

  if (!credits) return null;

  return (
    <FeatureFlag flag="ff_referral">
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-semibold text-green-900">Your Credits</h4>
            <p className="text-sm text-green-700">
              ${(credits.balance / 100).toFixed(2)} available
            </p>
          </div>
          <Gift className="w-8 h-8 text-green-600" />
        </div>
      </div>
    </FeatureFlag>
  );
};

export default ReferralCode;