
import React from 'react';
import { Shield, Award, Star, CheckCircle, Thermometer, Clock } from 'lucide-react';
import { FeatureFlag } from './dd_FeatureFlag';

const SafetyBadges = ({ cook, className = "" }) => {
  const badges = [];

  if (cook.hygiene_badge) {
    badges.push({
      icon: Shield,
      label: "Hygiene Certified",
      color: "bg-green-100 text-green-800",
      description: "Passed food safety certification"
    });
  }

  if (cook.kyc_status === 'completed') {
    badges.push({
      icon: CheckCircle,
      label: "Verified Kitchen",
      color: "bg-blue-100 text-blue-800",
      description: "Identity and kitchen verified"
    });
  }

  if (cook.total_sales > 1000) {
    badges.push({
      icon: Award,
      label: "Top Seller",
      color: "bg-purple-100 text-purple-800",
      description: "High volume seller"
    });
  }

  if (cook.rating_average >= 4.5 && cook.rating_count >= 10) {
    badges.push({
      icon: Star,
      label: "Highly Rated",
      color: "bg-yellow-100 text-yellow-800",
      description: "Consistently excellent reviews"
    });
  }

  return (
    <FeatureFlag flag="ff_safety_badges">
      <div className={`flex flex-wrap gap-1 ${className}`}>
        {badges.map((badge, index) => (
          <div
            key={index}
            className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${badge.color}`}
            title={badge.description}
          >
            <badge.icon className="w-3 h-3" />
            {badge.label}
          </div>
        ))}
      </div>
    </FeatureFlag>
  );
};

export const SafetyChecklist = ({ onComplete, isOpen }) => {
  const [checkedItems, setCheckedItems] = React.useState({});

  const checklistItems = [
    {
      id: 'temperature',
      icon: Thermometer,
      title: 'Food Temperature',
      description: 'Hot food kept above 140°F (60°C), cold food below 40°F (4°C)'
    },
    {
      id: 'storage',
      icon: Shield,
      title: 'Proper Storage',
      description: 'Food stored in clean, covered containers'
    },
    {
      id: 'hygiene',
      icon: CheckCircle,
      title: 'Personal Hygiene',
      description: 'Clean hands, clean cooking area, hair covered'
    },
    {
      id: 'expiry',
      icon: Clock,
      title: 'Expiry Time',
      description: 'Clearly marked pickup window and expiration time'
    }
  ];

  const handleCheck = (id, checked) => {
    setCheckedItems(prev => ({ ...prev, [id]: checked }));
  };

  const allChecked = checklistItems.every(item => checkedItems[item.id]);

  if (!isOpen) return null;

  return (
    <FeatureFlag flag="ff_safety_badges">
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-md w-full p-6">
          <div className="text-center mb-6">
            <Shield className="w-12 h-12 text-green-500 mx-auto mb-3" />
            <h2 className="text-xl font-bold text-gray-900">Safety Checklist</h2>
            <p className="text-gray-600">Please confirm these safety measures before posting</p>
          </div>

          <div className="space-y-4 mb-6">
            {checklistItems.map(item => (
              <div key={item.id} className="flex items-start gap-3">
                <input
                  type="checkbox"
                  id={item.id}
                  checked={checkedItems[item.id] || false}
                  onChange={(e) => handleCheck(item.id, e.target.checked)}
                  className="mt-1 rounded border-gray-300 text-green-600 focus:ring-green-500"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <item.icon className="w-4 h-4 text-gray-500" />
                    <label htmlFor={item.id} className="font-medium text-gray-900">
                      {item.title}
                    </label>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <p className="text-sm text-yellow-800">
              <strong>Disclaimer:</strong> By posting food, you acknowledge responsibility for food safety and quality. 
              DishDash is not liable for any foodborne illness or injury.
            </p>
          </div>

          <button
            onClick={onComplete}
            disabled={!allChecked}
            className={`w-full py-3 rounded-lg font-semibold ${
              allChecked 
                ? 'bg-green-500 hover:bg-green-600 text-white' 
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
          >
            Continue to Post
          </button>
        </div>
      </div>
    </FeatureFlag>
  );
};

export default SafetyBadges;
