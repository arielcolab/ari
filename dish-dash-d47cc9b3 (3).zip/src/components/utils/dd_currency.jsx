
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { useTranslation } from './translations';

// Currency configuration
export const currencies = {
  USD: { symbol: '$', code: 'USD', name: 'US Dollar', position: 'before' },
  EUR: { symbol: '€', code: 'EUR', name: 'Euro', position: 'after' },
  GBP: { symbol: '£', code: 'GBP', name: 'British Pound', position: 'before' },
  ILS: { symbol: '₪', code: 'ILS', name: 'Israeli Shekel', position: 'after' },
  AED: { symbol: 'د.إ', code: 'AED', name: 'UAE Dirham', position: 'before' },
  SAR: { symbol: 'ر.س', code: 'SAR', name: 'Saudi Riyal', position: 'before' },
  BRL: { symbol: 'R$', code: 'BRL', name: 'Brazilian Real', position: 'before' }
};

// Language to currency mapping
const languageToCurrency = {
  en: 'USD',
  he: 'ILS', 
  ar: 'AED',
  fr: 'EUR',
  es: 'EUR',
  pt: 'BRL'
};

// Mock exchange rates (in a real app, you'd fetch from an API)
const exchangeRates = {
  USD: 1.0,
  EUR: 0.92,
  GBP: 0.79,
  ILS: 3.7,
  AED: 3.67,
  SAR: 3.75,
  BRL: 5.15
};

export const useCurrency = () => {
  const { currentLanguage } = useTranslation();
  const [currentCurrency, setCurrentCurrency] = useState('USD');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initializeCurrency = async () => {
      setIsLoading(true);
      try {
        const user = await User.me();
        if (user && user.preferred_currency && currencies[user.preferred_currency]) {
          setCurrentCurrency(user.preferred_currency);
          return;
        }
      } catch (error) { /* User not logged in */ }

      const savedCurrency = localStorage.getItem('preferredCurrency');
      if (savedCurrency && currencies[savedCurrency]) {
        setCurrentCurrency(savedCurrency);
      } else {
        setCurrentCurrency(languageToCurrency[currentLanguage] || 'USD');
      }
    };

    initializeCurrency().finally(() => setIsLoading(false));
  }, [currentLanguage]);

  const setCurrency = async (currencyCode) => {
    if (!currencies[currencyCode]) return;

    setCurrentCurrency(currencyCode);
    localStorage.setItem('preferredCurrency', currencyCode);
    try {
      await User.updateMyUserData({ preferred_currency: currencyCode });
    } catch (error) { /* User not logged in */ }
  };

  const convertPrice = (priceInUSD, toCurrency = currentCurrency) => {
    if (toCurrency === 'USD' || !exchangeRates[toCurrency]) return priceInUSD;
    return priceInUSD * exchangeRates[toCurrency];
  };

  const formatPrice = (priceInUSD, options = {}) => {
    const { 
      currency = currentCurrency, 
      showCode = false,
      decimals = 2 
    } = options;

    if (isLoading) return '...';

    const convertedPrice = convertPrice(priceInUSD, currency);
    const currencyInfo = currencies[currency];
    const formattedAmount = convertedPrice.toFixed(decimals);

    const priceString = currencyInfo.position === 'before'
      ? `${currencyInfo.symbol}${formattedAmount}`
      : `${formattedAmount}${currencyInfo.symbol}`;
      
    return showCode ? `${priceString} ${currency}` : priceString;
  };

  return { currentCurrency, setCurrency, convertPrice, formatPrice, currencies, isLoading };
};

// Utility component for displaying prices
export const PriceDisplay = ({ price, className = "", showCode = false, currency, decimals = 2, ...props }) => {
  const { formatPrice, isLoading } = useCurrency();
  if (isLoading) return <span className="animate-pulse bg-gray-200 rounded w-12 inline-block">&nbsp;</span>;
  
  // Override the default red color - use black unless explicitly overridden
  const finalClassName = className || "text-black";
  
  return (
    <span className={finalClassName} {...props}>
      {formatPrice(price, { currency, showCode, decimals })}
    </span>
  );
};
