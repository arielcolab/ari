import { Profile } from '@/api/entities';
import { User } from '@/api/entities';

export class ProfileManager {
  /**
   * Creates a profile for a user if one doesn't exist
   * @param {Object} userData - User data from User.me() or similar
   * @returns {Object} Profile data
   */
  static async ensureUserProfile(userData) {
    if (!userData || !userData.id) {
      throw new Error('Invalid user data provided');
    }

    try {
      // Check if profile already exists
      const existingProfiles = await Profile.filter({ userId: userData.id });
      
      if (existingProfiles.length > 0) {
        return existingProfiles[0];
      }

      // Create new profile
      const newProfile = await Profile.create({
        fullName: userData.full_name || userData.email || 'New User',
        photo: userData.profile_photo_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(userData.full_name || userData.email)}&background=ef4444&color=fff`,
        city: userData.address?.split(',')[0] || '',
        bio: '',
        interests: [],
        userId: userData.id
      });

      return newProfile;
    } catch (error) {
      console.error('Error ensuring user profile:', error);
      throw error;
    }
  }

  /**
   * Gets user profile by userId (PUBLIC - anyone can read)
   * @param {string} userId - User ID
   * @returns {Object} Profile data
   */
  static async getProfileByUserId(userId) {
    try {
      const profiles = await Profile.filter({ userId: userId });
      return profiles.length > 0 ? profiles[0] : null;
    } catch (error) {
      console.error('Error getting profile by user ID:', error);
      return null;
    }
  }

  /**
   * Gets all profiles (PUBLIC - anyone can read)
   * @param {string} sortBy - Sort field (default: '-created_date')
   * @param {number} limit - Limit results
   * @returns {Array} Array of profiles
   */
  static async getAllProfiles(sortBy = '-created_date', limit = 50) {
    try {
      return await Profile.list(sortBy, limit);
    } catch (error) {
      console.error('Error getting all profiles:', error);
      return [];
    }
  }

  /**
   * Gets current user's profile, creating one if it doesn't exist
   * @returns {Object} Profile data
   */
  static async getCurrentUserProfile() {
    try {
      const userData = await User.me();
      if (!userData) {
        throw new Error('User not authenticated');
      }
      return await this.ensureUserProfile(userData);
    } catch (error) {
      console.error('Error getting current user profile:', error);
      throw error;
    }
  }

  /**
   * Updates user profile (PROTECTED - only owner can update)
   * @param {Object} updates - Profile updates
   * @returns {Object} Updated profile
   */
  static async updateCurrentUserProfile(updates) {
    try {
      // Get current authenticated user
      const currentUser = await User.me();
      if (!currentUser) {
        throw new Error('Authentication required to update profile');
      }

      // Get current user's profile
      const profile = await this.ensureUserProfile(currentUser);
      
      // Security check: Only allow updating own profile
      if (profile.userId !== currentUser.id) {
        throw new Error('Unauthorized: You can only update your own profile');
      }

      // Filter out any attempts to change userId (security measure)
      const safeUpdates = { ...updates };
      delete safeUpdates.userId;
      delete safeUpdates.id;
      delete safeUpdates.created_date;
      delete safeUpdates.updated_date;

      // Update profile
      const updatedProfile = await Profile.update(profile.id, safeUpdates);
      return updatedProfile;
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  }

  /**
   * Attempts to update a profile by userId (PROTECTED)
   * This will fail if the current user doesn't own the profile
   * @param {string} userId - Target user ID
   * @param {Object} updates - Profile updates
   * @returns {Object} Updated profile or throws error
   */
  static async updateProfileByUserId(userId, updates) {
    try {
      // Get current authenticated user
      const currentUser = await User.me();
      if (!currentUser) {
        throw new Error('Authentication required to update profile');
      }

      // Security check: Can only update own profile
      if (currentUser.id !== userId) {
        throw new Error('Unauthorized: You can only update your own profile');
      }

      return await this.updateCurrentUserProfile(updates);
    } catch (error) {
      console.error('Error updating profile by user ID:', error);
      throw error;
    }
  }

  /**
   * Search profiles by name or city (PUBLIC)
   * @param {string} query - Search query
   * @returns {Array} Matching profiles
   */
  static async searchProfiles(query) {
    try {
      const allProfiles = await this.getAllProfiles();
      const searchTerm = query.toLowerCase();
      
      return allProfiles.filter(profile => 
        profile.fullName?.toLowerCase().includes(searchTerm) ||
        profile.city?.toLowerCase().includes(searchTerm) ||
        profile.bio?.toLowerCase().includes(searchTerm)
      );
    } catch (error) {
      console.error('Error searching profiles:', error);
      return [];
    }
  }
}