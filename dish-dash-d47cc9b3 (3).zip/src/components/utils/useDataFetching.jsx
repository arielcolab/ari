import { useState, useEffect } from 'react';

export const useDataFetching = (fetchFn, dependencies = []) => {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const result = await fetchFn();
        setData(result);
      } catch (err) {
        console.log('Data fetching error:', err.message || err);
        setError(err);
        // Don't throw, just set error state
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, dependencies);

  return { data, isLoading, error };
};