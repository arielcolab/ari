
import React, { useState, useEffect } from "react";
import { User } from '@/api/entities';

// Comprehensive language translations for the app
export const translations = {
  en: {
    // Navigation
    home: "Home", search: "Search", post: "Post", cart: "Cart", profile: "Profile",

    // Common Actions & States
    save: "Save", cancel: "Cancel", loading: "Loading...", error: "Error", success: "Success",
    back: "Back", next: "Next", done: "Done", edit: "Edit", "delete": "Delete", add: "Add",
    remove: "Remove", seeAll: "See all", close: "Close", confirm: "Confirm", yes: "Yes",
    no: "No", saving: "Saving...", orders: "Orders", active: "Active", inactive: "Inactive",
    price: "Price", quantity: "Quantity", description: "Description", upload: "Upload",
    "new": "NEW", noImage: "No Image", hide: "Hide", there: "there", view: "View",
    select: "Select", none: "None", optional: "Optional", required: "Required",
    menu: "Menu", free: "Free",

    // App Navigation & Layout
    navigationError: "Navigation error occurred",
    pageNotFound: "Page not found",
    goHome: "Go to Home",
    somethingWentWrong: "Something went wrong",
    somethingWentWrongDescription: "We're sorry, but an unexpected error occurred. Please try reloading the app.",
    reloadApp: "Reload App",
    networkError: "Connection Error",
    networkErrorDescription: "Please check your internet connection and try again.",
    error_loading_restaurants: "Error loading restaurants",
    error_loading_services: "Error loading services",
    please_try_again_later: "Please try again later.",
    no_restaurants_found: "No restaurants match your criteria.",
    no_meal_plans_found: "No meal plans found matching your criteria.",

    // Splash Screen & Onboarding
    loadingDeliciousness: "Loading deliciousness...",
    welcomeToDishDash: "Welcome to DishDash",
    yourLocalFoodMarketplace: "Your Local Food Marketplace",
    getStarted: "Get Started",
    skipIntro: "Skip Introduction",
    loginForFavoritesToast: "Please log in to save favorites",

    // Authentication & User Management
    login: "Login", logout: "Log Out", signUp: "Sign Up", loginOrSignUp: "Login / Sign Up",
    welcome: "Welcome, {{name}}!", hiUser: "Hi {{name}}!", newUser: "New User",
    loginFailed: "Login failed. Please try again.", logoutFailed: "Logout failed. Please try again.",
    areYouSureLogout: "Are you sure you want to log out?", browsingAsGuest: "Browsing as Guest",
    joinToUnlock: "Join DishDash to save favorites, track orders, and get exclusive deals.",

    // Sorting & Filtering
    sortBy: "Sort by", sort: "Sort", filters: "Filters", clearFilters: "Clear Filters",
    apply: "Apply", resetAll: "Reset all",
    oldest: "Oldest", newest: "Newest", lowestPrice: "Lowest Price", highestPrice: "Highest Price",
    highestRating: "Highest Rating", lowestRating: "Lowest Rating", endingSoon: "Ending Soon",
    endingLast: "Ending Last", nearest: "Nearest", distance: "Distance", rating: "Rating",

    // Home Page Categories & Features
    feed: "Feed", community: "Community", marketplace: "Chefs Marketplace",
    freeRecipes: "Free Recipes", leftoversNearYou: "Leftovers Near You",
    cookingClasses: "Cooking Classes", startCooking: "Start Cooking",
    giveaways: "Giveaways", lastCallEats: "Last Call Eats",
    surplusGroceries: "Surplus Groceries", weeklyMealPrep: "Weekly Meal Prep",
    iWantToEatHealthy: "..I want to eat healthy", allMealPlans: "All meal plans",
    // Badges for Home page
    badgeHighRevenue: '💰 High Revenue',
    badgePremium: '💎 Premium',
    badgePopular: '🔥 Popular',
    badgeHighValue: '💰 High Value',
    badgeQuickSales: '⚡ Quick Sales',
    badgeVolume: '📦 Volume',
    badgeCommunity: '❤️ Community',

    // Search & Discovery
    searchPlaceholder: "Search for food, recipes, or classes", searchDishes: "Search dishes, cuisines, or cooks",
    searchRecipes: "Search recipes...", searchForClasses: "Search for classes",
    noResultsFound: "No results found", noResultsFoundDescription: "Try adjusting your search or filters",
    searchSuggestions: "Search Suggestions", popularSearches: "Popular Searches",
    iFeelLikeEating: "I feel like eating..", seeItems: "See items",

    // Restaurants specific
    restaurants: "Restaurants",
    restaurantNotFound: "Restaurant not found",
    fastestDelivery: "Fastest delivery",
    lowestDeliveryFee: "Lowest delivery fee",
    allRestaurants: "All restaurants",
    deliveryFee: "Delivery fee",
    deliveryTime: "Delivery time",
    minutesShort: "min",
    pizza: "Pizza",
    burgers: "Burgers",
    sushi: "Sushi",
    japanese: "Japanese",
    american: "American",
    italian: "Italian",
    healthy: "Healthy",
    salads: "Salads",
    freeDelivery: "Free delivery",
    under30min: "Under 30 min",
    under45min: "Under 45 min",

    // Product Details & Descriptions
    dishDetails: "Dish Details", cook: "Cook", chef: "Chef", delivery: "Delivery",
    allergens: "Allergens", availability: "Availability", prepTime: "Prep Time",
    cookTime: "Cook Time", servings: "Servings", difficulty: "Difficulty",
    ingredients: "Ingredients", instructions: "Instructions", nutritionalInfo: "Nutritional Info",
    reheatingInstructions: "Reheating Instructions", storageInstructions: "Storage Instructions",
    servingsUnit: "servings",
    cookedToday: "Cooked today",
    requiresHeating: "Requires heating",
    addToCart: "Add to Cart",
    addedToCartToast: "{{quantity}}x {{name}} added to cart!",
    addedToFavoritesToast: "Added to favorites",
    removedFromFavoritesToast: "Removed from favorites",
    favoritesErrorToast: "Error updating favorites",

    // Cart & Checkout specific
    serviceFee: "Service Fee",
    processingFee: "Processing Fee",
    tax: "Tax",
    placeOrder: "Place Order",
    processingOrder: "Processing Order...",
    orderPlaced: "Order placed successfully!",

    // Location & Geography
    location: "Location",
    browseAllCities: "Browse all cities",
    approxMilesAway: "Approx. {{distance}} miles away",
    approxKmAway: "Approx. {{distance}} km away", milesAway: "miles away", kmAway: "km away",
    currentLocation: "Current Location", yourCurrentLocation: "Your current location",
    useCurrentLocation: "Use current location", autoDetectLocation: "Auto-detect your location",
    selectLocation: "Select location",
    add_new_address: "Add a new address",

    // New address-related translations
    addNewAddress: "Add New Address",
    addressLabel: "Label (e.g. Home, Work)",
    streetAddress: "Street Address",
    city: "City",
    state: "State",
    zipCode: "Zip Code",
    country: "Country",
    saveAddress: "Save Address",
    addressAdded: "Address added successfully",
    errorAddingAddress: "Error adding address",
    addressAlreadyExists: "This address already exists",
    pleaseEnterAddressDetails: "Please enter street and city",
    locationError: "Unable to get location",

    // Time & Duration
    minutes: "minutes", hours: "hours", days: "days", weeks: "weeks",
    hoursLeft: "hours left", minutesLeft: "minutes left", daysLeft: "days left",
    week: "week", month: "month", year: "year", today: "Today",
    yesterday: "Yesterday", tomorrow: "Tomorrow", now: "Now", ago: "ago",

    // Categories & Tags
    all: "All", desserts: "Desserts", quick: "Quick", easy: "Easy", medium: "Medium",
    hard: "Hard", vegan: "Vegan", vegetarian: "Vegetarian", glutenFree: "Gluten Free",
    dairyFree: "Dairy Free", kosher: "Kosher", organic: "Organic",
    spicy: "Spicy", sweet: "Sweet", savory: "Savory", comfort: "Comfort Food",

    // Languages
    english: "English", hebrew: "Hebrew", arabic: "Arabic",
    french: "French", spanish: "Spanish", portuguese: "Portuguese",

    // Common UI
    showMore: "Show More", showLess: "Show Less", readMore: "Read More", readLess: "Read Less",
    viewAll: "View All", expand: "Expand", collapse: "Collapse", refresh: "Refresh",
    retry: "Retry", skip: "Skip", finish: "Finish", "continue": "Continue", proceed: "Proceed",

    // User interface elements
    savedAddresses: "Saved addresses",

    // Post Page
    createPost: "Create a Post",
    bulkUpload: "Bulk Upload",
    uploadMultipleDishes: "Upload multiple dishes from a file",
    marketplace: "Chefs Marketplace",
    sellFreshlyPrepared: "Sell freshly prepared meals",
    offerWeeklyMealPlans: "Offer weekly meal plans to customers",
    hostCookingEvent: "Host a cooking class or event",
    offerDiscountedFood: "Offer food at a discount before it expires",
    sellSurplusGroceries: "Sell surplus grocery items",
    leftovers: "Leftovers",
    offerDeliciousSurplus: "Offer your delicious surplus food",
    offerSurplusFoodFree: "Offer surplus food for free",
    shareCulinaryCreations: "Share your culinary creations with the community",

    // List Page Titles & Subtitles
    healthyMealsDelivered: "Healthy meals, prepared and delivered weekly",
    learnFromLocalChefs: "Learn new skills from talented local chefs",
    discountedFoodNearExpiry: "Great food at a discount before it's gone",
    discountedGroceryItems: "Save on groceries and reduce waste",
    deliciousFoodForLess: "Find delicious homemade leftovers for less",
    freeItemsForCommunity: "Share and receive free items in your community",
    discoverLocalChefs: "Discover and order from talented local chefs",
    serviceNotFound: "Service Not Found",

    // New Account Settings translations
    accountSettings: "Account Settings",
    accountPersonalization: "Account & Personalization",
    editProfile: "Edit Profile",
    editProfileDesc: "Name, photo, bio",
    languageRegion: "Language & Region",
    currency: "Currency",
    addresses: "Addresses",
    manageAddresses: "Manage saved addresses",
    dietaryPreferences: "Dietary Preferences",
    dietaryPreferencesDesc: "Allergies, diet type",
    notifications: "Notifications",
    notificationSettings: "Notification Settings",
    notificationSettingsDesc: "Manage all notifications",
    privacySafety: "Privacy & Safety",
    privacySettings: "Privacy Settings",
    privacySettingsDesc: "Control who sees your info",
    blockedUsers: "Blocked Users",
    blockedUsersDesc: "Manage blocked accounts",
    quickSettings: "Quick Settings",
    darkMode: "Dark Mode",
    darkModeDesc: "Use dark theme",
    autoLocation: "Auto-detect Location",
    autoLocationDesc: "Automatically find your location",
    allergenWarnings: "Allergen Warnings",
    allergenWarningsDesc: "Show allergen alerts",
    account: "Account",
    paymentMethods: "Payment Methods",
    paymentMethodsDesc: "Manage cards and payment",
    accountData: "Download My Data",
    accountDataDesc: "Export your account data",
    deleteAccount: "Delete Account",
    deleteAccountDesc: "Permanently delete your account",
    delete: "Delete",
    contactSupport: "Please contact support",
    settingsUpdated: "Settings updated",
    settingsUpdateError: "Error updating settings",
    featureComingSoon: "Feature coming soon",

    // Privacy Settings
    profileVisibility: "Profile Visibility",
    publicProfile: "Public",
    publicProfileDesc: "Anyone can see your profile",
    friendsOnly: "Friends Only",
    friendsOnlyDesc: "Only people you follow can see your profile",
    privateProfile: "Private",
    privateProfileDesc: "Only you can see your profile",
    contactInformation: "Contact Information",
    showEmail: "Show Email",
    showEmailDesc: "Let others see your email address",
    showPhone: "Show Phone",
    showPhoneDesc: "Let others see your phone number",
    showLocation: "Show Location",
    showLocationDesc: "Let others see your general location",
    activitySocial: "Activity & Social",
    allowMessages: "Allow Messages",
    allowMessagesDesc: "Let others send you messages",
    showActivity: "Show Activity",
    showActivityDesc: "Let others see your recent activity",
    showFavorites: "Show Favorites",
    showFavoritesDesc: "Let others see your favorite cooks",
    showOrders: "Show Order History",
    showOrdersDesc: "Let others see your order history",
    privacySettingsUpdated: "Privacy settings updated",
    privacySettingsError: "Error updating privacy settings",

    // Blocked Users
    searchBlockedUsers: "Search blocked users...",
    noBlockedUsers: "No blocked users",
    noBlockedUsersDesc: "You haven't blocked any users yet",
    noMatchingBlockedUsers: "No matching blocked users",
    tryDifferentSearch: "Try a different search term",
    userUnblocked: "User unblocked",
    unblockError: "Error unblocking user"
  },
  he: {
    // Navigation
    home: "בית", search: "חיפוש", post: "פרסום", cart: "עגלה", profile: "פרופיל",

    // Common
    save: "שמור", cancel: "ביטול", loading: "טוען...", error: "שגיאה", success: "הצלחה",
    back: "חזור", next: "הבא", done: "סיום", edit: "עריכה", "delete": "מחק", add: "הוסף",
    remove: "הסר", seeAll: "הצג הכל", close: "סגור", confirm: "אישור", yes: "כן",
    no: "לא", saving: "שומר...", orders: "הזמנות", active: "פעיל", inactive: "לא פעיל",
    price: "מחיר", quantity: "כמות", description: "תיאור", upload: "העלה",
    "new": "חדש", noImage: "אין תמונה", hide: "הסתר", there: "חבר/ה",
    view: "צפה", select: "בחר", none: "ללא", optional: "אופציונלי", required: "נדרש",
    menu: "תפריט", free: "חינם",

    // App Navigation & Layout
    somethingWentWrong: "משהו השתבש",
    somethingWentWrongDescription: "אנו מצטערים, אך אירעה שגיאה לא צפויה. אנא נסה לטעון מחדש את האפליקציה.",
    reloadApp: "טען מחדש",
    networkError: "שגיאת חיבור",
    networkErrorDescription: "אנא בדוק את חיבור האינטרנט שלך ונסה שוב.",
    error_loading_restaurants: "שגיאה בטעינת מסעדות",
    error_loading_services: "שגיאה בטעינת שירותים",
    please_try_again_later: "אנא נסה שוב מאוחר יותר.",
    no_restaurants_found: "לא נמצאו מסעדות התואמות לקריטריונים שלך.",
    no_meal_plans_found: "לא נמצאו תכניות ארוחות התואמות לקריטריונים שלך.",

    // Splash Screen & Onboarding
    loadingDeliciousness: "טוענים דברים טעימים...",
    loginForFavoritesToast: "יש להתחבר כדי לשמור מועדפים",

    // Restaurants specific
    restaurants: "מסעדות",
    restaurantNotFound: "המסעדה לא נמצאה",
    fastestDelivery: "המשלוח המהיר ביותר",
    lowestDeliveryFee: "דמי משלוח הנמוכים ביותר",
    allRestaurants: "כל המסעדות",
    deliveryFee: "דמי משלוח",
    deliveryTime: "זמן משלוח",
    minutesShort: "דק'",
    pizza: "פיצה",
    burgers: "המבורגרים",
    sushi: "סושי",
    japanese: "יפני",
    american: "אמריקאי",
    italian: "איטלקי",
    healthy: "בריא",
    salads: "סלטים",
    freeDelivery: "משלוח חינם",
    under30min: "פחות מ-30 דק'",
    under45min: "פחות מ-45 דק'",

    // Product Details & Descriptions
    servingsUnit: "מנות",
    cookedToday: "בושל היום",
    requiresHeating: "דורש חימום",
    addToCart: "הוסף לעגלה",
    addedToCartToast: "{{quantity}}x {{name}} נוסף לעגלה!",
    addedToFavoritesToast: "נוסף למועדפים",
    removedFromFavoritesToast: "הוסר מהמועדפים",
    favoritesErrorToast: "שגיאה בעדכון מועדפים",

    // Cart & Checkout specific
    serviceFee: "דמי שירות",
    processingFee: "דמי עיבוד",
    tax: "מס",
    placeOrder: "בצע הזמנה",
    processingOrder: "מעבד הזמנה...",
    orderPlaced: "ההזמנה בוצעה בהצלחה!",

    // Location & Geography
    location: "מיקום",
    browseAllCities: "עיין בכל הערים",
    add_new_address: "הוסף כתובת חדשה",

    // New address-related translations
    addNewAddress: "הוסף כתובת חדשה",
    addressLabel: "תווית (לדוגמה בית, עבודה)",
    streetAddress: "כתובת רחוב",
    city: "עיר",
    state: "מדינה/אזור",
    zipCode: "מיקוד",
    country: "מדינה",
    saveAddress: "שמור כתובת",
    addressAdded: "הכתובת נוספה בהצלחה",
    errorAddingAddress: "שגיאה בהוספת כתובת",
    addressAlreadyExists: "הכתובת הזו כבר קיימת",
    pleaseEnterAddressDetails: "אנא הזן רחוב ועיר",
    locationError: "לא ניתן לקבל מיקום",

    // Common translations
    all: "הכל", sort: "מיין", filters: "מסננים", newest: "החדש ביותר",
    highestRating: "הדירוג הגבוה ביותר", selectLocation: "בחר מיקום",
    useCurrentLocation: "השתמש במיקום נוכחי", autoDetectLocation: "זיהוי אוטומטי של מיקום",
    savedAddresses: "כתובות שמורות",
    weeklyMealPrep: "הכנת ארוחות שבועית",
    iWantToEatHealthy: "..בא לי לאכול בריא", allMealPlans: "כל תכניות הארוחות",
    marketplace: "שוק השפים", cookingClasses: "שיעורי בישול", giveaways: "למסירה",
    lastCallEats: "קריאה אחרונה", surplusGroceries: "שוק מצרכים עודפים",
    leftoversNearYou: "שאריות בקרבתך",

    // Badges for Home page
    badgeHighRevenue: '💰 הכנסה גבוהה',
    badgePremium: '💎 פרימיום',
    badgePopular: '🔥 פופולרי',
    badgeHighValue: '💰 תמורה גבוהה',
    badgeQuickSales: '⚡ מכירות מהירות',
    badgeVolume: '📦 כמות',
    badgeCommunity: '❤️ קהילה',

    // Post Page
    createPost: "יצירת פוסט",
    bulkUpload: "העלאה בכמות גדולה",
    uploadMultipleDishes: "העלה מספר מנות מקובץ",
    sellFreshlyPrepared: "מכור ארוחות טריות שהוכנו זה עתה",
    offerWeeklyMealPlans: "הצע תכנון ארוחות שבועי ללקוחות",
    hostCookingEvent: "אירח שיעור בישול או אירוע",
    offerDiscountedFood: "הצע אוכל באחוז הנחה לפני שנגמר הזמן",
    sellSurplusGroceries: "מכור מצרכים עודפים במחירים מוזלים",
    leftovers: "שאריות",
    offerDeliciousSurplus: "הצע את עודפי האוכל הטעימים שלך",
    offerSurplusFoodFree: "הצע עודפי מזון בחינם",
    shareCulinaryCreations: "שתף את היצירות הקולינריות שלך עם הקהילה",

    // List Page Titles & Subtitles
    healthyMealsDelivered: "ארוחות בריאות, מוכנות ומסופקות שבועית",
    learnFromLocalChefs: "למד מיומנויות חדשות משפים מקומיים מוכשרים",
    discountedFoodNearExpiry: "אוכל נהדר בהנחה לפני שהוא נגמר",
    discountedGroceryItems: "חסוך במצרכים והפחת בזבוז",
    deliciousFoodForLess: "מצא שאריות ביתיות טעימות בפחות",
    freeItemsForCommunity: "שתף וקבל פריטים בחינם בקהילה שלך",
    discoverLocalChefs: "גלה והזמן משפים מקומיים מוכשרים",
    serviceNotFound: "השירות לא נמצא",

    // New Account Settings translations
    accountSettings: "הגדרות חשבון",
    accountPersonalization: "חשבון והתאמה אישית",
    editProfile: "ערוך פרופיל",
    editProfileDesc: "שם, תמונה, ביוגרפיה",
    languageRegion: "שפה ואזור",
    currency: "מטבע",
    addresses: "כתובות",
    manageAddresses: "נהל כתובות שמורות",
    dietaryPreferences: "העדפות תזונתיות",
    dietaryPreferencesDesc: "אלרגיות, סוג דיאטה",
    notifications: "התראות",
    notificationSettings: "הגדרות התראות",
    notificationSettingsDesc: "נהל את כל ההתראות",
    privacySafety: "פרטיות ובטיחות",
    privacySettings: "הגדרות פרטיות",
    privacySettingsDesc: "שלוט מי רואה את המידע שלך",
    blockedUsers: "משתמשים חסומים",
    blockedUsersDesc: "נהל חשבונות חסומים",
    quickSettings: "הגדרות מהירות",
    darkMode: "מצב כהה",
    darkModeDesc: "השתמש בערכת נושא כהה",
    autoLocation: "זיהוי מיקום אוטומטי",
    autoLocationDesc: "מצא את מיקומך באופן אוטומטי",
    allergenWarnings: "אזהרות אלרגנים",
    allergenWarningsDesc: "הצג התראות אלרגנים",
    account: "חשבון",
    paymentMethods: "שיטות תשלום",
    paymentMethodsDesc: "נהל כרטיסים ותשלום",
    accountData: "הורד את הנתונים שלי",
    accountDataDesc: "ייצא את נתוני החשבון שלך",
    deleteAccount: "מחק חשבון",
    deleteAccountDesc: "מחק לצמיתות את חשבונך",
    delete: "מחק",
    contactSupport: "אנא פנה לתמיכה",
    settingsUpdated: "ההגדרות עודכנו",
    settingsUpdateError: "שגיאה בעדכון הגדרות",
    featureComingSoon: "תכונה בקרוב",

    // Privacy Settings
    profileVisibility: "נראות פרופיל",
    publicProfile: "ציבורי",
    publicProfileDesc: "כל אחד יכול לראות את הפרופיל שלך",
    friendsOnly: "חברים בלבד",
    friendsOnlyDesc: "רק אנשים שאתה עוקב אחריהם יכולים לראות את הפרופיל שלך",
    privateProfile: "פרטי",
    privateProfileDesc: "רק אתה יכול לראות את הפרופיל שלך",
    contactInformation: "פרטי התקשרות",
    showEmail: "הצג אימייל",
    showEmailDesc: "אפשר לאחרים לראות את כתובת האימייל שלך",
    showPhone: "הצג טלפון",
    showPhoneDesc: "אפשר לאחרים לראות את מספר הטלפון שלך",
    showLocation: "הצג מיקום",
    showLocationDesc: "אפשר לאחרים לראות את מיקומך הכללי",
    activitySocial: "פעילות וחברתי",
    allowMessages: "אפשר הודעות",
    allowMessagesDesc: "אפשר לאחרים לשלוח לך הודעות",
    showActivity: "הצג פעילות",
    showActivityDesc: "אפשר לאחרים לראות את הפעילות האחרונה שלך",
    showFavorites: "הצג מועדפים",
    showFavoritesDesc: "אפשר לאחרים לראות את השפים המועדפים עליך",
    showOrders: "הצג היסטוריית הזמנות",
    showOrdersDesc: "אפשר לאחרים לראות את היסטוריית ההזמנות שלך",
    privacySettingsUpdated: "הגדרות הפרטיות עודכנו",
    privacySettingsError: "שגיאה בעדכון הגדרות פרטיות",

    // Blocked Users
    searchBlockedUsers: "חפש משתמשים חסומים...",
    noBlockedUsers: "אין משתמשים חסומים",
    noBlockedUsersDesc: "עדיין לא חסמת אף משתמש",
    noMatchingBlockedUsers: "אין משתמשים חסומים תואמים",
    tryDifferentSearch: "נסה מונח חיפוש אחר",
    userUnblocked: "המשתמש שוחרר",
    unblockError: "שגיאה בשחרור משתמש"
  },
  ar: {
    // Navigation
    home: "الرئيسية", search: "البحث", post: "نشر", cart: "السلة", profile: "الملف الشخصي",

    // Common
    save: "حفظ", cancel: "إلغاء", loading: "جار التحميل...", error: "خطأ", success: "نجاح",
    back: "رجوع", next: "التالي", done: "تم", edit: "تعديل", "delete": "حذف", add: "إضافة",
    remove: "إزالة", seeAll: "عرض الكل", close: "إغلاق", confirm: "تأكيد", yes: "نعم",
    no: "لا", saving: "جار الحفظ...", orders: "الطلبات", active: "نشط", inactive: "غير نشط",
    price: "السعر", quantity: "الكمية", description: "الوصف", upload: "رفع",
    "new": "جديد", noImage: "لا توجد صورة", hide: "إخفاء", there: "هناك",
    view: "عرض", select: "تحديد", none: "لا يوجد", optional: "اختياري", required: "مطلوب",
    menu: "قائمة", free: "مجاني",

    // App Navigation & Layout
    somethingWentWrong: "حدث خطأ ما",
    somethingWentWrongDescription: "نحن آسفون، ولكن أيرعت شجاعة غير متوقعة. يرجى محاولة إعادة تحميل التطبيق.",
    reloadApp: "إعادة تحميل التطبيق",
    networkError: "خطأ في الاتصال",
    networkErrorDescription: "يرجى التحقق من اتصالك بالإنترنت والمحاولة مرة أخرى.",
    error_loading_restaurants: "خطأ في تحميل المطاعم",
    error_loading_services: "خطأ في تحميل الخدمات",
    please_try_again_later: "يرجى المحاولة مرة أخرى في وقت لاحق.",
    no_restaurants_found: "لم يتم العثور على مطاعم تطابق معاييرك.",
    no_meal_plans_found: "لم يتم العثور على خطط وجبات تطابق معاييرك.",

    // Splash Screen & Onboarding
    loadingDeliciousness: "جار تحميل الأطعمة اللذيذة...",
    loginForFavoritesToast: "الرجاء تسجيل الدخول لحفظ المفضلة",

    // Authentication & User Management
    login: "تسجيل الدخول", logout: "تسجيل الخروج", signUp: "التسجيل", loginOrSignUp: "تسجيل الدخول / التسجيل",
    welcome: "مرحباً بك، {{name}}!", hiUser: "أهلاً {{name}}!", newUser: "مستخدم جديد",
    loginFailed: "فشل تسجيل الدخول. يرجى المحاولة مرة أخرى.", logoutFailed: "فشل تسجيل الخروج. يرجى المحاولة مرة أخرى.",
    areYouSureLogout: "هل أنت متأكد أنك تريد تسجيل الخروج؟", browsingAsGuest: "تصفح كضيف",
    joinToUnlock: "انضم إلى DishDash لحفظ المفضلة وتتبع الطلبات والحصول على عروض حصرية.",

    // Sorting & Filtering
    sortBy: "ترتيب حسب", sort: "فرز", filters: "المرشحات", clearFilters: "مسح المرشحات",
    apply: "تطبيق", resetAll: "إعادة تعيين الكل",
    oldest: "الأقدم", newest: "الأحدث", lowestPrice: "أقل سعر", highestPrice: "أعلى سعر",
    highestRating: "أعلى تقييم", lowestRating: "أقل تقييم", endingSoon: "ينتهي قريبا",
    endingLast: "ينتهي آخرا", nearest: "الأقرب", distance: "المسافة", rating: "التقييم",

    // Home Page Categories & Features
    feed: "الخلاصات", community: "المجتمع", marketplace: "سوق الطهاة",
    freeRecipes: "وصفات مجانية", leftoversNearYou: "بقايا الطعام القريبة منك",
    cookingClasses: "دروس الطبخ", startCooking: "ابدأ الطبخ",
    giveaways: "توزيعات مجانية", lastCallEats: "آخر فرصة للأكل",
    surplusGroceries: "البقالة الفائضة", weeklyMealPrep: "تحضير وجبات أسبوعية",
    iWantToEatHealthy: "..أريد أن آكل صحياً", allMealPlans: "جميع خطط الوجبات",

    // Badges for Home page
    badgeHighRevenue: '💰 إيرادات عالية',
    badgePremium: '💎 مميز',
    badgePopular: '🔥 شعبي',
    badgeHighValue: '💰 قيمة عالية',
    badgeQuickSales: '⚡ مبيعات سريعة',
    badgeVolume: '📦 حجم',
    badgeCommunity: '❤️ مجتمع',

    // Search & Discovery
    searchPlaceholder: "ابحث عن طعام، وصفات، أو دروس", searchDishes: "ابحث عن أطباق، مطابخ، أو طهاة",
    searchRecipes: "ابحث عن وصفات...", searchForClasses: "ابحث عن دروس",
    noResultsFound: "لم يتم العثور على نتائج", noResultsFoundDescription: "حاول تعديل بحثك أو فلاترك",
    searchSuggestions: "اقتراحات البحث", popularSearches: "عمليات البحث الشائعة",
    iFeelLikeEating: "أشعر برغبة في تناول..", seeItems: "مشاهدة العناصر",

    // Restaurants specific
    restaurants: "مطاعم",
    restaurantNotFound: "المطعم غير موجود",
    fastestDelivery: "أسرع توصيل",
    lowestDeliveryFee: "أقل رسوم توصيل",
    allRestaurants: "جميع المطاعم",
    deliveryFee: "رسوم التوصيل",
    deliveryTime: "وقت التوصيل",
    minutesShort: "دقيقة",
    pizza: "بيتزا",
    burgers: "برجر",
    sushi: "سوشي",
    japanese: "ياباني",
    american: "أمريكي",
    italian: "إيطالي",
    healthy: "صحي",
    salads: "سلطات",
    freeDelivery: "توصيل مجاني",
    under30min: "أقل من 30 دقيقة",
    under45min: "أقل من 45 دقيقة",

    // Product Details & Descriptions
    dishDetails: "تفاصيل الطبق", cook: "طباخ", chef: "شيف", delivery: "توصيل",
    allergens: "مسببات الحساسية", availability: "التوفر", prepTime: "وقت التحضير",
    cookTime: "وقت الطهي", servings: "حصص", difficulty: "الصعوبة",
    ingredients: "المكونات", instructions: "التعليمات", nutritionalInfo: "المعلومات الغذائية",
    reheatingInstructions: "تعليمات إعادة التسخين", storageInstructions: "تعليمات التخزين",
    servingsUnit: "حصص",
    cookedToday: "طبخ اليوم",
    requiresHeating: "يتطلب تسخين",
    addToCart: "أضف إلى السلة",
    addedToCartToast: "{{quantity}}x {{name}} أضيفت إلى السلة!",
    addedToFavoritesToast: "أضيف إلى المفضلة",
    removedFromFavoritesToast: "أزيل من المفضلة",
    favoritesErrorToast: "خطأ في تحديث المفضلة",

    // Cart & Checkout specific
    serviceFee: "رسوم الخدمة",
    processingFee: "رسوم المعالجة",
    tax: "ضريبة",
    placeOrder: "تأكيد الطلب",
    processingOrder: "جاري معالجة الطلب...",
    orderPlaced: "تم تأكيد الطلب بنجاح!",

    // Location & Geography
    location: "الموقع",
    browseAllCities: "تصفح جميع المدن",
    approxMilesAway: "حوالي {{distance}} ميل بعيد",
    approxKmAway: "حوالي {{distance}} كم بعيد", milesAway: "ميل بعيد", kmAway: "كم بعيد",
    currentLocation: "الموقع الحالي", yourCurrentLocation: "موقعك الحالي",
    useCurrentLocation: "استخدام الموقع الحالي", autoDetectLocation: "الكشف التلقائي عن موقعك",
    selectLocation: "تحديد الموقع",
    add_new_address: "إضافة عنوان جديد",

    // New address-related translations
    addNewAddress: "إضافة عنوان جديد",
    addressLabel: "تسمية (مثل المنزل، العمل)",
    streetAddress: "عنوان الشارع",
    city: "المدينة",
    state: "الولاية",
    zipCode: "الرمز البريدي",
    country: "البلد",
    saveAddress: "حفظ العنوان",
    addressAdded: "تم إضافة العنوان بنجاح",
    errorAddingAddress: "خطأ في إضافة العنوان",
    addressAlreadyExists: "هذا العنوان موجود بالفعل",
    pleaseEnterAddressDetails: "يرجى إدخال الشارع والمدينة",
    locationError: "غير قادر على الحصول على الموقع",

    // Time & Duration
    minutes: "دقائق", hours: "ساعات", days: "أيام", weeks: "أسابيع",
    hoursLeft: "ساعات متبقية", minutesLeft: "دقائق متبقية", daysLeft: "أيام متبقية",
    week: "أسبوع", month: "شهر", year: "سنة", today: "اليوم",
    yesterday: "أمس", tomorrow: "غداً", now: "الآن", ago: "منذ",

    // Categories & Tags
    all: "الكل", desserts: "حلويات", quick: "سريع", easy: "سهل", medium: "متوسط",
    hard: "صعب", vegan: "نباتي صرف", vegetarian: "نباتي", glutenFree: "خالٍ من الغلوتين",
    dairyFree: "خالٍ من الألبان", kosher: "كوشر", organic: "عضوي",
    spicy: "حار", sweet: "حلو", savory: "مالح", comfort: "طعام مريح",

    // Languages
    english: "الإنجليزية", hebrew: "العبرية", arabic: "العربية",
    french: "الفرنسية", spanish: "الإسبانية", portuguese: "البرتغالية",

    // Common UI
    showMore: "عرض المزيد", showLess: "عرض أقل", readMore: "اقرأ المزيد", readLess: "اقرأ أقل",
    viewAll: "عرض الكل", expand: "توسيع", collapse: "طي", refresh: "تحديث",
    retry: "إعادة المحاولة", skip: "تخطي", finish: "إنهاء", "continue": "متابعة", proceed: "متابعة",

    // User interface elements
    savedAddresses: "العناوين المحفوظة",

    // Post Page
    createPost: "إنشاء منشور",
    bulkUpload: "تحميل مجمع",
    uploadMultipleDishes: "تحميل أطباق متعددة من ملف",
    marketplace: "سوق الطهاة",
    sellFreshlyPrepared: "بيع وجبات طازجة محضرة",
    offerWeeklyMealPlans: "تقديم خطط وجبات أسبوعية للعملاء",
    hostCookingEvent: "استضافة حصة طبخ أو حدث",
    offerDiscountedFood: "تقديم الطعام بخصم قبل انتهاء صلاحيته",
    sellSurplusGroceries: "بيع مواد البقالة الفائضة",
    leftovers: "بقايا الطعام",
    offerDeliciousSurplus: "تقديم فائض طعامك اللذيذ",
    offerSurplusFoodFree: "تقديم الطعام الفائض مجاناً",
    shareCulinaryCreations: "شارك إبداعاتك الطهوية مع المجتمع",

    // List Page Titles & Subtitles
    healthyMealsDelivered: "وجبات صحية، محضرة ومسلمة أسبوعياً",
    learnFromLocalChefs: "تعلم مهارات جديدة من طهاة محليين موهوبين",
    discountedFoodNearExpiry: "طعام رائع بخصم قبل نفاده",
    discountedGroceryItems: "وفر على البقالة وقلل النفايات",
    deliciousFoodForLess: "ابحث عن بقايا طعام منزلية لذيذة بأقل سعر",
    freeItemsForCommunity: "شارك واستلم سلع مجانية في مجتمعك",
    discoverLocalChefs: "اكتشف واطلب من طهاة محليين موهوبين",
    serviceNotFound: "الخدمة غير موجودة",

    // New Account Settings translations
    accountSettings: "إعدادات الحساب",
    accountPersonalization: "الحساب والتخصيص",
    editProfile: "تعديل الملف الشخصي",
    editProfileDesc: "الاسم، الصورة، السيرة الذاتية",
    languageRegion: "اللغة والمنطقة",
    currency: "العملة",
    addresses: "العناوين",
    manageAddresses: "إدارة العناوين المحفوظة",
    dietaryPreferences: "التفضيلات الغذائية",
    dietaryPreferencesDesc: "الحساسيات، نوع الحمية",
    notifications: "الإشعارات",
    notificationSettings: "إعدادات الإشعارات",
    notificationSettingsDesc: "إدارة جميع الإشعارات",
    privacySafety: "الخصوصية والأمان",
    privacySettings: "إعدادات الخصوصية",
    privacySettingsDesc: "التحكم في من يرى معلوماتك",
    blockedUsers: "المستخدمون المحظورون",
    blockedUsersDesc: "إدارة الحسابات المحظورة",
    quickSettings: "إعدادات سريعة",
    darkMode: "الوضع الداكن",
    darkModeDesc: "استخدام السمة الداكنة",
    autoLocation: "الكشف التلقائي عن الموقع",
    autoLocationDesc: "العثور تلقائياً على موقعك",
    allergenWarnings: "تحذيرات الحساسية",
    allergenWarningsDesc: "إظهار تنبيهات الحساسية",
    account: "الحساب",
    paymentMethods: "طرق الدفع",
    paymentMethodsDesc: "إدارة البطاقات والدفع",
    accountData: "تنزيل بياناتي",
    accountDataDesc: "تصدير بيانات حسابك",
    deleteAccount: "حذف الحساب",
    deleteAccountDesc: "حذف حسابك نهائياً",
    delete: "حذف",
    contactSupport: "الرجاء التواصل مع الدعم",
    settingsUpdated: "تم تحديث الإعدادات",
    settingsUpdateError: "خطأ في تحديث الإعدادات",
    featureComingSoon: "ميزة قادمة قريباً",

    // Privacy Settings
    profileVisibility: "رؤية الملف الشخصي",
    publicProfile: "عام",
    publicProfileDesc: "يمكن لأي شخص رؤية ملفك الشخصي",
    friendsOnly: "الأصدقاء فقط",
    friendsOnlyDesc: "يمكن فقط للأشخاص الذين تتابعهم رؤية ملفك الشخصي",
    privateProfile: "خاص",
    privateProfileDesc: "فقط أنت يمكنك رؤية ملفك الشخصي",
    contactInformation: "معلومات الاتصال",
    showEmail: "إظهار البريد الإلكتروني",
    showEmailDesc: "السماح للآخرين برؤية عنوان بريدك الإلكتروني",
    showPhone: "إظهار رقم الهاتف",
    showPhoneDesc: "السماح للآخرين برؤية رقم هاتفك",
    showLocation: "إظهار الموقع",
    showLocationDesc: "السماح للآخرين برؤية موقعك العام",
    activitySocial: "النشاط والتواصل الاجتماعي",
    allowMessages: "السماح بالرسائل",
    allowMessagesDesc: "السماح للآخرين بإرسال رسائل إليك",
    showActivity: "إظهار النشاط",
    showActivityDesc: "السماح للآخرين برؤية نشاطك الأخير",
    showFavorites: "إظهار المفضلة",
    showFavoritesDesc: "السماح للآخرين برؤية الطهاة المفضلين لديك",
    showOrders: "إظهار سجل الطلبات",
    showOrdersDesc: "السماح للآخرين برؤية سجل طلباتك",
    privacySettingsUpdated: "تم تحديث إعدادات الخصوصية",
    privacySettingsError: "خطأ في تحديث إعدادات الخصوصية",

    // Blocked Users
    searchBlockedUsers: "البحث عن المستخدمين المحظورين...",
    noBlockedUsers: "لا يوجد مستخدمون محظورون",
    noBlockedUsersDesc: "لم تقم بحظر أي مستخدمين بعد",
    noMatchingBlockedUsers: "لا يوجد مستخدمون محظورون مطابقون",
    tryDifferentSearch: "جرب مصطلح بحث مختلف",
    userUnblocked: "تم إلغاء حظر المستخدم",
    unblockError: "خطأ في إلغاء حظر المستخدم"
  },
  fr: {
    // Navigation
    home: "Accueil", search: "Recherche", post: "Publier", cart: "Panier", profile: "Profil",

    // Common
    save: "Sauvegarder", cancel: "Annuler", loading: "Chargement...", error: "Erreur", success: "Succès",
    back: "Retour", next: "Suivant", done: "Terminé", edit: "Modifier", "delete": "Supprimer", add: "Ajouter",
    remove: "Retirer", seeAll: "Voir tout", close: "Fermer", confirm: "Confirmer", yes: "Oui",
    no: "Non", saving: "Enregistrement...", orders: "Commandes", active: "Actif", inactive: "Inactif",
    price: "Prix", quantity: "Quantité", description: "Description", upload: "Télécharger",
    "new": "NOUVEAU", noImage: "Pas d'image", hide: "Masquer", there: "là",
    view: "Voir", select: "Sélectionner", none: "Aucun", optional: "Facultatif", required: "Obligatoire",
    menu: "Menu", free: "Gratuit",

    // App Navigation & Layout
    somethingWentWrong: "Quelque chose s'est mal passé",
    somethingWentWrongDescription: "Nous sommes désolés, mais une erreur inattendue est survenue. Veuillez essayer de recharger l'application.",
    reloadApp: "Recharger l'application",
    networkError: "Erreur de connexion",
    networkErrorDescription: "Veuillez vérifier votre connexion Internet et réessayer.",
    error_loading_restaurants: "Erreur lors du chargement des restaurants",
    error_loading_services: "Erreur lors du chargement des services",
    please_try_again_later: "Veuillez réessayer plus tard.",
    no_restaurants_found: "Aucun restaurant ne correspond à vos critères.",
    no_meal_plans_found: "Aucun plan de repas ne correspond à vos critères.",

    // Splash Screen & Onboarding
    loadingDeliciousness: "Chargement des délices...",
    welcomeToDishDash: "Bienvenue sur DishDash",
    yourLocalFoodMarketplace: "Votre marché alimentaire local",
    getStarted: "Commencer",
    skipIntro: "Passer l'introduction",
    loginForFavoritesToast: "Veuillez vous connecter pour enregistrer vos favoris",

    // Authentication & User Management
    login: "Connexion", logout: "Déconnexion", signUp: "S'inscrire", loginOrSignUp: "Connexion / Inscription",
    welcome: "Bienvenue, {{name}}!", hiUser: "Salut {{name}}!", newUser: "Nouvel utilisateur",
    loginFailed: "Échec de la connexion. Veuillez réessayer.", logoutFailed: "Échec de la déconnexion. Veuillez réessayer.",
    areYouSureLogout: "Êtes-vous sûr de vouloir vous déconnecter?", browsingAsGuest: "Navigation en tant qu'invité",
    joinToUnlock: "Rejoignez DishDash pour sauvegarder vos favoris, suivre vos commandes et obtenir des offres exclusives.",

    // Sorting & Filtering
    sortBy: "Trier par", sort: "Trier", filters: "Filtres", clearFilters: "Effacer les filtres",
    apply: "Appliquer", resetAll: "Tout réinitialiser",
    oldest: "Plus ancien", newest: "Le plus récent", lowestPrice: "Prix le plus bas", highestPrice: "Prix le plus élevé",
    highestRating: "Note la plus élevée", lowestRating: "Note la plus basse", endingSoon: "Bientôt terminé",
    endingLast: "Termine en dernier", nearest: "Le plus proche", distance: "Distance", rating: "Note",

    // Home Page Categories & Features
    feed: "Flux", community: "Communauté", marketplace: "Marché des Chefs",
    freeRecipes: "Recettes gratuites", leftoversNearYou: "Restes près de chez vous",
    cookingClasses: "Cours de cuisine", startCooking: "Commencer à cuisiner",
    giveaways: "Cadeaux", lastCallEats: "Dernière chance de manger",
    surplusGroceries: "Produits d'épicerie excédentaires", weeklyMealPrep: "Préparation de repas hebdomadaire",
    iWantToEatHealthy: "..Je veux manger sainement", allMealPlans: "Tous les plans de repas",

    // Badges for Home page
    badgeHighRevenue: '💰 Revenus élevés',
    badgePremium: '💎 Premium',
    badgePopular: '🔥 Populaire',
    badgeHighValue: '💰 Grande valeur',
    badgeQuickSales: '⚡ Ventes rapides',
    badgeVolume: '📦 Volume',
    badgeCommunity: '❤️ Communauté',

    // Search & Discovery
    searchPlaceholder: "Rechercher de la nourriture, des recettes ou des cours", searchDishes: "Rechercher des plats, des cuisines ou des chefs",
    searchRecipes: "Rechercher des recettes...", searchForClasses: "Rechercher des cours",
    noResultsFound: "Aucun résultat trouvé", noResultsFoundDescription: "Essayez d'ajuster votre recherche ou vos filtres",
    searchSuggestions: "Suggestions de recherche", popularSearches: "Recherches populaires",
    iFeelLikeEating: "J'ai envie de manger..", seeItems: "Voir les articles",

    // Restaurants specific
    restaurants: "Restaurants",
    restaurantNotFound: "Restaurant introuvable",
    fastestDelivery: "Livraison la plus rapide",
    lowestDeliveryFee: "Frais de livraison les plus bas",
    allRestaurants: "Tous les restaurants",
    deliveryFee: "Frais de livraison",
    deliveryTime: "Temps de livraison",
    minutesShort: "min",
    pizza: "Pizza",
    burgers: "Hamburguesas",
    sushi: "Sushi",
    japanese: "Japonais",
    american: "Américain",
    italian: "Italien",
    healthy: "Sain",
    salads: "Salades",
    freeDelivery: "Livraison gratuite",
    under30min: "Moins de 30 min",
    under45min: "Moins de 45 min",

    // Product Details & Descriptions
    dishDetails: "Détails du plat", cook: "Cuisinier", chef: "Chef", delivery: "Livraison",
    allergens: "Allergènes", availability: "Disponibilité", prepTime: "Temps de préparation",
    cookTime: "Temps de cuisson", servings: "Portions", difficulty: "Difficulté",
    ingredients: "Ingrédients", instructions: "Instructions", nutritionalInfo: "Informations nutritionnelles",
    reheatingInstructions: "Instructions de réchauffage", storageInstructions: "Instructions de stockage",
    servingsUnit: "portions",
    cookedToday: "Cuisiné aujourd'hui",
    requiresHeating: "Nécessite un réchauffage",
    addToCart: "Ajouter au panier",
    addedToCartToast: "{{quantity}}x {{name}} ajouté au panier !",
    addedToFavoritesToast: "Ajouté aux favoris",
    removedFromFavoritesToast: "Supprimé des favoris",
    favoritesErrorToast: "Erreur lors de la mise à jour des favoris",

    // Cart & Checkout specific
    serviceFee: "Frais de service",
    processingFee: "Frais de traitement",
    tax: "Taxe",
    placeOrder: "Passer la commande",
    processingOrder: "Traitement de la commande...",
    orderPlaced: "Commande passée avec succès!",

    // Location & Geography
    location: "Emplacement",
    browseAllCities: "Parcourir toutes les villes",
    approxMilesAway: "Environ {{distance}} miles de distance",
    approxKmAway: "Environ {{distance}} km de distance", milesAway: "km de distance", kmAway: "km de distance",
    currentLocation: "Emplacement actuel", yourCurrentLocation: "Votre emplacement actuel",
    useCurrentLocation: "Utiliser l'emplacement actuel", autoDetectLocation: "Détecter automatiquement votre emplacement",
    selectLocation: "Sélectionner l'emplacement",
    add_new_address: "Ajouter une nouvelle adresse",

    // New address-related translations
    // New address-related translations
    addNewAddress: "Ajouter une nouvelle adresse",
    addressLabel: "Étiquette (ex. Domicile, Travail)",
    streetAddress: "Adresse",
    city: "Ville",
    state: "État/Province",
    zipCode: "Code postal",
    country: "Pays",
    saveAddress: "Enregistrer l'adresse",
    addressAdded: "Adresse ajoutée avec succès",
    errorAddingAddress: "Erreur lors de l'ajout de l'adresse",
    addressAlreadyExists: "Cette adresse existe déjà",
    pleaseEnterAddressDetails: "Veuillez entrer la rue et la ville",
    locationError: "Impossible d'obtenir la position",


    // Time & Duration
    minutes: "minutes", hours: "heures", days: "jours", weeks: "semaines",
    hoursLeft: "heures restantes", minutesLeft: "minutes restantes", daysLeft: "jours restants",
    week: "semaine", month: "mois", year: "année", today: "Aujourd'hui",
    yesterday: "Hier", tomorrow: "Demain", now: "Maintenant", ago: "il y a",

    // Categories & Tags
    all: "Tout", desserts: "Desserts", quick: "Rapide", easy: "Facile", medium: "Moyen",
    hard: "Difficile", vegan: "Végétalien", vegetarian: "Végétarien", glutenFree: "Sans gluten",
    dairyFree: "Sans produits laitiers", kosher: "Casher", organic: "Biologique",
    spicy: "Épicé", sweet: "Sucré", savory: "Salé", comfort: "Plat réconfortant",

    // Languages
    english: "Anglais", hebrew: "Hébreu", arabic: "Arabe",
    french: "Français", spanish: "Espagnol", portuguese: "Portugais",

    // Common UI
    showMore: "Afficher plus", showLess: "Afficher moins", readMore: "Lire la suite", readLess: "Lire moins",
    viewAll: "Tout voir", expand: "Développer", collapse: "Réduire", refresh: "Actualiser",
    retry: "Réessayer", skip: "Passer", finish: "Terminer", "continue": "Continuer", proceed: "Procéder",

    // User interface elements
    savedAddresses: "Adresses enregistrées",

    // Post Page
    createPost: "Créer une publication",
    bulkUpload: "Téléchargement en masse",
    uploadMultipleDishes: "Télécharger plusieurs plats à partir d'un fichier",
    marketplace: "Marché des Chefs",
    sellFreshlyPrepared: "Vendre des repas fraîchement préparés",
    offerWeeklyMealPlans: "Proposer des plans de repas hebdomadaires aux clients",
    hostCookingEvent: "Organiser un cours de cuisine ou un événement",
    offerDiscountedFood: "Proposer des aliments à prix réduit avant expiration",
    sellSurplusGroceries: "Vendre des produits d'épicerie excédentaires",
    leftovers: "Restes",
    offerDeliciousSurplus: "Proposez vos délicieux excédents alimentaires",
    offerSurplusFoodFree: "Proposer de la nourriture excédentaire gratuitement",
    shareCulinaryCreations: "Partagez vos créations culinaires avec la communauté",

    // List Page Titles & Subtitles
    healthyMealsDelivered: "Repas sains, préparés et livrés chaque semaine",
    learnFromLocalChefs: "Apprenez de nouvelles compétences auprès de chefs locaux talentueux",
    discountedFoodNearExpiry: "De bons plats à prix réduit avant qu'ils ne soient partis",
    discountedGroceryItems: "Économisez sur l'épicerie et réduisez le gaspillage",
    deliciousFoodForLess: "Trouvez de délicieux restes faits maison pour moins cher",
    freeItemsForCommunity: "Partagez et recevez des articles gratuits dans votre communauté",
    discoverLocalChefs: "Découvrez et commandez auprès de chefs locaux talentueux",
    serviceNotFound: "Service non trouvé",

    // New Account Settings translations
    accountSettings: "Paramètres du compte",
    accountPersonalization: "Compte et Personnalisation",
    editProfile: "Modifier le profil",
    editProfileDesc: "Nom, photo, biographie",
    languageRegion: "Langue et Région",
    currency: "Devise",
    addresses: "Adresses",
    manageAddresses: "Gérer les adresses enregistrées",
    dietaryPreferences: "Préférences alimentaires",
    dietaryPreferencesDesc: "Allergies, type de régime",
    notifications: "Notifications",
    notificationSettings: "Paramètres de notification",
    notificationSettingsDesc: "Gérer toutes les notifications",
    privacySafety: "Confidentialité et Sécurité",
    privacySettings: "Paramètres de confidentialité",
    privacySettingsDesc: "Contrôler qui voit vos informations",
    blockedUsers: "Utilisateurs bloqués",
    blockedUsersDesc: "Gérer les comptes bloqués",
    quickSettings: "Paramètres rapides",
    darkMode: "Mode sombre",
    darkModeDesc: "Utiliser le thème sombre",
    autoLocation: "Détection automatique de la position",
    autoLocationDesc: "Localiser automatiquement votre position",
    allergenWarnings: "Alertes allergènes",
    allergenWarningsDesc: "Afficher les alertes allergènes",
    account: "Compte",
    paymentMethods: "Méthodes de paiement",
    paymentMethodsDesc: "Gérer les cartes et le paiement",
    accountData: "Télécharger mes données",
    accountDataDesc: "Exporter les données de votre compte",
    deleteAccount: "Supprimer le compte",
    deleteAccountDesc: "Supprimer définitivement votre compte",
    delete: "Supprimer",
    contactSupport: "Veuillez contacter le support",
    settingsUpdated: "Paramètres mis à jour",
    settingsUpdateError: "Erreur lors de la mise à jour des paramètres",
    featureComingSoon: "Fonctionnalité à venir",

    // Privacy Settings
    profileVisibility: "Visibilité du profil",
    publicProfile: "Public",
    publicProfileDesc: "Tout le monde peut voir votre profil",
    friendsOnly: "Amis seulement",
    friendsOnlyDesc: "Seules les personnes que vous suivez peuvent voir votre profil",
    privateProfile: "Privé",
    privateProfileDesc: "Seul vous pouvez voir votre profil",
    contactInformation: "Informations de contact",
    showEmail: "Afficher l'e-mail",
    showEmailDesc: "Permettre aux autres de voir votre adresse e-mail",
    showPhone: "Afficher le téléphone",
    showPhoneDesc: "Permettre aux autres de voir votre numéro de téléphone",
    showLocation: "Afficher la position",
    showLocationDesc: "Permettre aux autres de voir votre position générale",
    activitySocial: "Activité et Social",
    allowMessages: "Autoriser les messages",
    allowMessagesDesc: "Permettre aux autres de vous envoyer des messages",
    showActivity: "Afficher l'activité",
    showActivityDesc: "Permettre aux autres de voir votre activité récente",
    showFavorites: "Afficher les favoris",
    showFavoritesDesc: "Permettre aux autres de voir vos chefs préférés",
    showOrders: "Afficher l'historique des commandes",
    showOrdersDesc: "Permettre aux autres de voir votre historique de commandes",
    privacySettingsUpdated: "Paramètres de confidentialité mis à jour",
    privacySettingsError: "Erreur lors de la mise à jour des paramètres de confidentialité",

    // Blocked Users
    searchBlockedUsers: "Rechercher des utilisateurs bloqués...",
    noBlockedUsers: "Aucun utilisateur bloqué",
    noBlockedUsersDesc: "Vous n'avez bloqué aucun utilisateur pour l'instant",
    noMatchingBlockedUsers: "Aucun utilisateur bloqué correspondant",
    tryDifferentSearch: "Essayez un terme de recherche différent",
    userUnblocked: "Utilisateur débloqué",
    unblockError: "Erreur lors du déblocage de l'utilisateur"
  },
  es: {
    // Navigation
    home: "Inicio", search: "Buscar", post: "Publicar", cart: "Carrito", profile: "Perfil",

    // Common
    save: "Guardar", cancel: "Cancelar", loading: "Cargando...", error: "Error", success: "Éxito",
    back: "Atrás", next: "Siguiente", done: "Listo", edit: "Editar", "delete": "Eliminar", add: "Añadir",
    remove: "Quitar", seeAll: "Ver todo", close: "Cerrar", confirm: "Confirmar", yes: "Sí",
    no: "No", saving: "Guardando...", orders: "Pedidos", active: "Activo", inactive: "Inactivo",
    price: "Precio", quantity: "Cantidad", description: "Descripción", upload: "Subir",
    "new": "NUEVO", noImage: "Sin imagen", hide: "Ocultar", there: "ahí",
    view: "Ver", select: "Seleccionar", none: "Ninguno", optional: "Opcional", required: "Requerido",
    menu: "Menú", free: "Gratis",

    // App Navigation & Layout
    somethingWentWrong: "Algo salió mal",
    somethingWentWrongDescription: "Lo sentimos, pero ocurrió un error inesperado. Por favor, intente recargar la aplicación.",
    reloadApp: "Recargar aplicación",
    networkError: "Error de conexión",
    networkErrorDescription: "Por favor, verifique su conexión a Internet e intente nuevamente.",
    error_loading_restaurants: "Error al cargar restaurantes",
    error_loading_services: "Error al cargar servicios",
    please_try_again_later: "Por favor, inténtelo de nuevo más tarde.",
    no_restaurants_found: "No se encontraron restaurantes que coincidan con sus criterios.",
    no_meal_plans_found: "No se encontraron planes de comidas que coincidan con sus criterios.",

    // Splash Screen & Onboarding
    loadingDeliciousness: "Cargando delicias...",
    welcomeToDishDash: "Bienvenido a DishDash",
    yourLocalFoodMarketplace: "Tu Mercado de Alimentos Local",
    getStarted: "Empezar",
    skipIntro: "Saltar introducción",
    loginForFavoritesToast: "Por favor, inicie sesión para guardar favoritos",

    // Authentication & User Management
    login: "Iniciar Sesión", logout: "Cerrar Sesión", signUp: "Registrarse", loginOrSignUp: "Iniciar Sesión / Registrarse",
    welcome: "¡Bienvenido, {{name}}!", hiUser: "¡Hola {{name}}!", newUser: "Nuevo Usuario",
    loginFailed: "Inicio de sesión fallido. Por favor, inténtelo de nuevo.", logoutFailed: "Cierre de sesión fallido. Por favor, inténtelo de nuevo.",
    areYouSureLogout: "¿Está seguro que desea cerrar sesión?", browsingAsGuest: "Navegando como invitado",
    joinToUnlock: "Únete a DishDash para guardar favoritos, rastrear pedidos y obtener ofertas exclusivas.",

    // Sorting & Filtering
    sortBy: "Ordenar por", sort: "Ordenar", filters: "Filtros", clearFilters: "Borrar filtros",
    apply: "Aplicar", resetAll: "Reiniciar todo",
    oldest: "Más antiguo", newest: "Más nuevo", lowestPrice: "Precio más bajo", highestPrice: "Precio más alto",
    highestRating: "Calificación más alta", lowestRating: "Calificación más baja", endingSoon: "Termina pronto",
    endingLast: "Termina último", nearest: "Más cercano", distance: "Distancia", rating: "Calificación",

    // Home Page Categories & Features
    feed: "Feed", community: "Comunidad", marketplace: "Mercado de Chefs",
    freeRecipes: "Recetas Gratis", leftoversNearYou: "Sobras Cerca de Ti",
    cookingClasses: "Clases de Cocina", startCooking: "Empezar a Cocinar",
    giveaways: "Sorteos", lastCallEats: "Última Llamada para Comer",
    surplusGroceries: "Comestibles Excedentes", weeklyMealPrep: "Preparación de Comidas Semanal",
    iWantToEatHealthy: "..Quiero comer sano", allMealPlans: "Todos los planes de comidas",

    // Badges for Home page
    badgeHighRevenue: '💰 Altos ingresos',
    badgePremium: '💎 Premium',
    badgePopular: '🔥 Popular',
    badgeHighValue: '💰 Alto valor',
    badgeQuickSales: '⚡ Ventas rápidas',
    badgeVolume: '📦 Volumen',
    badgeCommunity: '❤️ Comunidad',

    // Search & Discovery
    searchPlaceholder: "Buscar comida, recetas o clases", searchDishes: "Buscar platos, cocinas o cocineros",
    searchRecipes: "Buscar recetas...", searchForClasses: "Buscar clases",
    noResultsFound: "No se encontraron resultados", noResultsFoundDescription: "Intente ajustar su búsqueda o filtros",
    searchSuggestions: "Sugerencias de búsqueda", popularSearches: "Búsquedas Populares",
    iFeelLikeEating: "Tengo ganas de comer..", seeItems: "Ver artículos",

    // Restaurants specific
    restaurants: "Restaurantes",
    restaurantNotFound: "Restaurante no encontrado",
    fastestDelivery: "Entrega más rápida",
    lowestDeliveryFee: "Tarifa de entrega más baja",
    allRestaurants: "Todos los restaurantes",
    deliveryFee: "Tarifa de entrega",
    deliveryTime: "Tiempo de entrega",
    minutesShort: "min",
    pizza: "Pizza",
    burgers: "Hamburguesas",
    sushi: "Sushi",
    japanese: "Japonés",
    american: "Americano",
    italian: "Italiano",
    healthy: "Saludable",
    salads: "Ensaladas",
    freeDelivery: "Envío gratis",
    under30min: "Menos de 30 min",
    under45min: "Menos de 45 min",

    // Product Details & Descriptions
    dishDetails: "Detalles del Plato", cook: "Cocinero", chef: "Chef", delivery: "Entrega",
    allergens: "Alérgenos", availability: "Disponibilidad", prepTime: "Tiempo de Preparación",
    cookTime: "Tiempo de Cocción", servings: "Porciones", difficulty: "Dificultad",
    ingredients: "Ingredientes", instructions: "Instrucciones", nutritionalInfo: "Información Nutricional",
    reheatingInstructions: "Instrucciones de Recalentamiento", storageInstructions: "Instrucciones de Almacenamiento",
    servingsUnit: "porciones",
    cookedToday: "Cocinado hoy",
    requiresHeating: "Requiere calentar",
    addToCart: "Añadir al carrito",
    addedToCartToast: "¡{{quantity}}x {{name}} añadido al carrito!",
    addedToFavoritesToast: "Añadido a favoritos",
    removedFromFavoritesToast: "Eliminado de favoritos",
    favoritesErrorToast: "Error al actualizar favoritos",

    // Cart & Checkout specific
    serviceFee: "Tarifa de servicio",
    processingFee: "Tarifa de procesamiento",
    tax: "Impuesto",
    placeOrder: "Realizar pedido",
    processingOrder: "Procesando pedido...",
    orderPlaced: "¡Pedido realizado con éxito!",

    // Location & Geography
    location: "Ubicación",
    browseAllCities: "Explorar todas las ciudades",
    approxMilesAway: "Aprox. a {{distance}} millas de distancia",
    approxKmAway: "Aprox. a {{distance}} km de distancia", milesAway: "millas de distancia", kmAway: "km de distancia",
    currentLocation: "Ubicación Actual", yourCurrentLocation: "Su ubicación actual",
    useCurrentLocation: "Usar ubicación actual", autoDetectLocation: "Detectar automáticamente su ubicación",
    selectLocation: "Seleccionar ubicación",
    add_new_address: "Añadir una nueva dirección",

    // New address-related translations
    addNewAddress: "Añadir nueva dirección",
    addressLabel: "Etiqueta (ej. Casa, Trabajo)",
    streetAddress: "Dirección",
    city: "Ciudad",
    state: "Estado",
    zipCode: "Código Postal",
    country: "País",
    saveAddress: "Guardar dirección",
    addressAdded: "Dirección añadida con éxito",
    errorAddingAddress: "Error al añadir dirección",
    addressAlreadyExists: "Esta dirección ya existe",
    pleaseEnterAddressDetails: "Por favor, introduzca la calle y la ciudad",
    locationError: "No se puede obtener la ubicación",

    // Time & Duration
    minutes: "minutos", hours: "horas", days: "días", weeks: "semanas",
    hoursLeft: "horas restantes", minutesLeft: "minutos restantes", daysLeft: "días restantes",
    week: "semana", month: "mes", year: "año", today: "Hoy",
    yesterday: "Ayer", tomorrow: "Mañana", now: "Ahora", ago: "hace",

    // Categories & Tags
    all: "Todo", desserts: "Postres", quick: "Rápido", easy: "Fácil", medium: "Medio",
    hard: "Difícil", vegan: "Vegano", vegetarian: "Vegetariano", glutenFree: "Sin Gluten",
    dairyFree: "Sin Lácteos", kosher: "Kosher", organic: "Orgánico",
    spicy: "Picante", sweet: "Dulce", savory: "Salado", comfort: "Comida Reconfortante",

    // Languages
    english: "Inglés", hebrew: "Hebreo", arabic: "Árabe",
    french: "Francés", spanish: "Español", portuguese: "Portugués",

    // Common UI
    showMore: "Mostrar Más", showLess: "Mostrar Menos", readMore: "Leer Más", readLess: "Leer Menos",
    viewAll: "Ver Todo", expand: "Expandir", collapse: "Contraer", refresh: "Actualizar",
    retry: "Reintentar", skip: "Saltar", finish: "Finalizar", "continue": "Continuar", proceed: "Proceder",

    // User interface elements
    savedAddresses: "Direcciones guardadas",

    // Post Page
    createPost: "Crear una publicación",
    bulkUpload: "Carga masiva",
    uploadMultipleDishes: "Subir múltiples platos desde un archivo",
    marketplace: "Mercado de Chefs",
    sellFreshlyPrepared: "Vender comidas recién preparadas",
    offerWeeklyMealPlans: "Ofrecer planes de comidas semanales a los clientes",
    hostCookingEvent: "Organizar una clase de cocina o evento",
    offerDiscountedFood: "Ofrecer comida con descuento antes de que caduque",
    sellSurplusGroceries: "Vender productos de supermercado excedentes",
    leftovers: "Sobras",
    offerDeliciousSurplus: "Ofrece tu deliciosa comida sobrante",
    offerSurplusFoodFree: "Ofrecer comida sobrante gratis",
    shareCulinaryCreations: "Comparte tus creaciones culinarias con la comunidad",

    // List Page Titles & Subtitles
    healthyMealsDelivered: "Comidas saludables, preparadas y entregadas semanalmente",
    learnFromLocalChefs: "Aprende nuevas habilidades de talentosos chefs locales",
    discountedFoodNearExpiry: "Excelente comida con descuento antes de que se agote",
    discountedGroceryItems: "Ahorra en comestibles y reduce el desperdicio",
    deliciousFoodForLess: "Encuentra deliciosas sobras caseras por menos",
    freeItemsForCommunity: "Comparte y recibe artículos gratis en tu comunidad",
    discoverLocalChefs: "Descubre y pide a talentosos chefs locales",
    serviceNotFound: "Servicio no encontrado",

    // New Account Settings translations
    accountSettings: "Configuración de la cuenta",
    accountPersonalization: "Cuenta y Personalización",
    editProfile: "Editar perfil",
    editProfileDesc: "Nombre, foto, biografía",
    languageRegion: "Idioma y Región",
    currency: "Moneda",
    addresses: "Direcciones",
    manageAddresses: "Administrar direcciones guardadas",
    dietaryPreferences: "Preferencias dietéticas",
    dietaryPreferencesDesc: "Alergias, tipo de dieta",
    notifications: "Notificaciones",
    notificationSettings: "Configuración de notificaciones",
    notificationSettingsDesc: "Administrar todas las notificaciones",
    privacySafety: "Privacidad y Seguridad",
    privacySettings: "Configuración de privacidad",
    privacySettingsDesc: "Controlar quién ve su información",
    blockedUsers: "Usuarios bloqueados",
    blockedUsersDesc: "Administrar cuentas bloqueadas",
    quickSettings: "Configuración rápida",
    darkMode: "Modo oscuro",
    darkModeDesc: "Usar tema oscuro",
    autoLocation: "Detección automática de ubicación",
    autoLocationDesc: "Encontrar automáticamente su ubicación",
    allergenWarnings: "Advertencias de alérgenos",
    allergenWarningsDesc: "Mostrar alertas de alérgenos",
    account: "Cuenta",
    paymentMethods: "Métodos de pago",
    paymentMethodsDesc: "Administrar tarjetas y pagos",
    accountData: "Descargar mis datos",
    accountDataDesc: "Exportar los datos de su cuenta",
    deleteAccount: "Eliminar cuenta",
    deleteAccountDesc: "Eliminar permanentemente su cuenta",
    delete: "Eliminar",
    contactSupport: "Por favor contacte a soporte",
    settingsUpdated: "Configuración actualizada",
    settingsUpdateError: "Error al actualizar la configuración",
    featureComingSoon: "Función próximamente",

    // Privacy Settings
    profileVisibility: "Visibilidad del perfil",
    publicProfile: "Público",
    publicProfileDesc: "Cualquiera puede ver su perfil",
    friendsOnly: "Solo amigos",
    friendsOnlyDesc: "Solo las personas que sigues pueden ver tu perfil",
    privateProfile: "Privado",
    privateProfileDesc: "Solo usted puede ver su perfil",
    contactInformation: "Información de contacto",
    showEmail: "Mostrar correo electrónico",
    showEmailDesc: "Permitir que otros vean su dirección de correo electrónico",
    showPhone: "Mostrar teléfono",
    showPhoneDesc: "Permitir que otros vean su número de teléfono",
    showLocation: "Mostrar ubicación",
    showLocationDesc: "Permitir que otros vean su ubicación general",
    activitySocial: "Actividad y Social",
    allowMessages: "Permitir mensajes",
    allowMessagesDesc: "Permitir que otros le envíen mensajes",
    showActivity: "Mostrar actividad",
    showActivityDesc: "Permitir que otros vean su actividad reciente",
    showFavorites: "Mostrar favoritos",
    showFavoritesDesc: "Permitir que otros vean sus cocineros favoritos",
    showOrders: "Mostrar historial de pedidos",
    showOrdersDesc: "Permitir que otros vean su historial de pedidos",
    privacySettingsUpdated: "Configuración de privacidad actualizada",
    privacySettingsError: "Error al actualizar la configuración de privacidad",

    // Blocked Users
    searchBlockedUsers: "Buscar usuarios bloqueados...",
    noBlockedUsers: "No hay usuarios bloqueados",
    noBlockedUsersDesc: "Aún no ha bloqueado a ningún usuario",
    noMatchingBlockedUsers: "No hay usuarios bloqueados coincidentes",
    tryDifferentSearch: "Intente un término de búsqueda diferente",
    userUnblocked: "Usuario desbloqueado",
    unblockError: "Error al desbloquear usuario"
  },
  pt: {
    // Navigation
    home: "Início", search: "Busca", post: "Postar", cart: "Carrinho", profile: "Perfil",

    // Common
    save: "Salvar", cancel: "Cancelar", loading: "Carregando...", error: "Erro", success: "Sucesso",
    back: "Voltar", next: "Próximo", done: "Feito", edit: "Editar", "delete": "Deletar", add: "Adicionar",
    remove: "Remover", seeAll: "Ver tudo", close: "Fechar", confirm: "Confirmar", yes: "Sim",
    no: "Não", saving: "Salvando...", orders: "Pedidos", active: "Ativo", inactive: "Inativo",
    price: "Preço", quantity: "Quantidade", description: "Descrição", upload: "Upload",
    "new": "NOVO", noImage: "Sem Imagem", hide: "Ocultar", there: "lá",
    view: "Ver", select: "Selecionar", none: "Nenhum", optional: "Opcional", required: "Obrigatório",
    menu: "Menu", free: "Grátis",

    // App Navigation & Layout
    somethingWentWrong: "Algo deu errado",
    somethingWentWrongDescription: "Pedimos desculpas, mas ocorreu um erro inesperado. Por favor, tente recarregar o aplicativo.",
    reloadApp: "Recarregar aplicativo",
    networkError: "Erro de conexão",
    networkErrorDescription: "Por favor, verifique sua conexão com a internet e tente novamente.",
    error_loading_restaurants: "Erro ao carregar restaurantes",
    error_loading_services: "Erro ao carregar serviços",
    please_try_again_later: "Por favor, tente novamente mais tarde.",
    no_restaurants_found: "Nenhum restaurante corresponde aos seus critérios.",
    no_meal_plans_found: "Nenhum plano de refeição corresponde aos seus critérios.",

    // Splash Screen & Onboarding
    loadingDeliciousness: "Carregando delícias...",
    welcomeToDishDash: "Bem-vindo ao DishDash",
    yourLocalFoodMarketplace: "Seu Mercado Local de Alimentos",
    getStarted: "Começar",
    skipIntro: "Pular Introdução",
    loginForFavoritesToast: "Por favor, faça login para salvar favoritos",

    // Authentication & User Management
    login: "Entrar", logout: "Sair", signUp: "Cadastrar", loginOrSignUp: "Entrar / Cadastrar",
    welcome: "Bem-vindo, {{name}}!", hiUser: "Olá {{name}}!", newUser: "Novo Usuário",
    loginFailed: "Falha no login. Por favor, tente novamente.", logoutFailed: "Falha ao sair. Por favor, tente novamente.",
    areYouSureLogout: "Tem certeza que deseja sair?", browsingAsGuest: "Navegando como Convidado",
    joinToUnlock: "Junte-se ao DishDash para salvar favoritos, acompanhar pedidos e obter ofertas exclusivas.",

    // Sorting & Filtering
    sortBy: "Ordenar por", sort: "Ordenar", filters: "Filtros", clearFilters: "Limpar Filtros",
    apply: "Aplicar", resetAll: "Redefinir tudo",
    oldest: "Mais antigo", newest: "Mais novo", lowestPrice: "Preço mais baixo", highestPrice: "Preço mais alto",
    highestRating: "Maior avaliação", lowestRating: "Menor avaliação", endingSoon: "Termina em breve",
    endingLast: "Termina por último", nearest: "Mais próximo", distance: "Distância", rating: "Avaliação",

    // Home Page Categories & Features
    feed: "Feed", community: "Comunidade", marketplace: "Mercado de Chefs",
    freeRecipes: "Receitas Gratuitas", leftoversNearYou: "Sobras Perto de Você",
    cookingClasses: "Aulas de Culinária", startCooking: "Começar a Cozinhar",
    giveaways: "Doações", lastCallEats: "Última Chamada para Comer",
    surplusGroceries: "Excedentes de Mercearia", weeklyMealPrep: "Preparo de Refeições Semanal",
    iWantToEatHealthy: "..Eu quero comer saudável", allMealPlans: "Todos os planos de refeições",

    // Badges for Home page
    badgeHighRevenue: '💰 Alta Receita',
    badgePremium: '💎 Premium',
    badgePopular: '🔥 Popular',
    badgeHighValue: '💰 Alto Valor',
    badgeQuickSales: '⚡ Vendas Rápidas',
    badgeVolume: '📦 Volume',
    badgeCommunity: '❤️ Comunidade',

    // Search & Discovery
    searchPlaceholder: "Buscar comida, receitas ou aulas", searchDishes: "Buscar pratos, culinárias ou cozinheiros",
    searchRecipes: "Buscar receitas...", searchForClasses: "Buscar aulas",
    noResultsFound: "Nenhum resultado encontrado", noResultsFoundDescription: "Tente ajustar sua busca ou filtros",
    searchSuggestions: "Sugestões de Busca", popularSearches: "Buscas Populares",
    iFeelLikeEating: "Eu sinto vontade de comer..", seeItems: "Ver itens",

    // Restaurants specific
    restaurants: "Restaurantes",
    restaurantNotFound: "Restaurante não encontrado",
    fastestDelivery: "Entrega mais rápida",
    lowestDeliveryFee: "Menor taxa de entrega",
    allRestaurants: "Todos os restaurantes",
    deliveryFee: "Taxa de entrega",
    deliveryTime: "Tempo de entrega",
    minutesShort: "min",
    pizza: "Pizza",
    burgers: "Hambúrgueres",
    sushi: "Sushi",
    japanese: "Japonês",
    american: "Americano",
    italian: "Italiano",
    healthy: "Saudável",
    salads: "Saladas",
    freeDelivery: "Entrega grátis",
    under30min: "Menos de 30 min",
    under45min: "Menos de 45 min",

    // Product Details & Descriptions
    dishDetails: "Detalhes do Prato", cook: "Cozinheiro", chef: "Chef", delivery: "Entrega",
    allergens: "Alergênicos", availability: "Disponibilidade", prepTime: "Tempo de Preparo",
    cookTime: "Tempo de Cozimento", servings: "Porções", difficulty: "Dificuldade",
    ingredients: "Ingredientes", instructions: "Instruções", nutritionalInfo: "Informações Nutricionais",
    reheatingInstructions: "Instruções de Reaquecimento", storageInstructions: "Instruções de Armazenamento",
    servingsUnit: "porções",
    cookedToday: "Cozinhado hoje",
    requiresHeating: "Requer aquecimento",
    addToCart: "Adicionar ao carrinho",
    addedToCartToast: "{{quantity}}x {{name}} adicionado ao carrinho!",
    addedToFavoritesToast: "Adicionado aos favoritos",
    removedFromFavoritesToast: "Removido dos favoritos",
    favoritesErrorToast: "Erro ao atualizar favoritos",

    // Cart & Checkout specific
    serviceFee: "Taxa de serviço",
    processingFee: "Taxa de processamento",
    tax: "Imposto",
    placeOrder: "Fazer pedido",
    processingOrder: "Processando pedido...",
    orderPlaced: "Pedido realizado com sucesso!",

    // Location & Geography
    location: "Localização",
    browseAllCities: "Navegar por todas as cidades",
    approxMilesAway: "Aprox. {{distance}} milhas de distância",
    approxKmAway: "Aprox. {{distance}} km de distância", milesAway: "milhas de distância", kmAway: "km de distância",
    currentLocation: "Localização Atual", yourCurrentLocation: "Sua localização atual",
    useCurrentLocation: "Usar localização atual", autoDetectLocation: "Detectar automaticamente sua localização",
    selectLocation: "Selecionar localização",
    add_new_address: "Adicionar novo endereço",

    // Time & Duration
    minutes: "minutos", hours: "horas", days: "dias", weeks: "semanas",
    hoursLeft: "horas restantes", minutesLeft: "minutos restantes", daysLeft: "dias restantes",
    week: "semana", month: "mês", year: "ano", today: "Hoje",
    yesterday: "Ontem", tomorrow: "Amanhã", now: "Agora", ago: "atrás",

    // Categories & Tags
    all: "Tudo", desserts: "Sobremesas", quick: "Rápido", easy: "Fácil", medium: "Médio",
    hard: "Difícil", vegan: "Vegano", vegetarian: "Vegetariano", glutenFree: "Sem Glúten",
    dairyFree: "Sem Laticínios", kosher: "Kosher", organic: "Orgânico",
    spicy: "Picante", sweet: "Doce", savory: "Salgado", comfort: "Comida Conforto",

    // Languages
    english: "Inglês", hebrew: "Hebraico", arabic: "Árabe",
    french: "Francês", spanish: "Espanhol", portuguese: "Português",

    // Common UI
    showMore: "Mostrar Mais", showLess: "Mostrar Menos", readMore: "Ler Mais", readLess: "Ler Menos",
    viewAll: "Ver Tudo", expand: "Expandir", collapse: "Recolher", refresh: "Atualizar",
    retry: "Tentar novamente", skip: "Pular", finish: "Finalizar", "continue": "Continuar", proceed: "Prosseguir",

    // User interface elements
    savedAddresses: "Endereços salvos",

    // Post Page
    createPost: "Criar uma Publicação",
    bulkUpload: "Carregamento em massa",
    uploadMultipleDishes: "Carregar vários pratos de um arquivo",
    marketplace: "Mercado de Chefs",
    sellFreshlyPrepared: "Vender refeições recém-preparadas",
    offerWeeklyMealPlans: "Oferecer planos de refeição semanais aos clientes",
    hostCookingEvent: "Organizar uma aula de culinária ou evento",
    offerDiscountedFood: "Oferecer comida com desconto antes de expirar",
    sellSurplusGroceries: "Vender itens de mercearia excedentes",
    leftovers: "Sobras",
    offerDeliciousSurplus: "Ofereça sua deliciosa comida excedente",
    offerSurplusFoodFree: "Oferecer comida excedente gratuitamente",
    shareCulinaryCreations: "Compartilhe suas criações culinárias com a comunidade",

    // List Page Titles & Subtitles
    healthyMealsDelivered: "Refeições saudáveis, preparadas e entregues semanalmente",
    learnFromLocalChefs: "Aprenda novas habilidades com talentosos chefs locais",
    discountedFoodNearExpiry: "Ótima comida com desconto antes que acabe",
    discountedGroceryItems: "Economize em mercearia e reduza o desperdício",
    deliciousFoodForLess: "Encontre deliciosas sobras caseiras por menos",
    freeItemsForCommunity: "Compartilhe e receba itens gratuitos em sua comunidade",
    discoverLocalChefs: "Descubra e peça a talentosos chefs locais",
    serviceNotFound: "Serviço não encontrado",

    // New Account Settings translations
    accountSettings: "Configurações da Conta",
    accountPersonalization: "Conta e Personalização",
    editProfile: "Editar Perfil",
    editProfileDesc: "Nome, foto, biografia",
    languageRegion: "Idioma e Região",
    currency: "Moeda",
    addresses: "Endereços",
    manageAddresses: "Gerenciar endereços salvos",
    dietaryPreferences: "Preferências Alimentares",
    dietaryPreferencesDesc: "Alergias, tipo de dieta",
    notifications: "Notificações",
    notificationSettings: "Configurações de Notificação",
    notificationSettingsDesc: "Gerenciar todas as notificações",
    privacySafety: "Privacidade e Segurança",
    privacySettings: "Configurações de Privacidade",
    privacySettingsDesc: "Controlar quem vê suas informações",
    blockedUsers: "Usuários Bloqueados",
    blockedUsersDesc: "Gerenciar contas bloqueadas",
    quickSettings: "Configurações Rápidas",
    darkMode: "Modo Escuro",
    darkModeDesc: "Usar tema escuro",
    autoLocation: "Detecção Automática de Localização",
    autoLocationDesc: "Encontrar automaticamente sua localização",
    allergenWarnings: "Alertas de Alergênicos",
    allergenWarningsDesc: "Mostrar alertas de alergênicos",
    account: "Conta",
    paymentMethods: "Métodos de Pagamento",
    paymentMethodsDesc: "Gerenciar cartões e pagamento",
    accountData: "Baixar Meus Dados",
    accountDataDesc: "Exportar os dados da sua conta",
    deleteAccount: "Excluir Conta",
    deleteAccountDesc: "Excluir permanentemente sua conta",
    delete: "Excluir",
    contactSupport: "Por favor, entre em contato com o suporte",
    settingsUpdated: "Configurações atualizadas",
    settingsUpdateError: "Erro ao atualizar configurações",
    featureComingSoon: "Recurso em breve",

    // Privacy Settings
    profileVisibility: "Visibilidade do Perfil",
    publicProfile: "Público",
    publicProfileDesc: "Qualquer um pode ver seu perfil",
    friendsOnly: "Apenas Amigos",
    friendsOnlyDesc: "Apenas pessoas que você segue podem ver seu perfil",
    privateProfile: "Privado",
    privateProfileDesc: "Apenas você pode ver seu perfil",
    contactInformation: "Informações de Contato",
    showEmail: "Mostrar E-mail",
    showEmailDesc: "Permitir que outros vejam seu endereço de e-mail",
    showPhone: "Mostrar Telefone",
    showPhoneDesc: "Permitir que outros vejam seu número de telefone",
    showLocation: "Mostrar Localização",
    showLocationDesc: "Permitir que outros vejam sua localização geral",
    activitySocial: "Atividade e Social",
    allowMessages: "Permitir Mensagens",
    allowMessagesDesc: "Permitir que outros enviem mensagens para você",
    showActivity: "Mostrar Atividade",
    showActivityDesc: "Permitir que outros vejam sua atividade recente",
    showFavorites: "Mostrar Favoritos",
    showFavoritesDesc: "Permitir que outros vejam seus cozinheiros favoritos",
    showOrders: "Mostrar Histórico de Pedidos",
    showOrdersDesc: "Permitir que outros vejam seu histórico de pedidos",
    privacySettingsUpdated: "Configurações de privacidade atualizadas",
    privacySettingsError: "Erro ao atualizar configurações de privacidade",

    // Blocked Users
    searchBlockedUsers: "Pesquisar usuários bloqueados...",
    noBlockedUsers: "Nenhum usuário bloqueado",
    noBlockedUsersDesc: "Você ainda não bloqueou nenhum usuário",
    noMatchingBlockedUsers: "Nenhum usuário bloqueado correspondente",
    tryDifferentSearch: "Tente um termo de pesquisa diferente",
    userUnblocked: "Usuário desbloqueado",
    unblockError: "Erro ao desbloquear usuário"
  }
};

// Hook to use translations
export const useTranslation = () => {
  // Try to get language from localStorage, fallback to browser language, then 'en'
  const getInitialLanguage = () => {
    if (typeof window !== 'undefined') {
      const savedLang = localStorage.getItem('appLanguage');
      if (savedLang && translations[savedLang]) {
        return savedLang;
      }
      const browserLang = navigator.language.split('-')[0];
      if (translations[browserLang]) {
        return browserLang;
      }
    }
    return 'en';
  };

  const [currentLanguage, setCurrentLanguageState] = useState(getInitialLanguage);

  useEffect(() => {
    const updateUserLocale = async () => {
      try {
        const user = await User.me();
        if (user && user.locale !== currentLanguage) {
          await User.updateMyUserData({ locale: currentLanguage });
        }
      } catch (e) {
        // User not logged in or API error, gracefully ignore
      }
    };
    updateUserLocale();
  }, [currentLanguage]);

  const t = (key, fallback = '') => {
    return translations[currentLanguage]?.[key] || translations.en[key] || fallback || key;
  };

  const setLanguage = (lang) => {
    if (translations[lang]) {
      localStorage.setItem('appLanguage', lang);
      setCurrentLanguageState(lang);
      if (lang === 'ar' || lang === 'he') {
        document.documentElement.dir = 'rtl';
      } else {
        document.documentElement.dir = 'ltr';
      }
    }
  };

  // Set initial direction
  useEffect(() => {
    if (currentLanguage === 'ar' || currentLanguage === 'he') {
      document.documentElement.dir = 'rtl';
    } else {
      document.documentElement.dir = 'ltr';
    }
  }, [currentLanguage]);

  // Sync across tabs
  useEffect(() => {
    const handleStorageChange = (event) => {
      if (event.key === 'appLanguage' && event.newValue && translations[event.newValue]) {
        setLanguage(event.newValue);
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  return { t, currentLanguage, setLanguage, allLanguages: translations };
};
