import { createPageUrl } from '@/utils';

// Centralized utility to map various item types to a consistent format for display
export const mapItemToDetails = (item, itemType) => {
  if (!item) return null;

  switch (itemType) {
    case 'dish':
    case 'leftovers':
      return {
        id: item.id,
        title: item.name,
        price: item.price,
        imageUrl: item.photo_url,
        rating: item.rating_average,
        subtext: item.cook_name || 'Local Chef',
        description: item.description,
        cookName: item.cook_name,
        route: createPageUrl(`DishDetails?id=${item.id}`),
        item,
        itemType,
      };
    case 'meal_prep':
      return {
        id: item.id,
        title: item.service_title,
        price: item.price_per_week,
        imageUrl: item.photo_url,
        rating: item.rating_average,
        subtext: `${item.meals_per_week} meals/week`,
        description: item.description,
        cookName: item.cook_name,
        route: createPageUrl(`MealPrepDetails?id=${item.id}`),
        item,
        itemType,
      };
    case 'class':
      return {
        id: item.id,
        title: item.title,
        price: item.price,
        imageUrl: item.image_url,
        rating: item.rating,
        subtext: new Date(item.date).toLocaleDateString(),
        description: item.description,
        cookName: item.chef_name,
        route: createPageUrl(`ClassDetails?id=${item.id}`),
        item,
        itemType,
      };
    case 'last_call':
      return {
        id: item.id,
        title: item.food_title,
        price: item.discounted_price,
        originalPrice: item.original_price,
        imageUrl: item.photo_url,
        subtext: `Ends: ${new Date(item.expires_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
        description: item.description,
        cookName: item.seller_name,
        route: createPageUrl(`LastCallEatDetails?id=${item.id}`),
        item,
        itemType,
      };
    case 'surplus_grocery':
      return {
        id: item.id,
        title: item.product_title,
        price: item.discounted_price,
        originalPrice: item.original_price,
        imageUrl: item.photo_url,
        subtext: item.brand || 'Grocery Item',
        description: item.description,
        cookName: item.seller_name,
        route: createPageUrl(`SurplusGroceryDetails?id=${item.id}`),
        item,
        itemType,
      };
    case 'giveaway':
      return {
        id: item.id,
        title: item.item_title,
        price: 0,
        imageUrl: item.photo_url,
        subtext: `Free! (${item.condition})`,
        description: item.description,
        cookName: item.giver_name,
        route: createPageUrl(`GiveawayDetails?id=${item.id}`),
        item,
        itemType,
      };
    default:
      return {
        id: item.id,
        title: 'Unknown Item',
        price: 0,
        imageUrl: '',
        subtext: '',
        description: '',
        item,
        itemType,
      };
  }
};