import React from 'react';
import { Button } from '@/components/ui/button';
import { X, Share2, Copy } from 'lucide-react';
import { useTranslation } from './utils/translations';
import { showToast } from './common/ErrorBoundary';
import { createPageUrl } from '@/utils';

export const ShareModal = ({ isOpen, onClose, item, type }) => {
  const { t } = useTranslation();

  if (!isOpen || !item) return null;

  const getShareDetails = () => {
    let url, text;
    const baseUrl = window.location.origin;

    switch (type) {
      case 'dish':
        url = baseUrl + createPageUrl(`DishDetails?id=${item.id}`);
        text = t('shareDishText', `Check out this dish: ${item.name}! `);
        break;
      case 'recipe':
        url = baseUrl + createPageUrl(`RecipeDetails?id=${item.id}`);
        text = t('shareRecipeText', `I found a great recipe for ${item.title}! `);
        break;
      default:
        url = baseUrl;
        text = t('shareDefaultText', `Check this out on DishDash! `);
    }
    return { url, text };
  };

  const { url, text } = getShareDetails();
  const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text + url)}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(url);
    showToast(t('linkCopied', 'Link copied to clipboard!'), 'success');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">{t('shareItem', 'Share Item')}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
        </div>
        <div className="space-y-4">
          <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="w-full">
            <Button className="w-full h-12 bg-green-500 hover:bg-green-600 text-white text-base">
              {t('shareOnWhatsApp', 'Share on WhatsApp')}
            </Button>
          </a>
          <Button variant="outline" className="w-full h-12 text-base" onClick={copyToClipboard}>
            <Copy className="w-4 h-4 mr-2" /> {t('copyLink', 'Copy Link')}
          </Button>
        </div>
      </div>
    </div>
  );
};