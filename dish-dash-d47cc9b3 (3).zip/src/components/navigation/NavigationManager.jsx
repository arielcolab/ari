// Navigation state management and deep link handling
import { createPageUrl } from '@/utils';

export class NavigationManager {
  static navigateToScreen(screenName, params = {}) {
    const paramString = Object.keys(params).length > 0 
      ? '?' + new URLSearchParams(params).toString()
      : '';
    
    const url = createPageUrl(screenName) + paramString;
    
    // For programmatic navigation
    if (window.history && window.history.pushState) {
      window.history.pushState(null, '', url);
      window.dispatchEvent(new PopStateEvent('popstate'));
    } else {
      window.location.href = url;
    }
  }

  static handleDeepLink(url) {
    const urlObj = new URL(url, window.location.origin);
    const path = urlObj.pathname;
    const params = Object.fromEntries(urlObj.searchParams);
    
    // Extract screen name from path
    const screenName = path.split('/').pop() || 'Home';
    return { screenName, params };
  }

  static resetToHome() {
    this.navigateToScreen('Home');
  }
}