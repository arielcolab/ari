import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Plus, Check } from "lucide-react";
import { User } from "@/api/entities";
import { Follow } from "@/api/entities";
import { showToast } from "../common/ErrorBoundary";

export default function FollowButton({ cookId, cookName, size = "default" }) {
  const [isFollowing, setIsFollowing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const checkFollowStatus = async () => {
      try {
        const userData = await User.me();
        setUser(userData);
        
        // Check if already following
        const follows = await Follow.filter({ follower_id: userData.id, following_id: cookId });
        setIsFollowing(follows.length > 0);
      } catch (error) {
        setUser(null);
        setIsFollowing(false);
      }
    };
    
    if (cookId) {
      checkFollowStatus();
    }
  }, [cookId]);

  const handleFollow = async () => {
    if (!user) {
      showToast('Please log in to follow cooks', 'info');
      return;
    }

    setIsLoading(true);
    try {
      if (isFollowing) {
        // Unfollow
        const follows = await Follow.filter({ follower_id: user.id, following_id: cookId });
        if (follows.length > 0) {
          await Follow.delete(follows[0].id);
        }
        setIsFollowing(false);
        showToast(`Unfollowed ${cookName}`, 'success');
      } else {
        // Follow
        await Follow.create({
          follower_id: user.id,
          following_id: cookId
        });
        setIsFollowing(true);
        showToast(`Now following ${cookName}!`, 'success');
      }
    } catch (error) {
      console.error("Follow/unfollow error:", error);
      showToast('Could not update follow status', 'error');
    }
    setIsLoading(false);
  };

  const buttonSize = size === "sm" ? "sm" : "default";
  const iconSize = size === "sm" ? "w-4 h-4" : "w-5 h-5";

  return (
    <Button
      onClick={handleFollow}
      disabled={isLoading}
      size={buttonSize}
      variant={isFollowing ? "outline" : "default"}
      className={isFollowing 
        ? "border-gray-300 text-gray-700 hover:bg-gray-50" 
        : "bg-red-500 hover:bg-red-600 text-white"
      }
    >
      {isFollowing ? (
        <>
          <Check className={`${iconSize} mr-2`} />
          Following
        </>
      ) : (
        <>
          <Plus className={`${iconSize} mr-2`} />
          Follow
        </>
      )}
    </Button>
  );
}