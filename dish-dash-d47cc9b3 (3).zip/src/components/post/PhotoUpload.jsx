import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Upload, X, Plus } from "lucide-react";
import { UploadFile } from "@/api/integrations";
import { useTranslation } from "../utils/translations";

export default function PhotoUpload({ photos = [], onPhotosChange }) {
  const [uploading, setUploading] = useState(false);
  const { t } = useTranslation();

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploading(true);
    try {
      const uploadPromises = files.map(file => UploadFile({ file }));
      const results = await Promise.all(uploadPromises);
      const newPhotoUrls = results.map(result => result.file_url);
      onPhotosChange([...photos, ...newPhotoUrls]);
    } catch (error) {
      console.error("Error uploading photos:", error);
      alert("Error uploading photos. Please try again.");
    }
    setUploading(false);
  };

  const removePhoto = (indexToRemove) => {
    onPhotosChange(photos.filter((_, index) => index !== indexToRemove));
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-900">{t('photos')}</h3>
      
      {/* Photo Grid */}
      <div className="grid grid-cols-2 gap-3">
        {photos.map((photo, index) => (
          <div key={index} className="relative aspect-square rounded-xl overflow-hidden">
            <img
              src={photo}
              alt={`Dish photo ${index + 1}`}
              className="w-full h-full object-cover"
            />
            <button
              type="button"
              onClick={() => removePhoto(index)}
              className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
        
        {/* Upload Button */}
        {photos.length < 4 && (
          <div className="aspect-square border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center hover:border-red-400 transition-colors">
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
              id="photo-upload"
              disabled={uploading}
            />
            <label
              htmlFor="photo-upload"
              className="flex flex-col items-center justify-center cursor-pointer w-full h-full"
            >
              {uploading ? (
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-red-500" />
              ) : (
                <>
                  <Plus className="w-8 h-8 text-gray-400 mb-2" />
                  <span className="text-sm text-gray-500 text-center px-2">
                    {t('addPhotos')}
                  </span>
                </>
              )}
            </label>
          </div>
        )}
      </div>

      {/* Guidelines */}
      <p className="text-sm text-gray-500">
        {t('photoUploadGuidelines')}
      </p>
    </div>
  );
}