import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, X, Navigation, MapPin } from "lucide-react";

const AddressSuggestion = ({ address, subtitle, icon: Icon, onClick }) => (
  <button
    onClick={onClick}
    className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors"
  >
    <div className="p-2 bg-gray-100 rounded-full">
      <Icon className="w-5 h-5 text-gray-600" />
    </div>
    <div className="flex-1 text-left">
      <div className="font-medium text-[#1b140d]">{address}</div>
      <div className="text-sm text-gray-500">{subtitle}</div>
    </div>
  </button>
);

export default function AddressSearch({ isOpen, onClose, onAddressSelect }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [suggestions] = useState([
    {
      id: 1,
      address: "Avraham Stern Street 10",
      subtitle: "We think you're around here",
      icon: Navigation
    }
  ]);

  const filteredSuggestions = suggestions.filter(suggestion =>
    suggestion.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-white z-50">
      {/* Search Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onClose}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1 relative">
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search for your address"
              className="pr-10 bg-gray-50 border-0 rounded-lg"
              autoFocus
            />
            {searchTerm && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSearchTerm("")}
                className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Suggestions */}
      <div className="flex-1 bg-white">
        {searchTerm ? (
          filteredSuggestions.length > 0 ? (
            <div className="divide-y divide-gray-100">
              {filteredSuggestions.map((suggestion) => (
                <AddressSuggestion
                  key={suggestion.id}
                  address={suggestion.address}
                  subtitle={suggestion.subtitle}
                  icon={suggestion.icon}
                  onClick={() => {
                    onAddressSelect(suggestion);
                    onClose();
                  }}
                />
              ))}
            </div>
          ) : (
            <div className="p-4 text-center text-gray-500">
              No addresses found for "{searchTerm}"
            </div>
          )
        ) : (
          <div className="p-4">
            <AddressSuggestion
              address="Can't find your address?"
              subtitle="Use a map to do this instead"
              icon={MapPin}
              onClick={() => {
                alert("Map feature coming soon!");
                onClose();
              }}
            />
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 bg-gray-50">
        <div className="text-center text-xs text-gray-400">
          powered by Google
        </div>
      </div>
    </div>
  );
}