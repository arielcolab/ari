
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { MapPin, ChevronDown, Plus, Navigation, Home, Briefcase, X, Check } from 'lucide-react';
import { useTranslation } from '../utils/translations';
import { Address } from '@/api/entities';
import { showToast } from '../common/ErrorBoundary';

const LocationManager = ({ variant = 'default', onLocationChange }) => {
  const { t } = useTranslation();
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [currentLocation, setCurrentLocation] = useState('Tel Aviv'); // Initial state, will be updated by handleLocationSelect
  const [savedAddresses, setSavedAddresses] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newAddress, setNewAddress] = useState({
    label: '',
    street: '',
    city: '',
    state: '',
    zip_code: '',
    country: ''
  });

  useEffect(() => {
    if (showLocationModal) {
      loadSavedAddresses();
    }
  }, [showLocationModal]);

  const loadSavedAddresses = async () => {
    try {
      const addresses = await Address.list('-created_date');
      setSavedAddresses(addresses || []);
    } catch (error) {
      console.error('Error loading addresses:', error);
      setSavedAddresses([]);
    }
  };

  const handleLocationSelect = (location) => {
    setCurrentLocation(location);
    setShowLocationModal(false);
    if (onLocationChange) {
      onLocationChange(location);
    }
  };

  const handleAddAddress = async () => {
    try {
      if (!newAddress.street.trim() || !newAddress.city.trim()) {
        showToast(t('pleaseEnterAddressDetails', 'Please enter street and city'), 'error');
        return;
      }

      // Check for duplicates
      const fullAddress = `${newAddress.street.trim()}, ${newAddress.city.trim()}`;
      const isDuplicate = savedAddresses.some(addr => 
        `${addr.street}, ${addr.city}`.toLowerCase() === fullAddress.toLowerCase()
      );

      if (isDuplicate) {
        showToast(t('addressAlreadyExists', 'This address already exists'), 'error');
        return;
      }

      await Address.create({
        ...newAddress,
        label: newAddress.label.trim() || fullAddress, // Use full address as label if not provided
        street: newAddress.street.trim(),
        city: newAddress.city.trim(),
        zip_code: newAddress.zip_code.trim(),
      });

      // Reload addresses and close form
      await loadSavedAddresses();
      setNewAddress({ label: '', street: '', city: '', state: '', zip_code: '', country: '' });
      setShowAddForm(false);
      showToast(t('addressAdded', 'Address added successfully'), 'success');

    } catch (error) {
      console.error('Error adding address:', error);
      showToast(t('errorAddingAddress', 'Error adding address'), 'error');
    }
  };

  const getAddressIcon = (label) => {
    const lowerLabel = (label || '').toLowerCase();
    if (lowerLabel.includes('home') || lowerLabel.includes('בית')) return Home;
    if (lowerLabel.includes('work') || lowerLabel.includes('עבודה') || lowerLabel.includes('office')) return Briefcase;
    return MapPin;
  };

  if (variant === 'header') {
    return (
      <div className="relative">
        <div 
          className="flex items-center gap-2 cursor-pointer hover:bg-gray-100 rounded-lg p-2 transition-colors"
          onClick={() => setShowLocationModal(!showLocationModal)}
        >
          <MapPin className="w-4 h-4 text-gray-600" />
          <span className="text-sm font-medium text-gray-900">{currentLocation}</span>
          <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${showLocationModal ? 'rotate-180' : ''}`} />
        </div>

        {/* Dropdown Menu - Positioned absolutely from the top */}
        {showLocationModal && (
          <>
            {/* Background overlay */}
            <div 
              className="fixed inset-0 z-40" 
              onClick={() => setShowLocationModal(false)}
            />
            
            {/* Dropdown content - Made much wider */}
            <div className="absolute top-full left-0 mt-2 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden z-50 max-h-[80vh] overflow-y-auto w-96 min-w-[24rem]">
              {/* Header */}
              <div className="p-5 border-b border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900">{t('selectLocation', 'Select location')}</h3>
              </div>

              {/* Current Location Option */}
              <div 
                className="flex items-center gap-4 p-5 hover:bg-gray-50 cursor-pointer border-b border-gray-50"
                onClick={() => {
                  navigator.geolocation.getCurrentPosition(
                    () => handleLocationSelect(t('currentLocation', 'Current Location')),
                    () => showToast(t('locationError', 'Unable to get location'), 'error')
                  );
                }}
              >
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Navigation className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-blue-600 truncate">{t('useCurrentLocation', 'Use current location')}</p>
                  <p className="text-sm text-gray-500 truncate">{t('autoDetectLocation', 'Auto-detect your location')}</p>
                </div>
                {currentLocation === t('currentLocation', 'Current Location') && (
                  <Check className="w-5 h-5 text-blue-600 flex-shrink-0" />
                )}
              </div>

              {/* Saved Addresses Header */}
              {savedAddresses.length > 0 && (
                <div className="px-5 py-3 bg-gray-50">
                  <p className="text-sm font-medium text-gray-700">{t('savedAddresses', 'Saved addresses')}</p>
                </div>
              )}

              {/* Saved Addresses List */}
              {savedAddresses.map((address, index) => {
                const IconComponent = getAddressIcon(address.label);
                const fullAddress = `${address.street}, ${address.city}`;
                const isSelected = currentLocation === fullAddress;
                
                return (
                  <div
                    key={index}
                    className="flex items-center gap-4 p-5 hover:bg-gray-50 cursor-pointer border-b border-gray-50 last:border-b-0"
                    onClick={() => handleLocationSelect(fullAddress)}
                  >
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <IconComponent className={`w-5 h-5 ${isSelected ? 'text-red-600' : 'text-gray-600'}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`font-semibold truncate ${isSelected ? 'text-red-600' : 'text-gray-900'}`}>
                        {address.label}
                      </p>
                      <p className="text-sm text-gray-500 truncate">{fullAddress}</p>
                    </div>
                    {isSelected && <Check className="w-5 h-5 text-red-600 flex-shrink-0" />}
                  </div>
                );
              })}

              {/* Add New Address Option */}
              {!showAddForm && (
                <div 
                  className="flex items-center gap-4 p-5 hover:bg-gray-50 cursor-pointer border-t border-gray-100"
                  onClick={() => setShowAddForm(true)}
                >
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Plus className="w-5 h-5 text-green-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-green-600">{t('addNewAddress', 'Add new address')}</p>
                    <p className="text-sm text-gray-500">{t('saveAddressForLater', 'Save an address for quick access')}</p>
                  </div>
                </div>
              )}

              {/* Add Address Form */}
              {showAddForm && (
                <div className="p-5 border-t border-gray-100 bg-gray-50">
                  <h4 className="font-semibold text-gray-900 mb-4">{t('addNewAddress', 'Add New Address')}</h4>
                  <div className="space-y-3">
                    <input
                      type="text"
                      placeholder={t('addressLabel', 'Label (e.g. Home, Work)')}
                      value={newAddress.label}
                      onChange={(e) => setNewAddress({...newAddress, label: e.target.value})}
                      className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                    />
                    <input
                      type="text"
                      placeholder={t('streetAddress', 'Street Address')}
                      value={newAddress.street}
                      onChange={(e) => setNewAddress({...newAddress, street: e.target.value})}
                      className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                      required
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="text"
                        placeholder={t('city', 'City')}
                        value={newAddress.city}
                        onChange={(e) => setNewAddress({...newAddress, city: e.target.value})}
                        className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                        required
                      />
                      <input
                        type="text"
                        placeholder={t('zipCode', 'Zip Code')}
                        value={newAddress.zip_code}
                        onChange={(e) => setNewAddress({...newAddress, zip_code: e.target.value})}
                        className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                      />
                    </div>
                    <div className="flex gap-3 pt-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setShowAddForm(false);
                          setNewAddress({ label: '', street: '', city: '', state: '', zip_code: '', country: '' });
                        }}
                        className="flex-1"
                      >
                        {t('cancel', 'Cancel')}
                      </Button>
                      <Button
                        onClick={handleAddAddress}
                        className="flex-1 bg-red-600 hover:bg-red-700"
                      >
                        {t('saveAddress', 'Save Address')}
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    );
  }

  // Default variant (for other uses)
  return (
    <Button 
      variant="ghost" 
      onClick={() => setShowLocationModal(true)}
      className="text-left"
    >
      <div className="flex items-center gap-2">
        <MapPin className="w-4 h-4" />
        <span>{currentLocation}</span>
        <ChevronDown className="w-4 h-4" />
      </div>
    </Button>
  );
};

export default LocationManager;
