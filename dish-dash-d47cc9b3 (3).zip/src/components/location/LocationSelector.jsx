
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Address } from "@/api/entities";
import {
  ChevronDown,
  MapPin,
  Navigation,
  Home as HomeIcon,
  Plus,
  List,
  X,
  Check,
  Search,
  AlertCircle
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import AddressSearch from "./AddressSearch";
import { useTranslation } from "../utils/translations";

const LocationOption = ({ icon: Icon, title, subtitle, isSelected, onClick, disabled = false, showCheck = false }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`w-full flex items-center gap-4 p-4 rounded-xl transition-colors ${
      isSelected ? 'bg-red-50 border border-red-200' : 'hover:bg-gray-50'
    } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
  >
    <div className={`p-2 rounded-full ${
      isSelected ? 'bg-red-500 text-white' : 'bg-gray-100 text-gray-600'
    }`}>
      <Icon className="w-5 h-5" />
    </div>
    <div className="flex-1 text-left">
      <div className="font-semibold text-gray-900">{title}</div>
      {subtitle && <div className="text-sm text-gray-500">{subtitle}</div>}
    </div>
    {showCheck && isSelected && (
      <Check className="w-5 h-5 text-green-500" />
    )}
  </button>
);

export default function LocationSelector({ currentLocation, onLocationChange }) {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [showAddressSearch, setShowAddressSearch] = useState(false);
  const [locationError, setLocationError] = useState(null);
  const [savedAddresses, setSavedAddresses] = useState([]);

  useEffect(() => {
    if (isOpen) {
      loadSavedAddresses();
    }
  }, [isOpen]);

  const loadSavedAddresses = async () => {
    try {
      const addresses = await Address.list("-created_date");
      setSavedAddresses(addresses);
    } catch (error) {
      console.error("Error loading addresses:", error);
    }
  };

  const handleUseCurrentLocation = () => {
    setLocationError(null);
    if (!navigator.geolocation) {
      setLocationError(t("locationAccessNotAvailable"));
      return;
    }

    setIsGettingLocation(true);

    const options = {
      enableHighAccuracy: false,
      timeout: 10000,
      maximumAge: 60000
    };

    const success = (position) => {
      const { latitude, longitude } = position.coords;
      const newLocation = {
        id: 'current',
        title: t('currentLocation'),
        subtitle: `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`,
        coords: { latitude, longitude }
      };
      onLocationChange(newLocation);
      setIsGettingLocation(false);
      setIsOpen(false);
    };

    const error = (err) => {
      console.warn(`Location error: - ${err.message}`);
      setIsGettingLocation(false);
      let errorMessage = t("couldNotAccessLocation");
      if (err.code === err.PERMISSION_DENIED) {
        errorMessage = t("locationAccessDenied");
      }
      setLocationError(errorMessage);
    };

    navigator.geolocation.getCurrentPosition(success, error, options);
  };

  const handleSavedLocationSelect = (address) => {
    const location = {
      id: address.id,
      title: address.label || address.street,
      subtitle: `${address.city}, ${address.state} ${address.zip_code}`.trim(),
      address: address
    };
    onLocationChange(location);
    setIsOpen(false);
  };

  const handleAddNewAddress = () => {
    setIsOpen(false);
    navigate(createPageUrl("AddAddress"));
  };

  const handleAddressSearchSelect = (address) => {
    const newLocation = {
      id: 'searched',
      title: address.address,
      subtitle: address.subtitle
    };
    onLocationChange(newLocation);
    setShowAddressSearch(false);
    setIsOpen(false);
  };

  const openDialog = () => {
    setLocationError(null);
    setIsOpen(true);
  };

  return (
    <>
      <Button
        variant="ghost"
        onClick={openDialog}
        className="flex items-center gap-2 text-left p-2 h-auto bg-transparent hover:bg-gray-50 rounded-lg"
      >
        <HomeIcon className="w-5 h-5 text-gray-900" />
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-gray-900 text-sm truncate">
            {currentLocation?.title || t("setLocation")}
          </div>
          {currentLocation?.subtitle && (
            <div className="text-xs text-gray-500 truncate">
              {currentLocation.subtitle}
            </div>
          )}
        </div>
        <ChevronDown className="w-4 h-4 text-gray-400" />
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader className="flex flex-row items-center justify-between">
            <DialogTitle className="text-2xl font-bold text-gray-900">{t("location")}</DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="rounded-full"
            >
              <X className="w-5 h-5" />
            </Button>
          </DialogHeader>

          {locationError && (
            <div className="bg-red-50 border border-red-200 text-red-800 p-3 rounded-lg text-sm flex items-start gap-3">
              <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
              <span>{locationError}</span>
            </div>
          )}

          <div className="space-y-4 pt-2">
            {/* Use Current Location */}
            <LocationOption
              icon={Navigation}
              title={t("useCurrentLocation")}
              disabled={isGettingLocation}
              onClick={handleUseCurrentLocation}
            />

            {/* Search for Address */}
            <LocationOption
              icon={Search}
              title={t("searchForDishes")}
              subtitle={t("findYourLocation")}
              onClick={() => setShowAddressSearch(true)}
            />

            {/* Saved Addresses */}
            {savedAddresses.map((address) => (
              <LocationOption
                key={address.id}
                icon={address.label?.toLowerCase() === 'home' ? HomeIcon : MapPin}
                title={address.label || address.street}
                subtitle={`${address.city}, ${address.state} ${address.zip_code}`.trim()}
                isSelected={currentLocation?.id === address.id}
                onClick={() => handleSavedLocationSelect(address)}
                showCheck={true}
              />
            ))}

            {/* Add New Address */}
            <LocationOption
              icon={Plus}
              title={t("addNewAddress")}
              subtitle={t("createSavedLocation")}
              onClick={handleAddNewAddress}
            />

            {/* Browse Cities */}
            <LocationOption
              icon={List}
              title={t("browseAllCities")}
              subtitle={t("viewAvailableLocations")}
              onClick={() => alert(t("cityBrowserComingSoon"))}
            />
          </div>
        </DialogContent>
      </Dialog>

      <AddressSearch
        isOpen={showAddressSearch}
        onClose={() => setShowAddressSearch(false)}
        onAddressSelect={handleAddressSearchSelect}
      />
    </>
  );
}
