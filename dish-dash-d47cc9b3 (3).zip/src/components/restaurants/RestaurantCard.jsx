import React from 'react';
import OptimizedImage from '../dd_OptimizedImage';
import RatingDisplay from '../reviews/RatingDisplay';
import { Clock, Star, DollarSign } from 'lucide-react';
import { useTranslation } from '../utils/translations';
import { Button } from '@/components/ui/button'; // Fixed import path

export default function RestaurantCard({ restaurant, onClick }) {
  const { t } = useTranslation();

  if (!restaurant) return null;

  const InfoTag = ({ icon: Icon, text, color = "text-gray-600" }) => (
    <div className="flex items-center gap-1.5">
      <Icon className={`w-4 h-4 ${color}`} />
      <span className="text-sm font-medium text-gray-700">{text}</span>
    </div>
  );

  return (
    <div
      className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300"
    >
      <div onClick={onClick} className="cursor-pointer">
        <div className="relative">
          <OptimizedImage
            src={restaurant.image_url}
            alt={restaurant.name}
            className="w-full h-40 object-cover"
          />
          {restaurant.is_premium && (
            <div className="absolute top-3 left-3 bg-yellow-400 text-yellow-900 text-xs font-bold px-2 py-1 rounded-full shadow-md">
              DishDash+
            </div>
          )}
        </div>
        <div className="p-4">
          <h3 className="font-bold text-lg text-gray-900 truncate mb-1">{restaurant.name}</h3>
          <p className="text-sm text-gray-500 mb-3">{restaurant.cuisine}</p>
          <div className="flex items-center justify-between">
            <InfoTag icon={Star} text={restaurant.rating_average?.toFixed(1) || 'N/A'} color="text-yellow-500" />
            <InfoTag icon={Clock} text={`${restaurant.delivery_time_minutes || '--'} ${t('minutesShort', 'min')}`} />
            <InfoTag
              icon={DollarSign}
              text={restaurant.delivery_fee === 0 ? t('free', 'Free') : `₪${restaurant.delivery_fee?.toFixed(2)}`}
              color={restaurant.delivery_fee === 0 ? "text-green-600" : "text-gray-600"}
            />
          </div>
        </div>
      </div>

      {/* Note: Restaurants don't have direct add to cart, but we maintain consistency */}
      <div className="p-4 border-t border-gray-100">
        <div className="flex justify-between items-center">
          <div className="text-sm text-gray-600">
            {restaurant.cuisine} • {restaurant.delivery_time_minutes} min
          </div>
          <Button
            onClick={onClick}
            size="sm"
            className="bg-red-600 hover:bg-red-700 text-white"
          >
            View Menu
          </Button>
        </div>
      </div>
    </div>
  );
}