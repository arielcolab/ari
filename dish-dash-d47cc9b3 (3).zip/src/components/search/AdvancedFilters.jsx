import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter, SheetClose } from '@/components/ui/sheet';
import { ArrowLeft, ChevronRight, X } from 'lucide-react';
import { useTranslation } from '../utils/translations';
import { PriceDisplay } from '../utils/dd_currency';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';

const FilterSection = ({ title, children }) => (
  <div className="py-4 border-b border-gray-100">
    <h3 className="font-semibold text-gray-900 mb-3">{title}</h3>
    {children}
  </div>
);

export default function AdvancedFilters({ isOpen, onClose, filters, onFiltersChange }) {
  const { t } = useTranslation();
  const [currentFilters, setCurrentFilters] = useState(filters);

  const handleApply = () => {
    onFiltersChange(currentFilters);
    onClose();
  };

  const handleReset = () => {
    const defaultFilters = {
      type: 'all',
      sortBy: 'newest',
      priceRange: { min: 0, max: 500 },
      distance: 25,
      isChef: 'any',
      onSale: false,
      isBundle: false,
      freeItems: false,
      expiryWithin: 'any',
      dietaryTags: [],
      allergenFree: [],
      rating: 0,
      verified: false
    };
    setCurrentFilters(defaultFilters);
  };

  const updateFilter = (key, value) => {
    setCurrentFilters(prev => ({ ...prev, [key]: value }));
  };

  if (!isOpen) return null;

  const sortOptions = [
    { value: 'newest', label: 'Newest First' },
    { value: 'oldest', label: 'Oldest First' },
    { value: 'price_low', label: 'Price: Low to High' },
    { value: 'price_high', label: 'Price: High to Low' },
    { value: 'rating', label: 'Highest Rated' },
    { value: 'ending_soon', label: 'Ending Soon' }
  ];

  const dietaryOptions = ['vegan', 'vegetarian', 'kosher', 'halal', 'organic', 'keto', 'paleo'];
  const allergenOptions = ['gluten', 'dairy', 'nuts', 'eggs', 'soy', 'shellfish', 'fish', 'sesame'];

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="bottom" className="h-[95vh] flex flex-col rounded-t-2xl">
        <SheetHeader className="flex-row items-center justify-between px-4 py-3 border-b">
           <SheetClose asChild>
             <Button variant="ghost" size="icon"><ArrowLeft className="w-5 h-5" /></Button>
           </SheetClose>
          <SheetTitle className="text-center">{t('filters')}</SheetTitle>
          <Button variant="ghost" onClick={handleReset} className="text-red-500">
            {t('resetAll')}
          </Button>
        </SheetHeader>
        
        <div className="flex-grow overflow-y-auto px-4">
          {/* Sort By */}
          <FilterSection title="Sort By">
            <div className="space-y-2">
              {sortOptions.map(option => (
                <Button
                  key={option.value}
                  variant={currentFilters.sortBy === option.value ? "default" : "outline"}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => updateFilter('sortBy', option.value)}
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </FilterSection>

          {/* Price Range */}
          <FilterSection title="Price Range">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <PriceDisplay price={currentFilters.priceRange.min} />
                <span>-</span>
                <PriceDisplay price={currentFilters.priceRange.max} />
              </div>
              <Slider
                value={[currentFilters.priceRange.min, currentFilters.priceRange.max]}
                onValueChange={([min, max]) => updateFilter('priceRange', { min, max })}
                max={500}
                step={5}
                className="w-full"
              />
            </div>
          </FilterSection>

          {/* Chef Type */}
          <FilterSection title="Chef Type">
            <div className="space-y-2">
              {[
                { value: 'any', label: 'Any Chef' },
                { value: 'professional', label: 'Professional Chef' },
                { value: 'home', label: 'Home Cook' }
              ].map(option => (
                <Button
                  key={option.value}
                  variant={currentFilters.isChef === option.value ? "default" : "outline"}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => updateFilter('isChef', option.value)}
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </FilterSection>

          {/* Quick Filters */}
          <FilterSection title="Quick Filters">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span>On Sale Only</span>
                <Switch
                  checked={currentFilters.onSale}
                  onCheckedChange={(checked) => updateFilter('onSale', checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <span>Bundles Only</span>
                <Switch
                  checked={currentFilters.isBundle}
                  onCheckedChange={(checked) => updateFilter('isBundle', checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <span>Free Items</span>
                <Switch
                  checked={currentFilters.freeItems}
                  onCheckedChange={(checked) => updateFilter('freeItems', checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <span>Verified Only</span>
                <Switch
                  checked={currentFilters.verified}
                  onCheckedChange={(checked) => updateFilter('verified', checked)}
                />
              </div>
            </div>
          </FilterSection>

          {/* Dietary Tags */}
          <FilterSection title="Dietary Preferences">
            <div className="flex flex-wrap gap-2">
              {dietaryOptions.map(tag => (
                <Badge
                  key={tag}
                  variant={currentFilters.dietaryTags.includes(tag) ? "default" : "outline"}
                  className="cursor-pointer capitalize"
                  onClick={() => {
                    const newTags = currentFilters.dietaryTags.includes(tag)
                      ? currentFilters.dietaryTags.filter(t => t !== tag)
                      : [...currentFilters.dietaryTags, tag];
                    updateFilter('dietaryTags', newTags);
                  }}
                >
                  {tag}
                </Badge>
              ))}
            </div>
          </FilterSection>

          {/* Allergen Free */}
          <FilterSection title="Allergen Free">
            <div className="flex flex-wrap gap-2">
              {allergenOptions.map(allergen => (
                <Badge
                  key={allergen}
                  variant={currentFilters.allergenFree.includes(allergen) ? "default" : "outline"}
                  className="cursor-pointer capitalize"
                  onClick={() => {
                    const newAllergens = currentFilters.allergenFree.includes(allergen)
                      ? currentFilters.allergenFree.filter(a => a !== allergen)
                      : [...currentFilters.allergenFree, allergen];
                    updateFilter('allergenFree', newAllergens);
                  }}
                >
                  No {allergen}
                </Badge>
              ))}
            </div>
          </FilterSection>

          {/* Rating */}
          <FilterSection title="Minimum Rating">
            <div className="space-y-2">
              {[0, 3, 4, 4.5].map(rating => (
                <Button
                  key={rating}
                  variant={currentFilters.rating === rating ? "default" : "outline"}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => updateFilter('rating', rating)}
                >
                  {rating === 0 ? 'Any Rating' : `${rating}+ Stars`}
                </Button>
              ))}
            </div>
          </FilterSection>
        </div>

        <SheetFooter className="p-4 border-t">
          <Button onClick={handleApply} className="w-full h-12 text-lg bg-red-600 hover:bg-red-700">
            {t('seeItems')} ({currentFilters.resultCount || 0})
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}