import React, { useState, useEffect } from "react";
import { Review } from "@/api/entities";
import { Star, ThumbsUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTranslation } from "../utils/translations";

const ReviewItem = ({ review, showDishName = false, showCookName = false }) => {
  const { t } = useTranslation();
  
  return (
    <div className="py-4 border-b border-gray-100 last:border-b-0">
      <div className="flex items-start gap-4">
        <img
          src={review.reviewer_photo || "https://images.unsplash.com/photo-1544005313-94ddf0286df2"}
          alt={review.reviewer_name}
          className="w-10 h-10 rounded-full object-cover"
        />
        <div className="flex-1">
          <div className="flex justify-between items-start mb-2">
            <div>
              <h4 className="font-semibold text-gray-900">{review.reviewer_name}</h4>
              {review.is_verified_purchase && (
                <span className="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full mt-1">
                  Verified Purchase
                </span>
              )}
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1 mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <p className="text-xs text-gray-500">
                {new Date(review.created_date).toLocaleDateString()}
              </p>
            </div>
          </div>
          
          {(showDishName || showCookName) && (
            <p className="text-sm text-gray-600 mb-2">
              {showDishName && `Dish: ${review.dish_name || 'Unknown Dish'}`}
              {showCookName && `Cook: ${review.cook_name || 'Unknown Cook'}`}
            </p>
          )}
          
          {review.comment && (
            <p className="text-gray-700 text-sm leading-relaxed">{review.comment}</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default function ReviewsList({ 
  dishId = null, 
  cookId = null, 
  userId = null,
  showDishName = false,
  showCookName = false,
  limit = null 
}) {
  const [reviews, setReviews] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { t } = useTranslation();

  useEffect(() => {
    loadReviews();
  }, [dishId, cookId, userId]);

  const loadReviews = async () => {
    setIsLoading(true);
    try {
      let allReviews = await Review.list("-created_date");
      
      // Filter reviews based on props
      let filteredReviews = allReviews;
      
      if (dishId) {
        filteredReviews = filteredReviews.filter(r => r.dish_id === dishId);
      }
      
      if (cookId) {
        filteredReviews = filteredReviews.filter(r => r.cook_id === cookId);
      }
      
      if (userId) {
        // Reviews for a specific user (reviews they received as a cook)
        filteredReviews = filteredReviews.filter(r => r.cook_id === userId);
      }
      
      if (limit) {
        filteredReviews = filteredReviews.slice(0, limit);
      }
      
      setReviews(filteredReviews);
    } catch (error) {
      console.error("Error loading reviews:", error);
    }
    setIsLoading(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-500" />
      </div>
    );
  }

  if (reviews.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>No reviews yet. Be the first to leave one!</p>
      </div>
    );
  }

  return (
    <div className="space-y-0">
      {reviews.map((review) => (
        <ReviewItem 
          key={review.id} 
          review={review}
          showDishName={showDishName}
          showCookName={showCookName}
        />
      ))}
    </div>
  );
}