
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Star } from "lucide-react";
import { Review } from "@/api/entities";
import { User } from "@/api/entities";
import { useTranslation } from "../utils/translations";
import { showToast } from "../common/ErrorBoundary";

const StarRating = ({ rating, onRatingChange, readonly = false }) => (
  <div className="flex gap-1">
    {[1, 2, 3, 4, 5].map((star) => (
      <button
        key={star}
        type="button"
        onClick={() => !readonly && onRatingChange(star)}
        className={`transition-colors ${readonly ? 'cursor-default' : 'hover:scale-110'}`}
        disabled={readonly}
      >
        <Star
          className={`w-8 h-8 ${
            star <= rating
              ? "text-yellow-400 fill-yellow-400"
              : "text-gray-300"
          }`}
        />
      </button>
    ))}
  </div>
);

export default function ReviewForm({ dishId, cookId, orderId, onSubmitted, existingReview = null }) {
  const { t } = useTranslation();
  const [rating, setRating] = useState(existingReview?.rating || 0);
  const [comment, setComment] = useState(existingReview?.comment || "");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!rating) {
      showToast(t('pleaseSelectRating', 'Please select a rating'), 'error');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const user = await User.me(); // Fetch user first

      const reviewData = {
        dish_id: dishId,
        cook_id: cookId,
        order_id: orderId,
        rating: rating,
        comment: comment.trim(),
        reviewer_name: user?.full_name || 'Anonymous',
        reviewer_photo: user?.profile_photo_url || '',
        review_type: 'dish', // Hardcoded as per outline
        is_verified_purchase: true // Hardcoded as per outline
      };

      await Review.create(reviewData); // Always create new review as per outline
      
      // Award gamification points for review
      try {
        const { awardReviewPoints } = await import('../gamification/GamificationManager');
        if (user?.id) {
          await awardReviewPoints(user.id);
        }
      } catch (error) {
        console.log('Could not award review points:', error);
      }
      
      showToast(t('reviewSubmitted', 'Review submitted successfully!'), 'success');
      
      if (onSubmitted) { // Using onSubmitted as it's the defined prop
        onSubmitted();
      }
    } catch (error) {
      console.error('Error submitting review:', error);
      showToast(t('reviewSubmissionError', 'Error submitting review'), 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 p-6 bg-white rounded-xl">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          {t('leaveAReview', 'Leave a Review')} {/* Changed to always 'Leave a Review' */}
        </h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('rating', 'Rating')}
            </label>
            <StarRating rating={rating} onRatingChange={setRating} />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('commentOptional', 'Comment (Optional)')}
            </label>
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={t('shareYourExperience', 'Share your experience...')}
              className="min-h-[100px]"
            />
          </div>
        </div>
      </div>

      <div className="flex gap-3">
        <Button
          type="submit"
          disabled={isSubmitting || rating === 0}
          className="flex-1 bg-red-500 hover:bg-red-600"
        >
          {isSubmitting ? t('submitting', 'Submitting...') : t('submitReview', 'Submit Review')} {/* Changed to always 'Submit Review' */}
        </Button>
      </div>
    </form>
  );
}
