import React from "react";
import { Star } from "lucide-react";

export default function RatingDisplay({ 
  rating, 
  reviewCount = 0, 
  size = "sm", 
  showCount = true,
  className = "" 
}) {
  const starSize = {
    xs: "w-3 h-3",
    sm: "w-4 h-4", 
    md: "w-5 h-5",
    lg: "w-6 h-6"
  };

  const textSize = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-base",
    lg: "text-lg"
  };

  const displayRating = rating ? parseFloat(rating).toFixed(1) : "0.0";

  return (
    <div className={`flex items-center gap-1 ${className}`}>
      <Star className={`${starSize[size]} text-yellow-400 fill-yellow-400`} />
      <span className={`font-medium text-gray-900 ${textSize[size]}`}>
        {displayRating}
      </span>
      {showCount && reviewCount > 0 && (
        <span className={`text-gray-500 ${textSize[size]}`}>
          ({reviewCount})
        </span>
      )}
    </div>
  );
}